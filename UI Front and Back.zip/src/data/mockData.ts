import { Candidate, JobListing, SystemMetrics, SystemSettings, NotificationItem } from '../types';

export const initialMetrics: SystemMetrics = {
  totalProcessed: 1248,
  processedTrendPercentage: 14.2,
  avgMatchScore: 84.5,
  matchScoreTrendPercentage: 3.8,
  pendingReviews: 18,
  jobsRecommended: 342,
};

export const initialCandidates: Candidate[] = [
  {
    id: 'cand-001',
    name: 'Maya Lin',
    codeName: 'Candidate #84A9',
    role: 'Senior Staff AI/ML Engineer',
    email: 'maya.lin@example.com',
    phone: '+1 (415) 892-0129',
    location: 'San Francisco, CA (Hybrid)',
    regionZone: 'Zone 1 - Bay Area Commute',
    experienceYears: 8,
    matchScore: 96,
    status: 'Shortlisted',
    uploadDate: '2026-08-06',
    summary: 'Senior ML Engineer specializing in Large Language Models, PyTorch architecture, distributed training pipelines, and high-throughput serving systems on GCP.',
    technicalSkills: ['Python', 'PyTorch', 'TensorFlow', 'LLM Fine-Tuning', 'Transformer Models', 'Kubernetes', 'Docker', 'Google Cloud (Vertex AI)', 'C++'],
    softSkills: ['Technical Leadership', 'Cross-team Collaboration', 'Research to Product Translation', 'Problem Solving'],
    education: ['M.S. Computer Science - Stanford University', 'B.S. Electrical Engineering - UC Berkeley'],
    fileName: 'Maya_Lin_Resume_AI_Lead.pdf',
    fileSize: '1.4 MB',
    strengths: [
      'Published 3 papers on Transformer Optimization at NeurIPS',
      'Engineered inference pipeline reducing p99 latency by 42%',
      'Direct expertise in Google Vertex AI & modern GenAI frameworks'
    ],
    missingKeywords: ['Rust', 'ONNX Runtime'],
    biasMitigationScore: 99,
    aiOptimizationTip: 'Add specific GPU cluster memory optimization benchmarks to highlight hardware-level infrastructure efficiency.',

    // Multi-Module Extracted Data
    detectedLanguage: 'en',
    ocrExtractedText: `MAYA LIN - SENIOR STAFF AI/ML ENGINEER
Email: maya.lin@example.com | Phone: +1 (415) 892-0129 | Location: San Francisco, CA
SUMMARY: Senior ML Engineer with 8 years of experience building scalable transformer architectures, fine-tuning LLMs on GCP Vertex AI, and deploying PyTorch inference pipelines in production.
EXPERIENCE:
- Anthro AI (2023 - Present): Staff AI Engineer - Architected LLM serving processing 50M+ daily tokens. Reduced p99 latency by 42%.
- Tech Labs (2019 - 2023): Senior ML Researcher - Trained custom transformer models for document parsing.
EDUCATION: M.S. CS Stanford University, B.S. EE UC Berkeley`,
    
    portfolioLinks: [
      {
        platform: 'github',
        url: 'https://github.com/mayalin-ai',
        status: 'verified',
        lastVerifiedTimestamp: '2 mins ago (AI Fetch)',
        repoCount: 42,
        topLanguages: ['Python', 'C++', 'CUDA'],
        pinnedProjects: ['vllm-flash-attn-opt', 'transformer-quantizer-v3', 'vertex-agent-sdk']
      },
      {
        platform: 'linkedin',
        url: 'https://linkedin.com/in/mayalin-ai',
        status: 'verified',
        lastVerifiedTimestamp: '10 mins ago (AI Fetch)'
      }
    ],

    careerGaps: [
      {
        id: 'gap-001',
        startDate: '2021-06',
        endDate: '2021-11',
        durationMonths: 5,
        reasonCategory: 'Higher Education / Upskilling',
        explanationText: 'Intensive Stanford AI Research Residency focusing on Transformer Attention Pruning.',
        aiConfidence: 96,
        resolved: true,
        recruiterNotes: 'Verified via research publication timeline.'
      }
    ],

    companyHistory: [
      {
        id: 'comp-01',
        companyName: 'Anthro AI',
        roleTitle: 'Staff AI Engineer',
        startDate: '2023-01',
        endDate: 'Present',
        tier: 'Tier 1 (FAANG / Tech Leader)',
        criteriaTooltip: 'Tier 1: High-impact AI frontier lab with elite engineering bars.',
        durationMonths: 43,
        promotionsInCompany: [{ from: 'Senior AI Engineer', to: 'Staff AI Engineer', monthsTaken: 14 }]
      },
      {
        id: 'comp-02',
        companyName: 'Google Research Lab',
        roleTitle: 'Senior ML Researcher',
        startDate: '2019-06',
        endDate: '2022-12',
        tier: 'Tier 1 (FAANG / Tech Leader)',
        criteriaTooltip: 'Tier 1: Global tech leader with world-class AI research infrastructure.',
        durationMonths: 42
      }
    ],

    blockchainCredentials: [
      {
        id: 'bc-01',
        title: 'M.S. Computer Science - Stanford University',
        issuer: 'Stanford Decentralized Registrar',
        issuedDate: '2019-05-15',
        ledgerNetwork: 'Ethereum',
        txHash: '0x7a1b...4f92d8e3',
        verificationStatus: 'verified',
        proofUrl: 'https://etherscan.io/tx/0x7a1b4f92'
      },
      {
        id: 'bc-02',
        title: 'Google Cloud Certified Professional ML Engineer',
        issuer: 'Google Cloud Credentials Ledger',
        issuedDate: '2024-02-10',
        ledgerNetwork: 'Polygon',
        txHash: '0x3c9f...81e2a401',
        verificationStatus: 'verified',
        proofUrl: 'https://polygonscan.com/tx/0x3c9f81e2'
      }
    ],

    inferredSoftSkills: [
      { id: 'ss-1', skillName: 'Technical Leadership', score: 95, aiConfidence: 98, resumeSnippet: 'Led team of 5 research engineers on multi-modal vision-language model training', validated: true },
      { id: 'ss-2', skillName: 'Problem Solving', score: 92, aiConfidence: 95, resumeSnippet: 'Reduced inference p99 latency by 42% through INT8 quantization & CUDA kernels', validated: true },
      { id: 'ss-3', skillName: 'Cross-team Collaboration', score: 88, aiConfidence: 91, resumeSnippet: 'Partnered with product & infrastructure teams to deploy models serving 50M+ daily tokens', validated: true }
    ],

    growthTrajectory: {
      promotionVelocityTag: '🚀 Fast-Track: Promoted in 14 months',
      promotionVelocityColor: 'green',
      averageTenureMonths: 42,
      industryAvgComparison: '+40% faster promotion rate than industry benchmark',
      titleChanges: [
        { title: 'Senior ML Researcher', year: '2019', company: 'Google Research' },
        { title: 'Senior AI Engineer', year: '2023', company: 'Anthro AI' },
        { title: 'Staff AI Engineer', year: '2024', company: 'Anthro AI' }
      ]
    },

    techStackItems: [
      { id: 'ts-1', name: 'Python', category: 'Modern/Emerging Stack', yearsExperience: 8, adoptionTrend: 'Up-to-Date', matchesJobReq: true },
      { id: 'ts-2', name: 'PyTorch / vLLM', category: 'Modern/Emerging Stack', yearsExperience: 6, adoptionTrend: 'Up-to-Date', matchesJobReq: true },
      { id: 'ts-3', name: 'Vertex AI / GCP', category: 'Modern/Emerging Stack', yearsExperience: 5, adoptionTrend: 'Up-to-Date', matchesJobReq: true },
      { id: 'ts-4', name: 'C++ / CUDA', category: 'Foundational/Legacy', yearsExperience: 7, adoptionTrend: 'Up-to-Date', matchesJobReq: true },
      { id: 'ts-5', name: 'TensorFlow 1.x', category: 'Foundational/Legacy', yearsExperience: 4, adoptionTrend: 'Legacy', matchesJobReq: false }
    ],

    fuzzySkillAlias: {
      standardizedRole: 'AI / Machine Learning Engineer',
      aliases: [
        { name: 'LLM Architect', confidence: 98, approved: true },
        { name: 'Neural Pipeline Specialist', confidence: 95, approved: true },
        { name: 'Deep Learning Scientist', confidence: 92, approved: true }
      ]
    },

    marketDemand: {
      marketDemandScore: 98,
      scarcityTags: [
        { skill: 'LLM Fine-Tuning', tag: 'Surging Demand 📈', icon: 'trending_up' },
        { skill: 'vLLM / CUDA Optimization', tag: 'High Scarcity 🔥', icon: 'local_fire_department' }
      ],
      marketAvailability: 'Low',
      hiringVelocity: 'Fast',
      twelveMonthTrend: [65, 70, 78, 82, 88, 91, 94, 96, 98, 97, 99, 100]
    },

    peerBenchmarking: {
      targetRoleBaseline: 'Senior Staff AI Engineer Baseline',
      metrics: [
        { name: 'Technical Stack Alignment', candidateScore: 98, teamAvgScore: 84, variancePercentage: 16.6 },
        { name: 'Execution Speed / Velocity', candidateScore: 94, teamAvgScore: 80, variancePercentage: 17.5 },
        { name: 'Inferred Leadership Potential', candidateScore: 92, teamAvgScore: 82, variancePercentage: 12.2 }
      ]
    },

    careerPathProjection: [
      { stepIndex: 1, title: 'Senior Staff AI Engineer', estimatedYear: 'Current', isCurrent: true, requiredCertifications: ['Google Vertex AI Professional'], targetAspirations: ['Distributed Systems Architecture'] },
      { stepIndex: 2, title: 'Principal AI Architect', estimatedYear: 'Year 2 (2028)', isCurrent: false, requiredCertifications: ['System Design Mastery'], targetAspirations: ['Multi-Modal Frontier Models'] },
      { stepIndex: 3, title: 'VP of AI / Machine Learning', estimatedYear: 'Year 5 (2031)', isCurrent: false, requiredCertifications: ['Executive Leadership Program'], targetAspirations: ['Global AI Strategy'] }
    ],

    skillGaps: [
      {
        skillName: 'PyTorch / LLM Fine-Tuning',
        matched: true,
        severity: 'Minor Gap'
      },
      {
        skillName: 'ONNX Runtime Optimization',
        matched: false,
        severity: 'Minor Gap',
        suggestedCourse: {
          id: 'course-101',
          title: 'High-Performance Inference with ONNX Runtime & TensorRT',
          platform: 'Google Cloud Skills',
          durationHours: '12 hours',
          difficulty: 'Intermediate',
          bridgesSkill: 'ONNX Runtime Optimization',
          syllabusUrl: 'https://cloud.google.com/training',
          assigned: false
        }
      }
    ],

    commuteInfo: {
      workMode: 'Hybrid',
      commuteMinutes: 25,
      travelMode: 'Transit',
      exceedsThreshold: false
    },

    cultureFit: {
      cultureFitIndex: 94,
      matchedValues: [
        { candidatePhrasing: 'Autonomous Research Execution', corporateValue: 'Innovation & Agility', alignmentScore: 96 },
        { candidatePhrasing: 'Open Source Community Contributor', corporateValue: 'Collaborative Open Ecosystem', alignmentScore: 92 }
      ],
      sourceSnippets: [
        '"Led team of 5 research engineers while maintaining hands-on code contributions in open source vLLM project."'
      ],
      interviewQuestions: [
        'How do you balance pure ML research exploration with strict production SLA deadlines?',
        'Describe a time you optimized GPU hardware usage under strict cloud cost constraints.'
      ]
    }
  },
  {
    id: 'cand-002',
    name: 'Alex Rivera',
    codeName: 'Candidate #39F2',
    role: 'Frontend Technical Lead',
    email: 'alex.rivera@example.com',
    phone: '+1 (212) 554-9031',
    location: 'New York, NY (Remote)',
    regionZone: 'Zone 1 - East Coast Remote',
    experienceYears: 7,
    matchScore: 91,
    status: 'In Review',
    uploadDate: '2026-08-07',
    summary: 'Product-minded Frontend Engineer with deep expertise in React 19, TypeScript, Next.js, Web Vitals performance tuning, and Material 3 design systems.',
    technicalSkills: ['React', 'TypeScript', 'Tailwind CSS', 'Material Design 3', 'Next.js', 'GraphQL', 'Jest/RTL', 'Web Performance Optimization', 'Vite'],
    softSkills: ['UI/UX Design Alignment', 'Mentorship', 'Agile Architecture'],
    education: ['B.S. Software Engineering - Columbia University'],
    fileName: 'Alex_Rivera_Frontend_Lead_2026.docx',
    fileSize: '890 KB',
    strengths: [
      'Built design system component library adopted across 14 internal product teams',
      'Improved Core Web Vitals LCP from 3.8s to 0.9s for high-traffic enterprise app',
      'Strong Material Design 3 and accessibility (WCAG AA) mastery'
    ],
    missingKeywords: ['Micro-frontends', 'Module Federation'],
    biasMitigationScore: 97,
    aiOptimizationTip: 'Quantify design token system adoption impact across engineering departments.',

    detectedLanguage: 'en',
    ocrExtractedText: `ALEX RIVERA - FRONTEND TECHNICAL LEAD
Email: alex.rivera@example.com | Location: New York, NY
SUMMARY: Product-focused Frontend Lead with 7 years experience building React 19, TypeScript, and Material Design 3 applications.
EXPERIENCE:
- UI Scale Systems (2022 - Present): Frontend Tech Lead - Built Material Design 3 token system for 14 teams.
- Cloud Web Inc (2019 - 2022): Senior React Developer - Migrated legacy app to Next.js & TypeScript.`,

    portfolioLinks: [
      {
        platform: 'github',
        url: 'https://github.com/arivera-ui',
        status: 'verified',
        lastVerifiedTimestamp: '5 mins ago',
        repoCount: 31,
        topLanguages: ['TypeScript', 'CSS', 'HTML'],
        pinnedProjects: ['material3-react-tokens', 'web-vitals-profiler']
      },
      {
        platform: 'behance',
        url: 'https://behance.net/alexrivera-ui',
        status: 'verified',
        lastVerifiedTimestamp: '1 hour ago',
        thumbnailUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=300&auto=format&fit=crop'
      }
    ],

    careerGaps: [],

    companyHistory: [
      {
        id: 'comp-11',
        companyName: 'UI Scale Systems',
        roleTitle: 'Frontend Tech Lead',
        startDate: '2022-03',
        endDate: 'Present',
        tier: 'Tier 2 (Unicorn / Fortune 500)',
        criteriaTooltip: 'Tier 2: High-growth unicorn with large product scale.',
        durationMonths: 53
      },
      {
        id: 'comp-12',
        companyName: 'Cloud Web Inc',
        roleTitle: 'Senior React Developer',
        startDate: '2019-01',
        endDate: '2022-02',
        tier: 'Tier 3 (Established SMB)',
        criteriaTooltip: 'Tier 3: Established SaaS provider.',
        durationMonths: 38
      }
    ],

    blockchainCredentials: [
      {
        id: 'bc-11',
        title: 'B.S. Software Engineering - Columbia University',
        issuer: 'Columbia University Digital Verification',
        issuedDate: '2018-05-20',
        ledgerNetwork: 'Ethereum',
        txHash: '0x9d2e...11c4b82a',
        verificationStatus: 'verified',
        proofUrl: 'https://etherscan.io/tx/0x9d2e11c4'
      }
    ],

    inferredSoftSkills: [
      { id: 'ss-11', skillName: 'UI/UX Design Alignment', score: 96, aiConfidence: 97, resumeSnippet: 'Built Google Material 3 token system adopted across 14 internal engineering teams', validated: true },
      { id: 'ss-12', skillName: 'Mentorship', score: 89, aiConfidence: 92, resumeSnippet: 'Mentored 6 junior/mid-level frontend engineers on TypeScript best practices', validated: true }
    ],

    growthTrajectory: {
      promotionVelocityTag: 'Steady Progression',
      promotionVelocityColor: 'blue',
      averageTenureMonths: 45,
      industryAvgComparison: '+15% faster promotion rate than industry benchmark',
      titleChanges: [
        { title: 'Senior React Developer', year: '2019', company: 'Cloud Web Inc' },
        { title: 'Frontend Tech Lead', year: '2022', company: 'UI Scale Systems' }
      ]
    },

    techStackItems: [
      { id: 'ts-11', name: 'React 19 & Next.js', category: 'Modern/Emerging Stack', yearsExperience: 7, adoptionTrend: 'Up-to-Date', matchesJobReq: true },
      { id: 'ts-12', name: 'TypeScript & Vite', category: 'Modern/Emerging Stack', yearsExperience: 6, adoptionTrend: 'Up-to-Date', matchesJobReq: true },
      { id: 'ts-13', name: 'Material Design 3', category: 'Modern/Emerging Stack', yearsExperience: 4, adoptionTrend: 'Up-to-Date', matchesJobReq: true },
      { id: 'ts-14', name: 'jQuery', category: 'Foundational/Legacy', yearsExperience: 3, adoptionTrend: 'Legacy', matchesJobReq: false }
    ],

    fuzzySkillAlias: {
      standardizedRole: 'Frontend Engineering Lead',
      aliases: [
        { name: 'UI Systems Architect', confidence: 96, approved: true },
        { name: 'Web Applications Lead', confidence: 93, approved: true }
      ]
    },

    marketDemand: {
      marketDemandScore: 92,
      scarcityTags: [
        { skill: 'Material Design 3 Token Architect', tag: 'Surging Demand 📈', icon: 'trending_up' }
      ],
      marketAvailability: 'Medium',
      hiringVelocity: 'Fast',
      twelveMonthTrend: [70, 72, 75, 80, 85, 88, 90, 92, 91, 93, 92, 94]
    },

    peerBenchmarking: {
      targetRoleBaseline: 'Frontend Tech Lead Baseline',
      metrics: [
        { name: 'Technical Stack Alignment', candidateScore: 94, teamAvgScore: 82, variancePercentage: 14.6 },
        { name: 'Execution Speed / Velocity', candidateScore: 90, teamAvgScore: 83, variancePercentage: 8.4 },
        { name: 'Inferred Leadership Potential', candidateScore: 88, teamAvgScore: 80, variancePercentage: 10.0 }
      ]
    },

    careerPathProjection: [
      { stepIndex: 1, title: 'Frontend Technical Lead', estimatedYear: 'Current', isCurrent: true, requiredCertifications: ['Material Design 3 Specialist'], targetAspirations: ['Design Tokens Architecture'] },
      { stepIndex: 2, title: 'Principal User Experience Engineer', estimatedYear: 'Year 2 (2028)', isCurrent: false, requiredCertifications: ['Enterprise Micro-frontends'], targetAspirations: ['Design System Ecosystems'] },
      { stepIndex: 3, title: 'Director of UI / UX Engineering', estimatedYear: 'Year 5 (2031)', isCurrent: false, requiredCertifications: ['Executive Tech Leadership'], targetAspirations: ['Global Design Platforms'] }
    ],

    skillGaps: [
      {
        skillName: 'Micro-frontends Architecture',
        matched: false,
        severity: 'Critical Gap',
        suggestedCourse: {
          id: 'course-201',
          title: 'Enterprise Micro-frontends & Module Federation Mastery',
          platform: 'Coursera',
          durationHours: '16 hours',
          difficulty: 'Advanced',
          bridgesSkill: 'Micro-frontends Architecture',
          syllabusUrl: 'https://coursera.org',
          assigned: false
        }
      }
    ],

    commuteInfo: {
      workMode: 'Remote',
      commuteMinutes: 0,
      travelMode: 'Transit',
      exceedsThreshold: false
    },

    cultureFit: {
      cultureFitIndex: 91,
      matchedValues: [
        { candidatePhrasing: 'Accessibility & WCAG AA Commitment', corporateValue: 'Inclusive Product Standards', alignmentScore: 95 }
      ],
      sourceSnippets: ['"Championed accessibility guidelines across all design system components."'],
      interviewQuestions: ['How do you resolve conflict between strict designer specs and frontend performance budgets?']
    }
  }
];


export const initialJobListings: JobListing[] = [
  {
    id: 'job-101',
    title: 'Senior Staff AI / ML Engineer',
    department: 'Google Cloud AI & Research',
    location: 'San Francisco, CA / Remote',
    type: 'Hybrid',
    salaryRange: '$190,000 - $240,000 / yr',
    requiredSkills: ['Python', 'PyTorch', 'LLM Fine-Tuning', 'Transformer Models', 'Kubernetes', 'Google Cloud (Vertex AI)'],
    preferredSkills: ['C++', 'CUDA', 'Rust', 'ONNX Runtime'],
    experienceRequired: '7+ years',
    postedDate: '2026-08-01',
    description: 'We are seeking a Staff AI/ML Engineer to lead the architecture of next-generation LLM serving infrastructure and transformer model distillation pipelines.',
    applicantsCount: 42,
    matchedCandidatesCount: 8,
    status: 'Active',
    workMode: 'Hybrid',
    commuteTimeMinutes: 25,
    desirabilityScore: 95
  },
  {
    id: 'job-102',
    title: 'Frontend Technical Lead (Material 3 Specialist)',
    department: 'User Experience & Platforms',
    location: 'New York, NY / Remote',
    type: 'Remote',
    salaryRange: '$175,000 - $215,000 / yr',
    requiredSkills: ['React', 'TypeScript', 'Material Design 3', 'Tailwind CSS', 'Web Performance Optimization', 'Next.js'],
    preferredSkills: ['GraphQL', 'Micro-frontends', 'Web Vitals', 'Design Tokens'],
    experienceRequired: '6+ years',
    postedDate: '2026-08-03',
    description: 'Lead frontend engineering for enterprise AI tools. Architect responsive, accessible UI components following Google Material Design 3 guidelines.',
    applicantsCount: 68,
    matchedCandidatesCount: 12,
    status: 'Active',
    workMode: 'Remote',
    commuteTimeMinutes: 0,
    desirabilityScore: 92
  },
  {
    id: 'job-103',
    title: 'Cloud DevOps & Reliability Engineer',
    department: 'Infrastructure & Security',
    location: 'Seattle, WA',
    type: 'Full-time',
    salaryRange: '$160,000 - $200,000 / yr',
    requiredSkills: ['Terraform', 'Kubernetes', 'Docker', 'Google Cloud Platform', 'Prometheus/Grafana', 'Python'],
    preferredSkills: ['Go', 'Istio', 'ArgoCD', 'SOC2 Compliance'],
    experienceRequired: '5+ years',
    postedDate: '2026-08-04',
    description: 'Ensure 99.99% reliability across enterprise cloud deployments. Build automated IaC blueprints and continuous deployment pipelines on GCP.',
    applicantsCount: 31,
    matchedCandidatesCount: 6,
    status: 'Active',
    workMode: 'On-Site',
    commuteTimeMinutes: 45,
    desirabilityScore: 86
  },
  {
    id: 'job-104',
    title: 'Lead AI Product Manager',
    department: 'Product & Innovation',
    location: 'Austin, TX / Hybrid',
    type: 'Hybrid',
    salaryRange: '$180,000 - $225,000 / yr',
    requiredSkills: ['Product Strategy', 'SaaS Analytics', 'AI Product Roadmaps', 'SQL', 'A/B Testing'],
    preferredSkills: ['Product-Led Growth (PLG)', 'API Monetization', 'Figma'],
    experienceRequired: '8+ years',
    postedDate: '2026-08-02',
    description: 'Drive strategy and feature expansion for AI-powered workforce intelligence products. Partner closely with machine learning researchers and design leads.',
    applicantsCount: 54,
    matchedCandidatesCount: 5,
    status: 'Active',
    workMode: 'Hybrid',
    commuteTimeMinutes: 30,
    desirabilityScore: 90
  }
];

export const initialNotifications: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'High Match Alert (96%)',
    message: 'Maya Lin matched 96% with Senior Staff AI / ML Engineer position.',
    timestamp: '10 minutes ago',
    read: false,
    type: 'ai',
  },
  {
    id: 'notif-2',
    title: 'Resume Batch Processed',
    message: 'Successfully parsed and extracted skills for 5 new candidates with 0 errors.',
    timestamp: '1 hour ago',
    read: false,
    type: 'success',
  },
  {
    id: 'notif-3',
    title: 'Bias Audit Verified',
    message: 'Screening model passed 99.2% equity audit across anonymized profiles.',
    timestamp: '3 hours ago',
    read: true,
    type: 'info',
  },
];

export const initialSettings: SystemSettings = {
  skillWeight: 40,
  experienceWeight: 30,
  educationWeight: 15,
  keywordDensityWeight: 15,
  anonymizedScreening: false,
  autoShortlistThreshold: 85,
  autoRejectThreshold: 45,
  emailNotifications: true,
  modelName: 'gemini-3.6-flash',
};

// Preset Sample Resumes for Uploader & Demo
export const sampleResumes = [
  {
    name: 'Maya Lin - Senior ML Architect.pdf',
    text: `Name: Maya Lin
Role: Senior Staff AI/ML Engineer
Email: maya.lin@example.com
Phone: +1 (415) 892-0129
Location: San Francisco, CA

SUMMARY
Senior ML Engineer with 8 years of experience building scalable transformer architectures, fine-tuning LLMs on GCP Vertex AI, and deploying PyTorch inference pipelines in production. Published researcher with 3 papers at NeurIPS.

EXPERIENCE
Staff AI Engineer - Anthro AI (2023 - Present)
- Architected LLM serving infrastructure processing 50M+ daily tokens with PyTorch and vLLM.
- Reduced inference p99 latency by 42% through INT8 quantization and CUDA kernel optimization.
- Led team of 5 research engineers on multi-modal vision-language model training.

Senior ML Researcher - Tech Labs (2019 - 2023)
- Trained custom transformer models for document parsing and entity extraction.
- Developed automated model evaluation and hallucination detection suites in Python & TensorFlow.

SKILLS
Technical: PyTorch, TensorFlow, Python, LLM Fine-Tuning, Transformers, Kubernetes, Docker, Google Cloud (Vertex AI), C++, vLLM
Soft Skills: Technical Leadership, Research to Product Translation, Cross-functional Leadership
Education: M.S. Computer Science - Stanford University, B.S. Electrical Engineering - UC Berkeley`
  },
  {
    name: 'Alex Rivera - Frontend Tech Lead.docx',
    text: `Name: Alex Rivera
Role: Frontend Technical Lead
Email: alex.rivera@example.com
Phone: +1 (212) 554-9031
Location: New York, NY

SUMMARY
Product-focused Frontend Engineer with 7 years of experience crafting enterprise web applications using React 19, TypeScript, Tailwind CSS, and Material Design 3. Specialist in Web Vitals performance and UI component design systems.

EXPERIENCE
Frontend Tech Lead - UI Scale Systems (2022 - Present)
- Designed and built Google Material Design 3 token system adopted by 14 internal product engineering teams.
- Optimized core web application bundle size by 38% and achieved 100/100 Lighthouse performance score.
- Championed accessibility guidelines (WCAG 2.1 AA) across all design system components.

Senior React Developer - Cloud Web Inc (2019 - 2022)
- Built interactive analytics dashboards using React, Recharts, and WebSockets for real-time streaming.
- Migrated legacy codebase to TypeScript and Next.js, reducing production runtime errors by 65%.

SKILLS
Technical: React 19, TypeScript, Tailwind CSS, Material Design 3, Next.js, GraphQL, Jest, Web Performance, Vite, Redux Toolkit
Soft Skills: UI/UX Alignment, Mentorship, Agile Engineering
Education: B.S. Software Engineering - Columbia University`
  },
  {
    name: 'Jordan Vance - Cybersecurity & Cloud Specialist.pdf',
    text: `Name: Jordan Vance
Role: Principal Cybersecurity Architect
Email: jordan.vance@example.com
Phone: +1 (408) 991-2384
Location: San Jose, CA

SUMMARY
Cybersecurity Architect with 10 years experience securing cloud infrastructure, implementing zero-trust network access, SOC2 Type II compliance, and automated vulnerability remediation.

EXPERIENCE
Security Director - Fortress Cloud (2021 - Present)
- Designed zero-trust access control policy across AWS and GCP infrastructure serving 10M customers.
- Orchestrated automated threat detection pipelines using Python and Google Cloud Security Command Center.

SKILLS
Technical: Cloud Security, Zero Trust, GCP Security, AWS, SOC2, Python, Go, SIEM, Docker Security, Kubernetes Security
Soft Skills: Threat Modeling, Risk Management, Security Training
Education: M.S. Cybersecurity - Carnegie Mellon University`
  }
];
