import React, { useState } from 'react';
import { Candidate, JobListing, SystemMetrics, SystemSettings, TabType, NotificationItem, UserProfile } from './types';
import {
  initialCandidates,
  initialJobListings,
  initialMetrics,
  initialNotifications,
  initialSettings,
} from './data/mockData';
import { LoginPage } from './components/auth/LoginPage';
import { Sidebar } from './components/layout/Sidebar';
import { TopHeader } from './components/layout/TopHeader';
import { OverviewTab } from './components/dashboard/OverviewTab';
import { ResumeUploaderTab } from './components/dashboard/ResumeUploaderTab';
import { CandidateAnalyticsTab } from './components/dashboard/CandidateAnalyticsTab';
import { JobMatcherTab } from './components/dashboard/JobMatcherTab';
import { SystemSettingsTab } from './components/dashboard/SystemSettingsTab';
import { CandidateExperiencePortalPanel } from './components/dashboard/panels/CandidateExperiencePortalPanel';
import { RecruiterAutomationSuitePanel } from './components/dashboard/panels/RecruiterAutomationSuitePanel';
import { NextGenSecuritySuitePanel } from './components/dashboard/panels/NextGenSecuritySuitePanel';
import { AuditTrailLoggingPanel } from './components/dashboard/panels/AuditTrailLoggingPanel';
import { CandidateDetailModal } from './components/modals/CandidateDetailModal';
import { JobCreateModal } from './components/modals/JobCreateModal';
import { NotificationDrawer } from './components/modals/NotificationDrawer';
import { ShieldAlert, UserCheck, Briefcase, Sparkles, ArrowRight } from 'lucide-react';

export default function App() {
  // Authentication & Current User State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>({
    id: 'usr-recruiter-01',
    name: 'Sarah Chen',
    email: 'sarah.chen@hirestudio.ai',
    role: 'recruiter',
    title: 'Lead Talent Acquisition Manager',
    company: 'Hire Studio',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200'
  });

  // Main Navigation and Layout State
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [roleMode, setRoleMode] = useState<'recruiter' | 'candidate'>('recruiter');

  // Application Data State
  const [candidates, setCandidates] = useState<Candidate[]>(initialCandidates);
  const [jobListings, setJobListings] = useState<JobListing[]>(initialJobListings);
  const [metrics, setMetrics] = useState<SystemMetrics>(initialMetrics);
  const [settings, setSettings] = useState<SystemSettings>(initialSettings);
  const [notifications, setNotifications] = useState<NotificationItem[]>(initialNotifications);
  const [anonymizedMode, setAnonymizedMode] = useState<boolean>(false);

  // Modal Dialog Controls
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [isJobModalOpen, setIsJobModalOpen] = useState<boolean>(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState<boolean>(false);
  const [isParsing, setIsParsing] = useState<boolean>(false);

  // Auth Handlers
  const handleLogin = (user: UserProfile) => {
    setCurrentUser(user);
    const newRole = user.role === 'candidate' ? 'candidate' : 'recruiter';
    setRoleMode(newRole);
    setActiveTab(newRole === 'candidate' ? 'candidate_portal' : 'overview');
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  // Handlers
  const handleAddCandidate = (newCand: Candidate) => {
    setCandidates((prev) => [newCand, ...prev]);
    setMetrics((prev) => ({
      ...prev,
      totalProcessed: prev.totalProcessed + 1,
      pendingReviews: prev.pendingReviews + 1,
    }));

    // Add system notification
    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'New Resume Parsed',
      message: `${newCand.name} (${newCand.role}) parsed with ${newCand.matchScore}% match score.`,
      timestamp: 'Just now',
      read: false,
      type: 'ai',
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const handleUpdateCandidateStatus = (candidateId: string, status: Candidate['status']) => {
    setCandidates((prev) =>
      prev.map((c) => (c.id === candidateId ? { ...c, status } : c))
    );

    if (status === 'Shortlisted') {
      setMetrics((prev) => ({
        ...prev,
        pendingReviews: Math.max(0, prev.pendingReviews - 1),
      }));
    }
  };

  const handleAddJob = (newJob: JobListing) => {
    setJobListings((prev) => [newJob, ...prev]);
    setMetrics((prev) => ({
      ...prev,
      jobsRecommended: prev.jobsRecommended + 1,
    }));
  };

  const handleParseSampleResume = async (sampleText: string, sampleName: string) => {
    setIsParsing(true);
    try {
      const response = await fetch('/api/parse-resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resumeText: sampleText, fileName: sampleName }),
      });

      if (response.ok) {
        const data = await response.json();
        const parsedCand: Candidate = {
          id: `cand-${Date.now()}`,
          name: data.candidateName || 'Maya Lin (Parsed)',
          role: data.primaryRole || 'Staff AI Engineer',
          email: data.email || 'candidate@example.com',
          phone: data.phone || '+1 (415) 892-0129',
          location: data.location || 'San Francisco, CA',
          experienceYears: data.experienceYears || 8,
          matchScore: data.overallMatchScore || 96,
          status: 'Parsed',
          uploadDate: new Date().toISOString().split('T')[0],
          summary: data.summary || 'Senior AI specialist in PyTorch and GCP Vertex AI.',
          technicalSkills: data.technicalSkills || ['PyTorch', 'TensorFlow', 'LLM Fine-Tuning', 'Google Cloud', 'Kubernetes'],
          softSkills: data.softSkills || ['Leadership', 'Research'],
          education: data.education || ['M.S. Computer Science - Stanford'],
          fileName: sampleName,
          fileSize: '1.4 MB',
          strengths: data.strengths || ['Published researcher', 'Reduced p99 latency by 42%'],
          missingKeywords: data.missingKeywords || ['Rust'],
          biasMitigationScore: data.biasMitigationScore || 99,
          aiOptimizationTip: data.aiOptimizationTip || 'Add hardware optimization metrics.',
        };

        handleAddCandidate(parsedCand);
        setSelectedCandidate(parsedCand);
      }
    } catch (err) {
      console.error('Parse sample error:', err);
    } finally {
      setIsParsing(false);
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  // Render Login Screen if not authenticated
  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1F1F1F] flex font-sans selection:bg-[#E8F0FE] selection:text-[#1A73E8]">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
        pendingReviewsCount={metrics.pendingReviews}
        totalCandidatesCount={candidates.length}
        roleMode={roleMode}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      {/* Main App Container */}
      <div
        className={`flex-1 transition-all duration-300 ease-in-out flex flex-col min-w-0 ${
          sidebarCollapsed ? 'ml-20' : 'ml-64'
        }`}
      >
        {/* Top Header */}
        <TopHeader
          sidebarCollapsed={sidebarCollapsed}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          unreadNotificationsCount={unreadCount}
          onOpenNotifications={() => setIsNotificationOpen(true)}
          onOpenUploadModal={() => setActiveTab('parser')}
          onOpenJobCreateModal={() => setIsJobModalOpen(true)}
          roleMode={roleMode}
          setRoleMode={setRoleMode}
          setActiveTab={setActiveTab}
          currentUser={currentUser}
          onLogout={handleLogout}
        />

        {/* Main Content Area */}
        <main className="flex-1 mt-16 p-4 md:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
          
          {/* Mode Banner Indicator */}
          {roleMode === 'candidate' && (
            <div className="bg-gradient-to-r from-[#E6F4EA] via-[#F8F9FA] to-[#E8F0FE] border border-[#CEEAD6] p-4 rounded-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#34A853] text-white flex items-center justify-center shrink-0 font-bold shadow-xs">
                  <Briefcase className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-gray-900 text-sm">
                      Candidate Portal Active — {currentUser.name}
                    </span>
                    <span className="px-2 py-0.5 bg-[#34A853] text-white text-[10px] font-bold rounded-full">
                      APPLICANT VIEW
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mt-0.5">
                    Build AI resume, record voice intros, track status, & explore algorithmic matching score.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => setActiveTab('candidate_portal')}
                  className="px-3.5 py-1.5 bg-[#34A853] hover:bg-[#2d9248] text-white text-xs font-bold rounded-full transition-all flex items-center gap-1.5"
                >
                  <span>Candidate Hub</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setRoleMode('recruiter')}
                  className="px-3.5 py-1.5 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 text-xs font-bold rounded-full transition-all"
                >
                  Switch to Recruiter Mode
                </button>
              </div>
            </div>
          )}

          {activeTab === 'overview' && (
            <OverviewTab
              metrics={metrics}
              candidates={candidates}
              jobListings={jobListings}
              onSelectCandidate={(cand) => setSelectedCandidate(cand)}
              onSelectJob={() => setActiveTab('matcher')}
              setActiveTab={setActiveTab}
              onParseSampleResume={handleParseSampleResume}
              onOpenUploadModal={() => setActiveTab('parser')}
              isParsing={isParsing}
            />
          )}

          {activeTab === 'parser' && (
            <ResumeUploaderTab
              onAddCandidate={handleAddCandidate}
              jobListings={jobListings}
              onSelectCandidate={(cand) => setSelectedCandidate(cand)}
            />
          )}

          {activeTab === 'analytics' && (
            <CandidateAnalyticsTab
              candidates={candidates}
              onSelectCandidate={(cand) => setSelectedCandidate(cand)}
              onUpdateCandidateStatus={handleUpdateCandidateStatus}
              anonymizedMode={anonymizedMode}
              setAnonymizedMode={setAnonymizedMode}
            />
          )}

          {activeTab === 'matcher' && (
            <JobMatcherTab
              candidates={candidates}
              jobListings={jobListings}
              onSelectCandidate={(cand) => setSelectedCandidate(cand)}
              onUpdateCandidateStatus={handleUpdateCandidateStatus}
              onOpenJobCreateModal={() => setIsJobModalOpen(true)}
            />
          )}

          {activeTab === 'candidate_portal' && (
            <CandidateExperiencePortalPanel />
          )}

          {activeTab === 'recruiter_suite' && (
            roleMode === 'candidate' ? (
              <div className="bg-white rounded-3xl p-8 border border-[#E3E7EE] text-center space-y-4 max-w-2xl mx-auto my-8">
                <div className="w-16 h-16 rounded-full bg-[#FEF7E0] text-[#B06000] flex items-center justify-center mx-auto">
                  <ShieldAlert className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Recruiter Privileges Required</h3>
                <p className="text-sm text-gray-600">
                  Recruiter Automation Suite contains bulk candidate tiering, automated offer generation, and confidential recruiter controls. Switch to Recruiter Mode to access.
                </p>
                <button
                  onClick={() => setRoleMode('recruiter')}
                  className="px-6 py-2.5 bg-[#1A73E8] hover:bg-[#1557B0] text-white text-xs font-bold rounded-full shadow-sm transition-all"
                >
                  Switch to Recruiter Mode
                </button>
              </div>
            ) : (
              <RecruiterAutomationSuitePanel candidates={candidates} />
            )
          )}

          {activeTab === 'security_suite' && (
            <NextGenSecuritySuitePanel />
          )}

          {activeTab === 'audit_logs' && (
            <AuditTrailLoggingPanel />
          )}

          {activeTab === 'settings' && (
            <SystemSettingsTab
              settings={settings}
              onSaveSettings={(newSettings) => setSettings(newSettings)}
            />
          )}
        </main>
      </div>

      {/* Candidate Detail & AI Enhancer Modal */}
      {selectedCandidate && (
        <CandidateDetailModal
          candidate={selectedCandidate}
          onClose={() => setSelectedCandidate(null)}
          onUpdateStatus={handleUpdateCandidateStatus}
          jobListings={jobListings}
          anonymizedMode={anonymizedMode}
        />
      )}

      {/* Post Job Modal */}
      {isJobModalOpen && (
        <JobCreateModal
          onClose={() => setIsJobModalOpen(false)}
          onAddJob={handleAddJob}
        />
      )}

      {/* Notifications Drawer */}
      {isNotificationOpen && (
        <NotificationDrawer
          isOpen={isNotificationOpen}
          onClose={() => setIsNotificationOpen(false)}
          notifications={notifications}
          onMarkAllRead={() => setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))}
          onClearAll={() => setNotifications([])}
        />
      )}
    </div>
  );
}

