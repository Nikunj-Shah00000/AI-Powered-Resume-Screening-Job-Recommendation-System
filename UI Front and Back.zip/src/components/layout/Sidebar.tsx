import React from 'react';
import { TabType, UserProfile } from '../../types';
import {
  LayoutDashboard,
  FileText,
  BarChart3,
  Briefcase,
  Settings,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  UserCheck,
  Cpu,
  History,
  Lock,
  LogOut
} from 'lucide-react';

interface SidebarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
  pendingReviewsCount: number;
  totalCandidatesCount: number;
  roleMode: 'recruiter' | 'candidate';
  currentUser: UserProfile | null;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  collapsed,
  setCollapsed,
  pendingReviewsCount,
  totalCandidatesCount,
  roleMode,
  currentUser,
  onLogout,
}) => {
  const navItems = [
    {
      id: 'overview' as TabType,
      label: 'Dashboard Overview',
      icon: LayoutDashboard,
      badge: null,
      forRole: 'all',
    },
    {
      id: 'candidate_portal' as TabType,
      label: 'Candidate Portal',
      icon: UserCheck,
      badge: 'Candidate Hub',
      badgeColor: 'bg-[#E6F4EA] text-[#137333]',
      forRole: 'all',
    },
    {
      id: 'parser' as TabType,
      label: 'Resume Parser',
      icon: FileText,
      badge: pendingReviewsCount > 0 ? `${pendingReviewsCount} new` : null,
      badgeColor: 'bg-[#1A73E8] text-white',
      forRole: 'recruiter',
    },
    {
      id: 'analytics' as TabType,
      label: 'Candidate Analytics',
      icon: BarChart3,
      badge: `${totalCandidatesCount}`,
      badgeColor: 'bg-[#E8F0FE] text-[#1A73E8]',
      forRole: 'recruiter',
    },
    {
      id: 'matcher' as TabType,
      label: 'Job Matcher',
      icon: Briefcase,
      badge: 'Smart Match',
      badgeColor: 'bg-[#E6F4EA] text-[#137333]',
      forRole: 'all',
    },
    {
      id: 'recruiter_suite' as TabType,
      label: 'Recruiter Automation',
      icon: Cpu,
      badge: 'Auto Tier',
      badgeColor: 'bg-[#E8F0FE] text-[#1A73E8]',
      forRole: 'recruiter',
    },
    {
      id: 'security_suite' as TabType,
      label: 'Security & Next-Gen',
      icon: Lock,
      badge: 'ZKP & VR',
      badgeColor: 'bg-[#E6F4EA] text-[#137333]',
      forRole: 'recruiter',
    },
    {
      id: 'audit_logs' as TabType,
      label: 'Compliance Audit Logs',
      icon: History,
      badge: 'Ledger',
      badgeColor: 'bg-[#FEF7E0] text-[#B06000]',
      forRole: 'recruiter',
    },
    {
      id: 'settings' as TabType,
      label: 'System Settings',
      icon: Settings,
      badge: null,
      forRole: 'all',
    },
  ];

  return (
    <aside
      className={`fixed left-0 top-0 bottom-0 z-30 bg-white border-r border-[#E3E7EE] transition-all duration-300 ease-in-out flex flex-col ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Sidebar Header */}
      <div className="h-16 px-4 flex items-center justify-between border-b border-[#F1F3F4]">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1A73E8] via-[#4285F4] to-[#34A853] flex items-center justify-center text-white shadow-xs shrink-0">
            <Sparkles className="w-5 h-5 text-white animate-pulse" />
          </div>
          {!collapsed && (
            <div className="truncate">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-gray-900 text-base tracking-tight font-sans">
                  Hire Studio
                </span>
              </div>
              <p className="text-[11px] text-gray-500 font-medium truncate">
                {roleMode === 'recruiter' ? '🏢 Recruiter Workspace' : '💼 Candidate Workspace'}
              </p>
            </div>
          )}
        </div>

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-1.5 text-gray-500 hover:text-gray-900 hover:bg-[#F1F3F4] rounded-lg transition-colors hidden md:flex items-center justify-center shrink-0"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </button>
      </div>

      {/* Mode Status Pill */}
      {!collapsed && (
        <div className="px-3 pt-3 pb-1">
          <div className={`p-2.5 rounded-2xl border text-xs font-bold flex items-center justify-between ${
            roleMode === 'recruiter'
              ? 'bg-[#E8F0FE] border-[#D2E3FC] text-[#1A73E8]'
              : 'bg-[#E6F4EA] border-[#CEEAD6] text-[#137333]'
          }`}>
            <span className="flex items-center gap-1.5 truncate">
              {roleMode === 'recruiter' ? <UserCheck className="w-4 h-4" /> : <Briefcase className="w-4 h-4" />}
              <span>{roleMode === 'recruiter' ? 'Recruiter Mode' : 'Candidate Mode'}</span>
            </span>
            <span className="text-[10px] bg-white/80 px-2 py-0.5 rounded-full font-extrabold shadow-2xs">
              ACTIVE
            </span>
          </div>
        </div>
      )}

      {/* Navigation items */}
      <div className="flex-1 py-3 px-3 space-y-1.5 overflow-y-auto">
        {!collapsed && (
          <div className="px-3 pb-1 text-[11px] font-semibold tracking-wider text-gray-400 uppercase">
            {roleMode === 'recruiter' ? 'Recruiter Navigation' : 'Candidate Navigation'}
          </div>
        )}

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          const isRecruiterOnly = item.forRole === 'recruiter' && roleMode === 'candidate';

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-full transition-all text-sm font-medium relative group ${
                isActive
                  ? roleMode === 'recruiter'
                    ? 'bg-[#E8F0FE] text-[#1A73E8] font-bold shadow-2xs'
                    : 'bg-[#E6F4EA] text-[#137333] font-bold shadow-2xs'
                  : 'text-gray-700 hover:bg-[#F8F9FA] hover:text-gray-900'
              } ${isRecruiterOnly ? 'opacity-60' : ''}`}
              title={collapsed ? `${item.label}${isRecruiterOnly ? ' (Recruiter Only)' : ''}` : undefined}
            >
              <Icon className={`w-5 h-5 shrink-0 transition-colors ${
                isActive
                  ? roleMode === 'recruiter' ? 'text-[#1A73E8]' : 'text-[#34A853]'
                  : 'text-gray-500 group-hover:text-gray-700'
              }`} />

              {!collapsed && (
                <span className="truncate flex-1 text-left">{item.label}</span>
              )}

              {!collapsed && item.badge && (
                <span className={`text-[11px] px-2 py-0.5 rounded-full font-semibold ${item.badgeColor}`}>
                  {item.badge}
                </span>
              )}

              {collapsed && item.badge && (
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#1A73E8]" />
              )}
            </button>
          );
        })}
      </div>

      {/* Footer / User Session */}
      <div className="p-3 border-t border-[#F1F3F4] space-y-2">
        {!collapsed ? (
          <div className="bg-[#F8F9FA] border border-[#E8EAED] rounded-2xl p-3 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-gray-800 truncate">{currentUser?.name || 'User'}</span>
              <button
                onClick={onLogout}
                className="text-[#EA4335] hover:text-[#b3261e] p-1 rounded hover:bg-[#FCE8E6]"
                title="Log Out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-gray-500 text-[11px] truncate">{currentUser?.email || ''}</p>
            <div className="pt-2 border-t border-gray-200/60 flex items-center justify-between text-[11px] text-[#137333]">
              <span className="flex items-center gap-1 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#34A853]" /> Validated
              </span>
              <span className="text-gray-500">Gemini 3.6</span>
            </div>
          </div>
        ) : (
          <button
            onClick={onLogout}
            className="w-full flex justify-center p-2 text-[#EA4335] hover:bg-[#FCE8E6] rounded-xl transition-colors"
            title="Log Out / Switch Account"
          >
            <LogOut className="w-5 h-5" />
          </button>
        )}
      </div>
    </aside>
  );
};

