import React, { useState } from 'react';
import {
  Search,
  Bell,
  Upload,
  PlusCircle,
  User,
  SlidersHorizontal,
  ChevronDown,
  Sparkles,
  Briefcase,
  UserCheck,
  Building2,
  Check,
  LogOut,
  ShieldCheck
} from 'lucide-react';
import { TabType, UserProfile } from '../../types';

interface TopHeaderProps {
  sidebarCollapsed: boolean;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  unreadNotificationsCount: number;
  onOpenNotifications: () => void;
  onOpenUploadModal: () => void;
  onOpenJobCreateModal: () => void;
  roleMode: 'recruiter' | 'candidate';
  setRoleMode: (mode: 'recruiter' | 'candidate') => void;
  setActiveTab: (tab: TabType) => void;
  currentUser: UserProfile | null;
  onLogout: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  sidebarCollapsed,
  searchQuery,
  setSearchQuery,
  unreadNotificationsCount,
  onOpenNotifications,
  onOpenUploadModal,
  onOpenJobCreateModal,
  roleMode,
  setRoleMode,
  setActiveTab,
  currentUser,
  onLogout,
}) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const getInitials = (name?: string) => {
    if (!name) return 'US';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <header
      className={`fixed top-0 right-0 z-20 h-16 bg-white border-b border-[#E3E7EE] transition-all duration-300 ease-in-out flex items-center justify-between px-4 md:px-6 ${
        sidebarCollapsed ? 'left-20' : 'left-64'
      }`}
    >
      {/* Search Bar Container */}
      <div className="flex items-center gap-4 flex-1 max-w-xl">
        <div className="relative w-full">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              roleMode === 'candidate'
                ? "Search open roles, required skills (e.g. PyTorch, React)..."
                : "Search candidates, skills, or job requisitions..."
            }
            className="w-full pl-10 pr-10 py-2 bg-[#F1F3F4] hover:bg-[#E8EAED] focus:bg-white text-sm text-gray-900 rounded-full border border-transparent focus:border-[#1A73E8] focus:ring-2 focus:ring-[#E8F0FE] outline-none transition-all placeholder:text-gray-500 font-sans"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs text-gray-400 hover:text-gray-700"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Right Header Controls */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Role Toggle Switcher */}
        <div className="hidden lg:flex items-center bg-[#F1F3F4] p-1 rounded-full border border-[#E8EAED] text-xs font-medium">
          <button
            onClick={() => setRoleMode('recruiter')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all ${
              roleMode === 'recruiter'
                ? 'bg-white text-[#1A73E8] font-bold shadow-2xs'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-[#1A73E8]" />
            <span>Recruiter Mode</span>
          </button>
          <button
            onClick={() => {
              setRoleMode('candidate');
              setActiveTab('candidate_portal');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all ${
              roleMode === 'candidate'
                ? 'bg-white text-[#34A853] font-bold shadow-2xs'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5 text-[#34A853]" />
            <span>Candidate Mode</span>
          </button>
        </div>

        {/* Action Buttons */}
        {roleMode === 'recruiter' ? (
          <>
            <button
              onClick={onOpenUploadModal}
              className="flex items-center gap-2 px-3.5 py-2 bg-[#1A73E8] hover:bg-[#1557B0] text-white text-xs md:text-sm font-bold rounded-full shadow-2xs transition-all active:scale-98"
            >
              <Upload className="w-4 h-4" />
              <span className="hidden sm:inline">Upload Resume</span>
            </button>

            <button
              onClick={onOpenJobCreateModal}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-[#E8F0FE] hover:bg-[#D2E3FC] text-[#1A73E8] text-xs md:text-sm font-bold rounded-full transition-all"
              title="Post new job position"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Post Job</span>
            </button>
          </>
        ) : (
          <button
            onClick={() => setActiveTab('candidate_portal')}
            className="flex items-center gap-2 px-3.5 py-2 bg-[#34A853] hover:bg-[#2d9248] text-white text-xs md:text-sm font-bold rounded-full shadow-2xs transition-all"
          >
            <Briefcase className="w-4 h-4" />
            <span>My Candidate Hub</span>
          </button>
        )}

        {/* Notification Bell */}
        <button
          onClick={onOpenNotifications}
          className="p-2 text-gray-600 hover:text-gray-900 hover:bg-[#F1F3F4] rounded-full transition-colors relative"
          title="Notifications"
        >
          <Bell className="w-5 h-5" />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 bg-[#EA4335] text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
              {unreadNotificationsCount}
            </span>
          )}
        </button>

        {/* User Profile Menu */}
        <div className="relative">
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center gap-2 p-1.5 hover:bg-[#F1F3F4] rounded-full transition-colors"
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-2xs ${
              roleMode === 'recruiter' ? 'bg-gradient-to-tr from-[#1A73E8] to-[#1557B0]' : 'bg-gradient-to-tr from-[#34A853] to-[#137333]'
            }`}>
              {getInitials(currentUser?.name)}
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-gray-500 hidden md:block" />
          </button>

          {showProfileMenu && (
            <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-[#E3E7EE] py-2 z-50 text-xs">
              <div className="px-4 py-3 border-b border-[#F1F3F4] space-y-1">
                <p className="font-bold text-gray-900 text-sm">{currentUser?.name || 'User Profile'}</p>
                <p className="text-gray-500 text-xs truncate">{currentUser?.email || 'user@hirestudio.ai'}</p>
                <div className="flex items-center gap-2 pt-1">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                    roleMode === 'recruiter' ? 'bg-[#E8F0FE] text-[#1A73E8]' : 'bg-[#E6F4EA] text-[#137333]'
                  }`}>
                    {roleMode === 'recruiter' ? '🏢 Recruiter Mode' : '💼 Candidate Mode'}
                  </span>
                  <span className="text-[10px] text-gray-400 font-mono truncate">{currentUser?.company || 'Hire Studio'}</span>
                </div>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    setRoleMode('recruiter');
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-4 py-2 hover:bg-[#F8F9FA] flex items-center justify-between text-gray-700"
                >
                  <span className="flex items-center gap-2 font-medium">
                    <UserCheck className="w-4 h-4 text-[#1A73E8]" /> Switch to Recruiter Workspace
                  </span>
                  {roleMode === 'recruiter' && <Check className="w-3.5 h-3.5 text-[#1A73E8]" />}
                </button>

                <button
                  onClick={() => {
                    setRoleMode('candidate');
                    setActiveTab('candidate_portal');
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-4 py-2 hover:bg-[#F8F9FA] flex items-center justify-between text-gray-700"
                >
                  <span className="flex items-center gap-2 font-medium">
                    <Building2 className="w-4 h-4 text-[#34A853]" /> Switch to Candidate Portal
                  </span>
                  {roleMode === 'candidate' && <Check className="w-3.5 h-3.5 text-[#34A853]" />}
                </button>

                <button
                  onClick={() => {
                    setActiveTab('settings');
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-4 py-2 hover:bg-[#F8F9FA] flex items-center gap-2 text-gray-700 font-medium"
                >
                  <SlidersHorizontal className="w-4 h-4 text-gray-500" /> Model Settings & Preferences
                </button>
              </div>

              <div className="pt-1 border-t border-[#F1F3F4]">
                <button
                  onClick={() => {
                    setShowProfileMenu(false);
                    onLogout();
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-[#FCE8E6] text-[#EA4335] flex items-center gap-2 font-bold transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Log Out / Switch Account</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

