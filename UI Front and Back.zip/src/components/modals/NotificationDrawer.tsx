import React from 'react';
import { NotificationItem } from '../../types';
import { X, Bell, Sparkles, CheckCircle2, AlertCircle, Check, Trash2 } from 'lucide-react';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
  onClearAll: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead,
  onClearAll,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-2xs flex justify-end">
      <div className="bg-white w-full max-w-sm h-full border-l border-[#E3E7EE] shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-[#F1F3F4] flex items-center justify-between bg-[#F8F9FA]">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-[#1A73E8]" />
            <h3 className="font-bold text-gray-900 text-sm font-sans">Notification Center</h3>
          </div>

          <button onClick={onClose} className="p-1 text-gray-400 hover:text-gray-700 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action controls */}
        <div className="p-3 border-b border-[#F1F3F4] flex items-center justify-between text-xs text-gray-500 bg-white">
          <button onClick={onMarkAllRead} className="hover:text-[#1A73E8] flex items-center gap-1 font-medium">
            <Check className="w-3.5 h-3.5" /> Mark all as read
          </button>
          <button onClick={onClearAll} className="hover:text-red-600 flex items-center gap-1">
            <Trash2 className="w-3.5 h-3.5" /> Clear all
          </button>
        </div>

        {/* Notifications list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-gray-400 text-xs">
              No new notifications.
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                className={`p-3.5 rounded-xl border transition-all text-xs space-y-1 ${
                  notif.read ? 'bg-[#F8F9FA] border-[#E3E7EE]' : 'bg-[#E8F0FE]/40 border-[#1A73E8]/30 font-medium'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-gray-900 flex items-center gap-1.5">
                    {notif.type === 'ai' && <Sparkles className="w-3.5 h-3.5 text-amber-500" />}
                    {notif.type === 'success' && <CheckCircle2 className="w-3.5 h-3.5 text-[#34A853]" />}
                    {notif.title}
                  </span>
                  <span className="text-[10px] text-gray-400">{notif.timestamp}</span>
                </div>
                <p className="text-gray-600 text-[11px] leading-relaxed">{notif.message}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
