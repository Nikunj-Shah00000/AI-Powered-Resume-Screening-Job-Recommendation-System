import React, { useState } from 'react';
import { Candidate, JobListing } from '../../types';
import { SkillGraphPanel } from '../dashboard/panels/SkillGraphPanel';
import { PortfolioVerificationPanel } from '../dashboard/panels/PortfolioVerificationPanel';
import { SoftSkillInferencePanel } from '../dashboard/panels/SoftSkillInferencePanel';
import { CareerGapTimelinePanel } from '../dashboard/panels/CareerGapTimelinePanel';
import { CompanyTierPanel } from '../dashboard/panels/CompanyTierPanel';
import { BlockchainVerificationPanel } from '../dashboard/panels/BlockchainVerificationPanel';
import { CultureFitPanel } from '../dashboard/panels/CultureFitPanel';
import {
  X,
  Star,
  CheckCircle2,
  XCircle,
  FileText,
  Sparkles,
  Tag,
  BookOpen,
  Award,
  Zap,
  RefreshCw,
  Send,
  Building,
  Check,
  Briefcase,
  Layers,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';

interface CandidateDetailModalProps {
  candidate: Candidate;
  onClose: () => void;
  onUpdateStatus: (candidateId: string, status: Candidate['status']) => void;
  jobListings: JobListing[];
  anonymizedMode: boolean;
}

export const CandidateDetailModal: React.FC<CandidateDetailModalProps> = ({
  candidate,
  onClose,
  onUpdateStatus,
  jobListings,
  anonymizedMode,
}) => {
  const [activeTab, setActiveTab] = useState<'details' | 'enhancer' | 'matrix'>('details');
  const [targetJobTitle, setTargetJobTitle] = useState<string>(jobListings[0]?.title || 'Staff AI Engineer');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhancements, setEnhancements] = useState<any>(null);

  const handleRunEnhance = async () => {
    setIsEnhancing(true);
    try {
      const response = await fetch('/api/enhance-resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          candidateProfile: candidate,
          targetJobTitle: targetJobTitle,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setEnhancements(data);
      }
    } catch (err) {
      console.error('Enhancer error:', err);
    } finally {
      setIsEnhancing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full border border-[#E3E7EE] shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Top Header */}
        <div className="p-6 bg-gradient-to-r from-white via-[#F8F9FA] to-[#E8F0FE] border-b border-[#E3E7EE] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#E8F0FE] text-[#1A73E8] font-bold text-lg flex items-center justify-center shrink-0">
              {anonymizedMode ? 'C' : candidate.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-gray-900 font-sans tracking-tight">
                  {anonymizedMode ? `Candidate #${candidate.id.split('-')[1]}` : candidate.name}
                </h2>
                <span className="text-xs bg-[#E6F4EA] text-[#137333] font-bold px-2.5 py-0.5 rounded-full">
                  {candidate.matchScore}% Match
                </span>
              </div>
              <p className="text-xs text-gray-500 font-medium">{candidate.role} • {candidate.location}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex items-center px-6 border-b border-[#F1F3F4] text-xs font-medium bg-[#F8F9FA]">
          <button
            onClick={() => setActiveTab('details')}
            className={`py-3 px-4 border-b-2 transition-all ${
              activeTab === 'details'
                ? 'border-[#1A73E8] text-[#1A73E8] font-bold'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Parsed Resume & Skills
          </button>
          <button
            onClick={() => {
              setActiveTab('enhancer');
              if (!enhancements) handleRunEnhance();
            }}
            className={`py-3 px-4 border-b-2 transition-all flex items-center gap-1.5 ${
              activeTab === 'enhancer'
                ? 'border-[#1A73E8] text-[#1A73E8] font-bold'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" /> AI Resume Optimizer
          </button>
          <button
            onClick={() => setActiveTab('matrix')}
            className={`py-3 px-4 border-b-2 transition-all ${
              activeTab === 'matrix'
                ? 'border-[#1A73E8] text-[#1A73E8] font-bold'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            Job Match Matrix
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 max-h-[65vh] overflow-y-auto space-y-5 text-xs">
          {activeTab === 'details' && (
            <div className="space-y-4">
              {/* Summary Box */}
              <div>
                <h4 className="font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                  Professional Executive Summary
                </h4>
                <p className="p-3.5 rounded-xl bg-[#F8F9FA] border border-[#E8EAED] text-gray-700 leading-relaxed">
                  {candidate.summary}
                </p>
              </div>

              {/* Skills Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-bold text-gray-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5 text-[#1A73E8]" /> Extracted Technical Skills
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {candidate.technicalSkills.map((sk, idx) => (
                      <span key={idx} className="bg-[#E8F0FE] text-[#1A73E8] font-medium px-2.5 py-1 rounded-full">
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-gray-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-[#34A853]" /> Strengths & Highlights
                  </h4>
                  <ul className="space-y-1.5 text-gray-700">
                    {candidate.strengths.map((str, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <Check className="w-3.5 h-3.5 text-[#34A853] shrink-0 mt-0.5" />
                        <span>{str}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Education & Missing Keywords */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-bold text-gray-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-[#1A73E8]" /> Education History
                  </h4>
                  <ul className="space-y-1 text-gray-700">
                    {candidate.education.map((edu, idx) => (
                      <li key={idx} className="bg-[#F8F9FA] p-2 rounded-lg border border-[#E3E7EE]">
                        {edu}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold text-gray-700 uppercase tracking-wider mb-2 text-amber-800">
                    Missing Target Keywords
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {candidate.missingKeywords.map((kw, idx) => (
                      <span key={idx} className="bg-amber-100 text-amber-800 font-medium px-2.5 py-1 rounded-md">
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Integrated Feature Panels */}
              <div className="space-y-4 pt-4 border-t border-[#E3E7EE]">
                <SkillGraphPanel candidate={candidate} />
                <CompanyTierPanel candidate={candidate} />
                <PortfolioVerificationPanel candidate={candidate} />
                <SoftSkillInferencePanel candidate={candidate} />
                <CareerGapTimelinePanel candidate={candidate} />
                <CultureFitPanel candidate={candidate} />
                <BlockchainVerificationPanel candidate={candidate} />
              </div>
            </div>
          )}

          {activeTab === 'enhancer' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-[#E8F0FE] p-3 rounded-xl">
                <span className="font-semibold text-[#1A73E8]">Target Position for AI Tailoring:</span>
                <select
                  value={targetJobTitle}
                  onChange={(e) => setTargetJobTitle(e.target.value)}
                  className="px-3 py-1 bg-white border border-[#1A73E8]/40 rounded-lg text-xs font-medium outline-none"
                >
                  {jobListings.map((job) => (
                    <option key={job.id} value={job.title}>
                      {job.title}
                    </option>
                  ))}
                </select>
              </div>

              {isEnhancing ? (
                <div className="p-8 text-center space-y-2">
                  <RefreshCw className="w-6 h-6 animate-spin text-[#1A73E8] mx-auto" />
                  <p className="font-bold text-gray-800">Gemini 3.6 Generating Tailored Resume Advice...</p>
                </div>
              ) : enhancements ? (
                <div className="space-y-4">
                  <div className="p-3.5 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200">
                    <span className="font-bold text-blue-900 block mb-1">Suggested Headline Booster:</span>
                    <p className="font-bold text-gray-900">{enhancements.tailoredHeadline}</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-700 uppercase tracking-wider mb-2">
                      High-Impact Accomplishment Bullet Points:
                    </h4>
                    <ul className="space-y-2">
                      {enhancements.suggestedBullets?.map((bullet: string, i: number) => (
                        <li key={i} className="p-2.5 rounded-lg bg-[#F8F9FA] border border-[#E3E7EE] text-gray-800 flex items-start gap-2">
                          <Zap className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                          <span>{bullet}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#E6F4EA] border border-[#34A853]/30">
                    <span className="font-bold text-[#137333] block mb-1">Strategic Keyword Boosters:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {enhancements.keywordBoosters?.map((kw: string, i: number) => (
                        <span key={i} className="bg-white text-[#137333] font-bold text-[11px] px-2.5 py-0.5 rounded-full shadow-2xs">
                          +{kw}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
          )}

          {activeTab === 'matrix' && (
            <div className="space-y-3">
              <h4 className="font-bold text-gray-700 uppercase tracking-wider">
                Cross-Job Compatibility Breakdown
              </h4>
              <div className="space-y-2.5">
                {jobListings.map((job) => {
                  const score = Math.min(98, candidate.matchScore + (job.id === 'job-101' ? 0 : -5));
                  return (
                    <div key={job.id} className="p-3.5 rounded-xl border border-[#E3E7EE] bg-[#F8F9FA] flex items-center justify-between">
                      <div>
                        <h5 className="font-bold text-gray-900">{job.title}</h5>
                        <p className="text-[11px] text-gray-500">{job.department} • {job.location}</p>
                      </div>

                      <div className="text-right">
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#E6F4EA] text-[#137333] font-bold text-xs">
                          {score}% Match
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Action Bar */}
        <div className="p-4 bg-[#F8F9FA] border-t border-[#E3E7EE] flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-gray-500 text-xs">Recruiter Action:</span>
            <span className="font-bold text-gray-800 text-xs">{candidate.status}</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={() => {
                onUpdateStatus(candidate.id, 'Shortlisted');
                onClose();
              }}
              className="px-4 py-2 bg-[#137333] hover:bg-[#0d5023] text-white font-bold text-xs rounded-full shadow-2xs transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" /> Shortlist Candidate
            </button>

            <button
              onClick={() => {
                onUpdateStatus(candidate.id, 'Rejected');
                onClose();
              }}
              className="px-4 py-2 bg-[#FCE8E6] hover:bg-[#FAD2CF] text-[#C5221F] font-bold text-xs rounded-full transition-all"
            >
              Reject
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
