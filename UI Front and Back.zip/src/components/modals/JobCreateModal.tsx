import React, { useState } from 'react';
import { JobListing } from '../../types';
import { X, Briefcase, Plus, Sparkles, Building, MapPin, DollarSign, Check } from 'lucide-react';

interface JobCreateModalProps {
  onClose: () => void;
  onAddJob: (job: JobListing) => void;
}

export const JobCreateModal: React.FC<JobCreateModalProps> = ({ onClose, onAddJob }) => {
  const [title, setTitle] = useState('');
  const [department, setDepartment] = useState('Google Cloud AI');
  const [location, setLocation] = useState('San Francisco, CA / Remote');
  const [type, setType] = useState<JobListing['type']>('Hybrid');
  const [salaryRange, setSalaryRange] = useState('$170,000 - $210,000 / yr');
  const [requiredSkills, setRequiredSkills] = useState('React, TypeScript, Tailwind CSS, Material 3, Node.js');
  const [experienceRequired, setExperienceRequired] = useState('5+ years');
  const [description, setDescription] = useState('We are looking for an experienced software professional to build high-performance user interfaces and backend integrations.');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newJob: JobListing = {
      id: `job-${Date.now()}`,
      title,
      department,
      location,
      type,
      salaryRange,
      requiredSkills: requiredSkills.split(',').map((s) => s.trim()).filter(Boolean),
      preferredSkills: ['GraphQL', 'Kubernetes'],
      experienceRequired,
      postedDate: new Date().toISOString().split('T')[0],
      description,
      applicantsCount: 1,
      matchedCandidatesCount: 4,
      status: 'Active',
    };

    onAddJob(newJob);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full border border-[#E3E7EE] shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        <div className="p-6 bg-gradient-to-r from-white via-[#F8F9FA] to-[#E8F0FE] border-b border-[#E3E7EE] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1A73E8] text-white flex items-center justify-center">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900 font-sans">Post New Job Position</h2>
              <p className="text-xs text-gray-500">Add job specifications to trigger AI candidate matching</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-gray-700 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-bold text-gray-700 uppercase tracking-wider mb-1">
              Job Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Senior Staff AI Engineer"
              className="w-full p-2.5 bg-[#F8F9FA] border border-[#E3E7EE] focus:border-[#1A73E8] rounded-xl outline-none font-medium"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-gray-700 uppercase tracking-wider mb-1">
                Department
              </label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full p-2.5 bg-[#F8F9FA] border border-[#E3E7EE] focus:border-[#1A73E8] rounded-xl outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 uppercase tracking-wider mb-1">
                Work Type
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full p-2.5 bg-[#F8F9FA] border border-[#E3E7EE] focus:border-[#1A73E8] rounded-xl outline-none"
              >
                <option value="Hybrid">Hybrid</option>
                <option value="Remote">Remote</option>
                <option value="Full-time">Full-time</option>
                <option value="Contract">Contract</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-gray-700 uppercase tracking-wider mb-1">
                Location
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full p-2.5 bg-[#F8F9FA] border border-[#E3E7EE] focus:border-[#1A73E8] rounded-xl outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-gray-700 uppercase tracking-wider mb-1">
                Salary Range
              </label>
              <input
                type="text"
                value={salaryRange}
                onChange={(e) => setSalaryRange(e.target.value)}
                className="w-full p-2.5 bg-[#F8F9FA] border border-[#E3E7EE] focus:border-[#1A73E8] rounded-xl outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-gray-700 uppercase tracking-wider mb-1">
              Required Technical Skill Keywords (Comma Separated)
            </label>
            <input
              type="text"
              value={requiredSkills}
              onChange={(e) => setRequiredSkills(e.target.value)}
              placeholder="e.g. PyTorch, React, TypeScript, Docker"
              className="w-full p-2.5 bg-[#F8F9FA] border border-[#E3E7EE] focus:border-[#1A73E8] rounded-xl outline-none"
            />
          </div>

          <div>
            <label className="block font-bold text-gray-700 uppercase tracking-wider mb-1">
              Job Description Overview
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 bg-[#F8F9FA] border border-[#E3E7EE] focus:border-[#1A73E8] rounded-xl outline-none"
            />
          </div>

          <div className="pt-3 border-t border-[#F1F3F4] flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#F1F3F4] text-gray-700 font-medium rounded-full"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#1A73E8] hover:bg-[#1557B0] text-white font-bold rounded-full shadow-2xs transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Publish Position
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
