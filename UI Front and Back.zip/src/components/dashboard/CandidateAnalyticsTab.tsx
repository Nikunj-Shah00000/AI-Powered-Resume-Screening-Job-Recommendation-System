import React, { useState, useMemo } from 'react';
import { Candidate } from '../../types';
import { SkillGraphPanel } from './panels/SkillGraphPanel';
import { PortfolioVerificationPanel } from './panels/PortfolioVerificationPanel';
import { CompanyTierPanel } from './panels/CompanyTierPanel';
import { GrowthTrajectoryPanel } from './panels/GrowthTrajectoryPanel';
import { TechStackEvolutionPanel } from './panels/TechStackEvolutionPanel';
import { PeerBenchmarkingPanel } from './panels/PeerBenchmarkingPanel';
import { SoftSkillInferencePanel } from './panels/SoftSkillInferencePanel';
import { CareerGapTimelinePanel } from './panels/CareerGapTimelinePanel';
import { BlockchainVerificationPanel } from './panels/BlockchainVerificationPanel';
import { BlindScreeningController } from './panels/BlindScreeningController';
import { CustomWeightSlidersPanel } from './panels/CustomWeightSlidersPanel';
import { DynamicThresholdingPanel } from './panels/DynamicThresholdingPanel';
import { UniversityDebiasingPanel } from './panels/UniversityDebiasingPanel';
import { ProxyVariableRedactionPanel } from './panels/ProxyVariableRedactionPanel';
import { AdversarialDebiasingPanel } from './panels/AdversarialDebiasingPanel';
import { XaiMatchJustificationPanel } from './panels/XaiMatchJustificationPanel';
import { FairnessMetricDashboardPanel } from './panels/FairnessMetricDashboardPanel';
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import {
  Search,
  Filter,
  Eye,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Award,
  Users,
  BarChart2,
  SlidersHorizontal,
  ChevronDown,
  Sparkles,
  ArrowUpDown
} from 'lucide-react';

interface CandidateAnalyticsTabProps {
  candidates: Candidate[];
  onSelectCandidate: (candidate: Candidate) => void;
  onUpdateCandidateStatus: (candidateId: string, status: Candidate['status']) => void;
  anonymizedMode: boolean;
  setAnonymizedMode: (anonymized: boolean) => void;
}

export const CandidateAnalyticsTab: React.FC<CandidateAnalyticsTabProps> = ({
  candidates,
  onSelectCandidate,
  onUpdateCandidateStatus,
  anonymizedMode,
  setAnonymizedMode,
}) => {
  const [filterRole, setFilterRole] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [sortField, setSortField] = useState<'matchScore' | 'experienceYears'>('matchScore');

  // Compute Skill Frequency Distribution for Radar Chart
  const skillDistributionData = useMemo(() => {
    const counts: Record<string, number> = {
      'TypeScript': 0,
      'React': 0,
      'Python': 0,
      'PyTorch': 0,
      'Kubernetes': 0,
      'Docker': 0,
      'Product Strategy': 0,
      'GCP / AWS': 0,
    };

    candidates.forEach((c) => {
      c.technicalSkills.forEach((s) => {
        if (s.includes('TypeScript')) counts['TypeScript']++;
        if (s.includes('React')) counts['React']++;
        if (s.includes('Python')) counts['Python']++;
        if (s.includes('PyTorch') || s.includes('TensorFlow')) counts['PyTorch']++;
        if (s.includes('Kubernetes')) counts['Kubernetes']++;
        if (s.includes('Docker')) counts['Docker']++;
        if (s.includes('Product') || s.includes('Analytics')) counts['Product Strategy']++;
        if (s.includes('Google Cloud') || s.includes('GCP') || s.includes('AWS')) counts['GCP / AWS']++;
      });
    });

    return Object.keys(counts).map((key) => ({
      skill: key,
      candidatesCount: counts[key],
      fullMark: candidates.length,
    }));
  }, [candidates]);

  // Compute Match Score Histogram Data
  const matchScoreHistogram = useMemo(() => {
    let high = 0; // 90-100
    let good = 0; // 80-89
    let moderate = 0; // 70-79
    let low = 0; // <70

    candidates.forEach((c) => {
      if (c.matchScore >= 90) high++;
      else if (c.matchScore >= 80) good++;
      else if (c.matchScore >= 70) moderate++;
      else low++;
    });

    return [
      { category: '90-100% Match', count: high, fill: '#34A853' },
      { category: '80-89% Match', count: good, fill: '#1A73E8' },
      { category: '70-79% Match', count: moderate, fill: '#FBBC04' },
      { category: '<70% Match', count: low, fill: '#EA4335' },
    ];
  }, [candidates]);

  // Compute Candidate Status Pie Data
  const statusPieData = useMemo(() => {
    const counts: Record<string, number> = {
      Shortlisted: 0,
      'In Review': 0,
      Parsed: 0,
      'Interview Scheduled': 0,
      Rejected: 0,
    };

    candidates.forEach((c) => {
      counts[c.status] = (counts[c.status] || 0) + 1;
    });

    const COLORS: Record<string, string> = {
      Shortlisted: '#34A853',
      'In Review': '#1A73E8',
      Parsed: '#4285F4',
      'Interview Scheduled': '#FBBC04',
      Rejected: '#EA4335',
    };

    return Object.keys(counts)
      .filter((k) => counts[k] > 0)
      .map((k) => ({
        name: k,
        value: counts[k],
        color: COLORS[k] || '#8884d8',
      }));
  }, [candidates]);

  // Filtered and Sorted Candidates
  const filteredCandidates = useMemo(() => {
    return candidates
      .filter((c) => {
        const matchesRole = filterRole === 'All' || c.role.toLowerCase().includes(filterRole.toLowerCase());
        const matchesStatus = filterStatus === 'All' || c.status === filterStatus;
        const matchesSearch =
          !searchFilter ||
          c.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
          c.role.toLowerCase().includes(searchFilter.toLowerCase()) ||
          c.technicalSkills.some((s) => s.toLowerCase().includes(searchFilter.toLowerCase()));
        return matchesRole && matchesStatus && matchesSearch;
      })
      .sort((a, b) => b[sortField] - a[sortField]);
  }, [candidates, filterRole, filterStatus, searchFilter, sortField]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-[#E3E7EE] shadow-2xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E8F0FE] text-[#1A73E8] text-xs font-semibold mb-2">
            <BarChart2 className="w-3.5 h-3.5" /> AI Candidate Analytics
          </div>
          <h1 className="text-xl font-bold text-gray-900 font-sans tracking-tight">
            Skill Distribution & Candidate Intelligence Analytics
          </h1>
          <p className="text-xs text-gray-500 mt-1">
            Aggregate skill matrix visualization, graph-based skill extraction, and bias-free screening.
          </p>
        </div>
      </div>

      {/* Blind Screening Controller Bar */}
      <BlindScreeningController
        anonymizedMode={anonymizedMode}
        setAnonymizedMode={setAnonymizedMode}
      />

      {/* Algorithmic Tuning & Debiasing Control Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CustomWeightSlidersPanel />
        <DynamicThresholdingPanel />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <UniversityDebiasingPanel />
        <ProxyVariableRedactionPanel />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AdversarialDebiasingPanel />
        <XaiMatchJustificationPanel candidate={candidates[0]} />
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Radar Chart: Skill Matrix (5 cols) */}
        <div className="lg:col-span-5 m3-card p-5 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#F1F3F4]">
            <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2">
              <Award className="w-4 h-4 text-[#1A73E8]" /> Skill Pool Distribution
            </h3>
            <span className="text-[11px] text-gray-400">Candidate Frequency</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="75%" data={skillDistributionData}>
                <PolarGrid stroke="#E0E0E0" />
                <PolarAngleAxis dataKey="skill" tick={{ fill: '#5F6368', fontSize: 11 }} />
                <PolarRadiusAxis angle={30} domain={[0, candidates.length]} />
                <Radar
                  name="Candidates"
                  dataKey="candidatesCount"
                  stroke="#1A73E8"
                  fill="#1A73E8"
                  fillOpacity={0.35}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bar Chart: Match Score Histogram (4 cols) */}
        <div className="lg:col-span-4 m3-card p-5 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#F1F3F4]">
            <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-[#34A853]" /> Match Score Range
            </h3>
            <span className="text-[11px] text-gray-400">Total Pool</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={matchScoreHistogram} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="category" tick={{ fill: '#5F6368', fontSize: 10 }} />
                <YAxis allowDecimals={false} tick={{ fill: '#5F6368', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', borderColor: '#E3E7EE', fontSize: '12px' }}
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Donut Chart: Candidate Status (3 cols) */}
        <div className="lg:col-span-3 m3-card p-5 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#F1F3F4]">
            <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-[#FBBC04]" /> Status Breakdown
            </h3>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {statusPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', fontSize: '12px' }}
                />
                <Legend iconSize={8} wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Candidate Data Table Section */}
      <div className="m3-card p-6 space-y-4">
        {/* Table Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#F1F3F4]">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-[#1A73E8]" />
            <h2 className="text-base font-bold text-gray-900">
              Candidate Screening Directory ({filteredCandidates.length})
            </h2>
          </div>

          {/* Table Filters */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Search */}
            <div className="relative">
              <input
                type="text"
                placeholder="Filter by skill, name..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="pl-8 pr-3 py-1.5 bg-[#F8F9FA] border border-[#E3E7EE] focus:border-[#1A73E8] rounded-full text-xs outline-none"
              />
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2" />
            </div>

            {/* Status Filter */}
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-1.5 bg-[#F8F9FA] border border-[#E3E7EE] rounded-full text-xs outline-none"
            >
              <option value="All">All Statuses</option>
              <option value="Shortlisted">Shortlisted</option>
              <option value="In Review">In Review</option>
              <option value="Parsed">Parsed</option>
              <option value="Interview Scheduled">Interview Scheduled</option>
            </select>

            {/* Sort Field Toggle */}
            <button
              onClick={() => setSortField(sortField === 'matchScore' ? 'experienceYears' : 'matchScore')}
              className="px-3 py-1.5 bg-[#E8F0FE] text-[#1A73E8] font-medium rounded-full flex items-center gap-1"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              Sort: {sortField === 'matchScore' ? 'Match Score' : 'Experience'}
            </button>
          </div>
        </div>

        {/* Table View */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F8F9FA] text-gray-500 font-bold uppercase tracking-wider border-b border-[#E3E7EE]">
              <tr>
                <th className="py-3 px-4">Candidate Profile</th>
                <th className="py-3 px-4">Target Role</th>
                <th className="py-3 px-4 text-center">Match %</th>
                <th className="py-3 px-4">Key Technical Skills</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Quick Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F1F3F4]">
              {filteredCandidates.map((cand) => (
                <tr
                  key={cand.id}
                  className="hover:bg-[#F8F9FA] transition-colors group cursor-pointer"
                  onClick={() => onSelectCandidate(cand)}
                >
                  {/* Profile */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-[#E8F0FE] text-[#1A73E8] font-bold text-xs flex items-center justify-center shrink-0">
                        {anonymizedMode ? 'C' : cand.name.charAt(0)}
                      </div>
                      <div>
                        <span className="font-bold text-gray-900 group-hover:text-[#1A73E8] transition-colors block text-xs">
                          {anonymizedMode ? `Candidate #${cand.id.split('-')[1]}` : cand.name}
                        </span>
                        <span className="text-[11px] text-gray-400">
                          {cand.experienceYears} Yrs Exp • {cand.location.split('(')[0]}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Target Role */}
                  <td className="py-3.5 px-4 font-medium text-gray-800">
                    {cand.role}
                  </td>

                  {/* Match Score */}
                  <td className="py-3.5 px-4 text-center">
                    <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-[#E6F4EA] text-[#137333] font-bold text-xs">
                      {cand.matchScore}%
                    </span>
                  </td>

                  {/* Technical Skills */}
                  <td className="py-3.5 px-4">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {cand.technicalSkills.slice(0, 3).map((skill, i) => (
                        <span key={i} className="bg-gray-100 text-gray-600 text-[10px] px-2 py-0.5 rounded">
                          {skill}
                        </span>
                      ))}
                      {cand.technicalSkills.length > 3 && (
                        <span className="text-[10px] text-gray-400">+{cand.technicalSkills.length - 3}</span>
                      )}
                    </div>
                  </td>

                  {/* Status */}
                  <td className="py-3.5 px-4 text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${
                        cand.status === 'Shortlisted'
                          ? 'bg-[#E6F4EA] text-[#137333]'
                          : cand.status === 'In Review'
                          ? 'bg-[#E8F0FE] text-[#1A73E8]'
                          : cand.status === 'Rejected'
                          ? 'bg-[#FCE8E6] text-[#C5221F]'
                          : 'bg-amber-50 text-amber-800'
                      }`}
                    >
                      {cand.status}
                    </span>
                  </td>

                  {/* Quick Actions */}
                  <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => onSelectCandidate(cand)}
                        className="p-1.5 text-gray-500 hover:text-[#1A73E8] hover:bg-[#E8F0FE] rounded-lg transition-colors"
                        title="View Full Resume Analysis"
                      >
                        <Eye className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => onUpdateCandidateStatus(cand.id, 'Shortlisted')}
                        className="p-1.5 text-[#34A853] hover:bg-[#E6F4EA] rounded-lg transition-colors"
                        title="Shortlist Candidate"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => onUpdateCandidateStatus(cand.id, 'Rejected')}
                        className="p-1.5 text-[#EA4335] hover:bg-[#FCE8E6] rounded-lg transition-colors"
                        title="Reject Candidate"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Deep Candidate Intelligence Modules Grid */}
      <div className="space-y-6">
        <h2 className="text-base font-bold text-gray-900 border-b pb-2">
          Candidate Deep-Dive Intelligence Panels (Selected Candidate: {candidates[0]?.name || 'Maya Lin'})
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SkillGraphPanel candidate={candidates[0]} />
          <PortfolioVerificationPanel candidate={candidates[0]} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <CompanyTierPanel candidate={candidates[0]} />
          <GrowthTrajectoryPanel candidate={candidates[0]} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <TechStackEvolutionPanel candidate={candidates[0]} />
          <PeerBenchmarkingPanel candidate={candidates[0]} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SoftSkillInferencePanel candidate={candidates[0]} />
          <CareerGapTimelinePanel candidate={candidates[0]} />
        </div>

        <BlockchainVerificationPanel candidate={candidates[0]} />
      </div>
    </div>
  );
};
