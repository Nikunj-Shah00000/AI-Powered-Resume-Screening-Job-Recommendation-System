import React, { useState } from 'react';
import { Scale, ShieldCheck, Download, AlertTriangle, CheckCircle2, HelpCircle, Info, BarChart } from 'lucide-react';

export const FairnessMetricDashboardPanel: React.FC = () => {
  const [framework, setFramework] = useState<'demographic' | 'equal_opportunity' | 'predictive'>('demographic');
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      alert('Compliance Fairness Audit Report (EEOC & AI Ethics Certified) exported successfully.');
    }, 1000);
  };

  const parityVectorData = [
    { label: 'Gender Diversity Ratio', score: 96, status: 'Compliant', color: '#34A853' },
    { label: 'Age Group Balance (>40 yrs)', score: 92, status: 'Compliant', color: '#34A853' },
    { label: 'Ethnic Inclusion Accord', score: 95, status: 'Compliant', color: '#34A853' },
    { label: 'Socioeconomic Indicator Parity', score: 89, status: 'Borderline Watch', color: '#FBBC05' }
  ];

  return (
    <div className="m3-card p-6 space-y-6 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#E6F4EA] text-[#137333] flex items-center justify-center font-bold">
            <Scale className="w-6 h-6 text-[#34A853]" />
          </div>
          <div>
            <h2 className="text-base font-bold text-gray-900 font-sans tracking-tight">
              Algorithmic Equity & Fairness Metric Compliance Dashboard
            </h2>
            <p className="text-xs text-gray-500">
              EEOC & EU AI Act 80% Four-Fifths Disparate Impact Rule Automated Auditor
            </p>
          </div>
        </div>

        {/* Actions & Framework Dropdown */}
        <div className="flex items-center gap-3 shrink-0">
          <select
            value={framework}
            onChange={(e) => setFramework(e.target.value as any)}
            className="text-xs font-semibold bg-[#F8F9FA] border border-[#E8EAED] rounded-xl px-3 py-2 text-gray-800 focus:outline-none focus:ring-1 focus:ring-[#1A73E8]"
          >
            <option value="demographic">Demographic Parity Accord</option>
            <option value="equal_opportunity">Equal Opportunity Standard</option>
            <option value="predictive">Predictive Equality Model</option>
          </select>

          <button
            onClick={handleExport}
            disabled={isExporting}
            className="px-4 py-2 bg-[#1A73E8] hover:bg-[#1557B0] text-white text-xs font-bold rounded-full transition-all shadow-2xs flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Generating PDF...' : 'Export Compliance Report'}</span>
          </button>
        </div>
      </div>

      {/* Primary Parity Scorecard Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Central Index */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-[#E6F4EA] to-[#CEEAD6] border border-[#34A853]/40 space-y-2 text-center flex flex-col items-center justify-center">
          <span className="text-[10px] font-bold text-[#137333] uppercase tracking-wider flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-[#34A853]" /> Overall Parity Index
          </span>
          <p className="text-3xl font-extrabold text-[#137333]">94.8%</p>
          <span className="text-[10px] font-bold bg-white text-[#137333] px-2.5 py-0.5 rounded-full shadow-2xs">
            Parity Accord Certified
          </span>
        </div>

        {/* Individual Selection Ratios */}
        {parityVectorData.map((vec, idx) => (
          <div key={idx} className="p-4 rounded-2xl border border-[#E8EAED] bg-[#F8F9FA] space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-gray-700">
              <span className="truncate">{vec.label}</span>
              <span className="font-mono text-[#137333]">{vec.score}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${vec.score}%`, backgroundColor: vec.color }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-gray-400">Target: ≥80.0%</span>
              <span
                className={`font-semibold px-2 py-0.5 rounded ${
                  vec.score >= 90 ? 'bg-[#E6F4EA] text-[#137333]' : 'bg-[#FEF7E0] text-[#B06000]'
                }`}
              >
                {vec.status}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Four-Fifths Rule Distribution Chart Mockup */}
      <div className="p-5 rounded-2xl border border-[#E8EAED] bg-[#F8F9FA] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart className="w-4 h-4 text-[#1A73E8]" />
            <h3 className="text-xs font-bold text-gray-900">
              Four-Fifths Rule (80% Disparate Impact) Selection Ratio Bar
            </h3>
          </div>

          <div className="flex items-center gap-1 text-[11px] text-gray-500 group relative cursor-pointer">
            <HelpCircle className="w-3.5 h-3.5 text-[#1A73E8]" />
            <span>What is Disparate Impact Ratio?</span>
            <div className="absolute right-0 top-6 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-[11px] rounded-xl shadow-xl z-20">
              Disparate Impact Ratio compares the selection rate of a protected group to the highest selection rate group. A ratio under 0.80 (80%) indicates adverse impact under US EEOC guidelines.
            </div>
          </div>
        </div>

        {/* Visual Bar Chart Comparison */}
        <div className="space-y-3 pt-2">
          {/* Baseline Group */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-gray-700">Highest Selection Group Baseline (100% Benchmark)</span>
              <span className="font-mono text-[#1A73E8]">82.4% Selected</span>
            </div>
            <div className="w-full bg-gray-200 h-4 rounded-lg overflow-hidden relative">
              <div className="bg-[#1A73E8] h-full rounded-lg" style={{ width: '82.4%' }} />
              <div className="absolute top-0 bottom-0 left-[80%] border-r-2 border-dashed border-red-500 z-10" />
            </div>
          </div>

          {/* Protected Demographic Group */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-gray-700">Protected Group Selection Ratio (Disparate Impact: 0.94)</span>
              <span className="font-mono text-[#34A853]">77.5% Selected (94.0% of Baseline)</span>
            </div>
            <div className="w-full bg-gray-200 h-4 rounded-lg overflow-hidden relative">
              <div className="bg-[#34A853] h-full rounded-lg" style={{ width: '77.5%' }} />
              {/* Target 80% line marker */}
              <div className="absolute top-0 bottom-0 left-[65.92%] border-r-2 border-dashed border-[#EA4335] z-10" />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between text-[11px] text-gray-600 pt-2 border-t border-gray-200/80">
          <span className="flex items-center gap-1 text-[#137333] font-bold">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#34A853]" /> Compliant with US EEOC Uniform Guidelines & EU AI Act Section 10
          </span>
          <span className="font-mono text-gray-400">Audit Hash: 0x98A1...F442</span>
        </div>
      </div>
    </div>
  );
};
