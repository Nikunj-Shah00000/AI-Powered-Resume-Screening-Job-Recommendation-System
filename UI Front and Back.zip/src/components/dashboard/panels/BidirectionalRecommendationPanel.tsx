import React, { useState } from 'react';
import { Briefcase, UserCheck, SlidersHorizontal, ArrowUpDown, Sparkles, MapPin, DollarSign } from 'lucide-react';
import { Candidate, JobListing } from '../../../types';

interface BidirectionalRecommendationPanelProps {
  viewMode?: 'recruiter' | 'candidate';
  onViewModeChange?: (mode: 'recruiter' | 'candidate') => void;
  candidates: Candidate[];
  jobListings: JobListing[];
  onSelectCandidate: (candidate: Candidate) => void;
}

export const BidirectionalRecommendationPanel: React.FC<BidirectionalRecommendationPanelProps> = ({
  viewMode = 'recruiter',
  onViewModeChange,
  candidates,
  jobListings,
  onSelectCandidate
}) => {
  const [mode, setMode] = useState<'recruiter' | 'candidate'>(viewMode);
  const [sortBy, setSortBy] = useState<'score' | 'salary' | 'commute'>('score');

  const handleModeSwitch = (newMode: 'recruiter' | 'candidate') => {
    setMode(newMode);
    if (onViewModeChange) onViewModeChange(newMode);
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <ArrowUpDown className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Bidirectional Recommendation Stream Switcher</h3>
            <p className="text-xs text-gray-500">Dual perspective matching for Recruiters & Candidates</p>
          </div>
        </div>

        {/* Perspective Switcher */}
        <div className="inline-flex p-1 bg-[#F1F3F4] rounded-full text-xs font-semibold border border-[#E8EAED]">
          <button
            onClick={() => handleModeSwitch('recruiter')}
            className={`px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 ${
              mode === 'recruiter' ? 'bg-[#1A73E8] text-white shadow-2xs' : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" /> Recruiter View
          </button>
          <button
            onClick={() => handleModeSwitch('candidate')}
            className={`px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 ${
              mode === 'candidate' ? 'bg-[#34A853] text-white shadow-2xs' : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5" /> Candidate View
          </button>
        </div>
      </div>

      {/* Sorting & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs bg-[#F8F9FA] p-2.5 rounded-xl border border-[#E8EAED]">
        <span className="font-semibold text-gray-700">
          {mode === 'recruiter' ? 'Showing Candidates Matched To Open Roles' : 'Showing Job Positions Ranked For Candidate Profile'}
        </span>

        <div className="flex items-center gap-2">
          <span className="text-gray-500 font-medium">Sort By:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-white border border-gray-300 rounded-lg px-2.5 py-1 text-xs font-medium outline-none focus:border-[#1A73E8]"
          >
            <option value="score">Compatibility Score %</option>
            <option value="salary">Salary Range</option>
            <option value="commute">Commute / Work Mode</option>
          </select>
        </div>
      </div>
    </div>
  );
};
