import React, { useState } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  Lock,
  Eye,
  Globe,
  Share2,
  Clock,
  TrendingUp,
  Award,
  Sparkles,
  DollarSign,
  Box,
  CheckCircle2,
  X
} from 'lucide-react';

export const NextGenSecuritySuitePanel: React.FC = () => {
  const [isVrModalOpen, setIsVrModalOpen] = useState(false);
  const [feedbackConfirmed, setFeedbackConfirmed] = useState(false);

  return (
    <div className="space-y-6">
      {/* C-Suite Executive Summary ROI Banner */}
      <div className="bg-gradient-to-r from-[#1A73E8] via-[#A142F4] to-[#34A853] p-6 rounded-2xl text-white shadow-sm space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold bg-white/20 px-3 py-1 rounded-full w-fit backdrop-blur-xs">
          <Sparkles className="w-3.5 h-3.5" /> Executive Summary ROI Dashboard & C-Suite View
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-2">
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/20">
            <span className="text-[10px] uppercase font-bold text-white/80">Total Financial Savings</span>
            <p className="text-2xl font-extrabold font-mono">$142,500</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/20">
            <span className="text-[10px] uppercase font-bold text-white/80">Time Saved by AI</span>
            <p className="text-2xl font-extrabold font-mono">1,240 Hrs</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/20">
            <span className="text-[10px] uppercase font-bold text-white/80">Parity Compliance</span>
            <p className="text-2xl font-extrabold font-mono">98.4%</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/20">
            <span className="text-[10px] uppercase font-bold text-white/80">Offer Acceptance Rate</span>
            <p className="text-2xl font-extrabold font-mono">92.0%</p>
          </div>
        </div>
      </div>

      {/* Grid: LinkedIn Live Sync + Fraud & Plagiarism + ZKP Privacy Guard */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* LinkedIn Live Sync Monitor */}
        <div className="m3-card p-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-900 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-[#1A73E8]" /> LinkedIn Live Sync Active
            </span>
            <span className="text-[10px] text-[#137333] font-bold bg-[#E6F4EA] px-2 py-0.5 rounded">
              Synced 4m ago
            </span>
          </div>
          <p className="text-xs text-gray-600">
            Auto-scanned profile updates: Added 1 patent and updated staff title at DeepMind.
          </p>
        </div>

        {/* Fraud & Plagiarism Detector Badge */}
        <div className="m3-card p-4 bg-white border border-[#EA4335]/30 bg-[#FCE8E6]/20 rounded-2xl shadow-2xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#C5221F] flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-[#EA4335]" /> AI Text & Copied Content Meter
            </span>
            <span className="text-[10px] font-bold text-[#C5221F] bg-[#FCE8E6] px-2 py-0.5 rounded">
              3% Risk (Genuine)
            </span>
          </div>
          <p className="text-xs text-gray-600">
            Originality Score: 97%. Text passes cross-web plagiarism scan with zero copied boilerplates.
          </p>
        </div>

        {/* Zero-Knowledge Proof Privacy Guard */}
        <div className="m3-card p-4 bg-white border border-[#34A853]/30 bg-[#E6F4EA]/20 rounded-2xl shadow-2xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#137333] flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-[#34A853]" /> Zero-Knowledge Proof (ZKP) Guard
            </span>
            <span className="text-[10px] font-bold text-[#137333] bg-[#E6F4EA] px-2 py-0.5 rounded">
              Verified
            </span>
          </div>
          <p className="text-xs text-gray-600">
            PII is cryptographically scrubbed at container edge without storing raw text on unencrypted servers.
          </p>
        </div>
      </div>

      {/* Grid: Recruiter Anti-Ghosting + Web3 Portfolio + Global Shift Adaptor */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Recruiter Anti-Ghosting Banner */}
        <div className="m3-card p-4 bg-white border border-[#FBBC05] bg-[#FEF7E0]/30 rounded-2xl shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-[#B06000]">
            <span>⏱️ Pipeline Stalled Warning</span>
            <span>4 Days Silent</span>
          </div>
          <p className="text-xs text-gray-700">
            Candidate file stagnant in Technical Assessment stage.
          </p>
          <button
            onClick={() => alert('Automated check-in macro message sent to candidate via WhatsApp & Email.')}
            className="w-full py-1.5 bg-[#B06000] hover:bg-[#8e4d00] text-white text-xs font-bold rounded-lg transition-all"
          >
            Trigger Anti-Ghosting Touch
          </button>
        </div>

        {/* Web3 Portfolio Scraping Container */}
        <div className="m3-card p-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-gray-900">
            <span className="flex items-center gap-1.5">
              <Box className="w-4 h-4 text-[#A142F4]" /> Web3 Portfolio Verification
            </span>
            <span className="text-[10px] font-mono text-[#A142F4]">Ethereum / Polygon</span>
          </div>
          <p className="text-xs text-gray-600">
            Verified Smart Contracts: 3 dApps deployed, 12,400 mainnet transactions verified on Etherscan.
          </p>
        </div>

        {/* Global Industry Shift Adaptor */}
        <div className="m3-card p-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-gray-900">
            <span className="flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-[#1A73E8]" /> Global Industry Shift Adaptor
            </span>
          </div>
          <p className="text-xs text-gray-600">
            🚨 Macro Trend: Legacy framework usage dropped 14% globally this quarter; Rust & Vertex AI up 22%.
          </p>
        </div>
      </div>

      {/* Grid: VR/AR Launcher + Graph Neural Network Talent Map + Self-Correcting Logger */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* VR/AR Interview Preview Launcher */}
        <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-gray-900">VR/AR Immersive Office Tour</h3>
            <span className="text-xs text-[#1A73E8] font-bold">3D Preview</span>
          </div>
          <p className="text-xs text-gray-600">
            Provide shortlisted candidates with an immersive 3D/VR office simulation experience before interview day.
          </p>
          <button
            onClick={() => setIsVrModalOpen(true)}
            className="w-full py-2 bg-[#1A73E8] hover:bg-[#1557B0] text-white text-xs font-bold rounded-xl transition-all shadow-2xs flex items-center justify-center gap-2"
          >
            <Eye className="w-4 h-4" />
            <span>Launch Immersive Virtual Office Tour</span>
          </button>
        </div>

        {/* Graph Neural Network (GNN) Talent Map */}
        <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-gray-900">GNN Macro Talent Network Map</h3>
            <span className="text-xs text-[#A142F4] font-bold">GNN Node Graph</span>
          </div>
          <div className="p-3 bg-[#1E1E1E] text-green-400 rounded-xl text-center text-xs font-mono space-y-1">
            <p>[Node Network Graph Simulation]</p>
            <p className="text-gray-400 text-[10px]">Tracking 1,400 engineer migration flows across FAANG/Unicorn tiers</p>
          </div>
        </div>

        {/* Self-Correcting Feedback Optimization Logger */}
        <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-gray-900">AI Loop Self-Correction Logger</h3>
            <span className="text-xs text-[#34A853] font-bold">Closed-Loop AI</span>
          </div>
          <p className="text-xs text-gray-600">
            Confirm successful placement to automatically refine background scoring weights for future hiring cycles.
          </p>
          <button
            onClick={() => setFeedbackConfirmed(true)}
            disabled={feedbackConfirmed}
            className={`w-full py-2 text-xs font-bold rounded-xl transition-all ${
              feedbackConfirmed
                ? 'bg-[#E6F4EA] text-[#137333]'
                : 'bg-[#34A853] hover:bg-[#2d9248] text-white'
            }`}
          >
            {feedbackConfirmed ? '✓ AI Scoring Loop Refined for Hired Profile' : 'Confirm Placement & Refine Loop'}
          </button>
        </div>
      </div>

      {/* VR Tour Modal Simulation */}
      {isVrModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full space-y-4 relative shadow-2xl">
            <button
              onClick={() => setIsVrModalOpen(false)}
              className="absolute top-4 right-4 p-1 text-gray-400 hover:text-gray-900 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <Box className="w-6 h-6 text-[#1A73E8]" />
              <h2 className="text-base font-bold text-gray-900">3D Immersive Corporate Office Tour</h2>
            </div>
            <div className="aspect-video bg-[#1E1E1E] rounded-xl flex flex-col items-center justify-center text-white space-y-2">
              <Sparkles className="w-8 h-8 text-[#1A73E8] animate-bounce" />
              <p className="text-xs font-mono">Rendering Interactive WebGL 3D Office Model...</p>
            </div>
            <button
              onClick={() => setIsVrModalOpen(false)}
              className="w-full py-2 bg-[#1A73E8] text-white text-xs font-bold rounded-full"
            >
              Close 3D View
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
