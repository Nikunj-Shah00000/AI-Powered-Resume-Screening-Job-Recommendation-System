import React, { useState } from 'react';
import { Lock, ShieldAlert, Eye, EyeOff, Filter, CheckCircle2, Info } from 'lucide-react';

export const ProxyVariableRedactionPanel: React.FC = () => {
  const [proxyActive, setProxyActive] = useState(true);
  const [filterCategory, setFilterCategory] = useState<'all' | 'geo' | 'affiliation'>('all');
  const [unmaskedMap, setUnmaskedMap] = useState<Record<string, boolean>>({});

  const detectedProxies = [
    { id: 'p1', original: 'Palo Alto Zip 94305', category: 'geo', masked: '[Redacted Proxy - Geo-indicator]' },
    { id: 'p2', original: 'Phi Beta Kappa Honor Society', category: 'affiliation', masked: '[Redacted Proxy - Affiliation]' },
    { id: 'p3', original: 'Bavarian Cultural & Heritage Society', category: 'affiliation', masked: '[Redacted Proxy - Affiliation]' },
    { id: 'p4', original: 'Class of 2012 High School Alum', category: 'geo', masked: '[Redacted Proxy - Age Indicator]' }
  ];

  const handleToggleUnmask = (id: string) => {
    setUnmaskedMap((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const filtered = detectedProxies.filter((p) => {
    if (filterCategory === 'all') return true;
    return p.category === filterCategory;
  });

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Lock className="w-5 h-5 text-[#1A73E8]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Proxy Variable Redaction & Protection Auditor</h3>
            <p className="text-xs text-gray-500">Detects & scrubs indirect indicators that proxy for protected classes</p>
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-gray-400" />
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value as any)}
            className="text-xs font-semibold bg-[#F8F9FA] border border-[#E8EAED] rounded-lg px-2.5 py-1 text-gray-800"
          >
            <option value="all">All Flagged Proxies ({detectedProxies.length})</option>
            <option value="geo">Geo-Indicators</option>
            <option value="affiliation">Affiliations / Clubs</option>
          </select>
        </div>
      </div>

      {/* Toggle Bar */}
      <div className="p-3 rounded-xl bg-[#F8F9FA] border border-gray-200 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-[#1A73E8]" />
          <span className="font-bold text-gray-800">Proxy Variable Protection Guardrails</span>
        </div>
        <button
          onClick={() => setProxyActive(!proxyActive)}
          className={`px-3 py-1 rounded-full font-bold transition-all ${
            proxyActive ? 'bg-[#1A73E8] text-white' : 'bg-gray-200 text-gray-700'
          }`}
        >
          {proxyActive ? 'Protection Active' : 'Protection Disabled'}
        </button>
      </div>

      {/* Flagged Sub-Indicators List */}
      <div className="space-y-2">
        {filtered.map((item) => {
          const isUnmasked = !proxyActive || unmaskedMap[item.id];
          return (
            <div
              key={item.id}
              className="p-3 rounded-xl border border-gray-200 bg-white flex items-center justify-between text-xs transition-all"
            >
              <div className="flex items-center gap-2">
                <Lock className="w-3.5 h-3.5 text-[#1A73E8]" />
                <span className="font-mono font-semibold text-gray-800">
                  {isUnmasked ? item.original : item.masked}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#E8F0FE] text-[#1A73E8]">
                  {item.category.toUpperCase()}
                </span>
                <button
                  onClick={() => handleToggleUnmask(item.id)}
                  className="p-1 text-gray-400 hover:text-gray-700 rounded"
                  title="Toggle unmask for context check"
                >
                  {isUnmasked ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
