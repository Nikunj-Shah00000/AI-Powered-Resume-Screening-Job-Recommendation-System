import React from 'react';
import { TrendingUp, Flame, Award, DollarSign } from 'lucide-react';

export const MarketDemandPanel: React.FC = () => {
  const demandItems = [
    { skill: 'PyTorch & vLLM Optimization', demandScore: 98, trend: '+42% MoM', salaryPremium: '+$45k' },
    { skill: 'Material Design 3 & Web Vitals', demandScore: 91, trend: '+18% MoM', salaryPremium: '+$25k' },
    { skill: 'GCP Vertex AI / Agentic AI', demandScore: 96, trend: '+35% MoM', salaryPremium: '+$38k' }
  ];

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#FCE8E6] text-[#C5221F] flex items-center justify-center font-bold text-xs">
            <Flame className="w-5 h-5 text-[#EA4335]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Market Demand Scoring & Trend Analysis</h3>
            <p className="text-xs text-gray-500">Real-time macro hiring velocity & skill premium index</p>
          </div>
        </div>
        <span className="text-xs font-bold text-red-700 bg-red-50 px-2.5 py-1 rounded-full">
          High Scarcity Skills
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {demandItems.map((item, idx) => (
          <div key={idx} className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-gray-900 truncate">{item.skill}</span>
              <span className="text-[10px] font-bold text-[#137333] bg-[#E6F4EA] px-2 py-0.5 rounded-full">
                {item.trend}
              </span>
            </div>
            <div className="flex items-baseline justify-between pt-1">
              <span className="text-lg font-bold text-gray-900">{item.demandScore} / 100</span>
              <span className="text-xs font-semibold text-[#1A73E8]">{item.salaryPremium} Premium</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
