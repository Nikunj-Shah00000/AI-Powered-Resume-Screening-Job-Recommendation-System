import React from 'react';
import { Eye, EyeOff, ShieldCheck, Lock, Sparkles, CheckCircle2 } from 'lucide-react';

interface BlindScreeningControllerProps {
  anonymizedMode: boolean;
  setAnonymizedMode: (active: boolean) => void;
}

export const BlindScreeningController: React.FC<BlindScreeningControllerProps> = ({
  anonymizedMode,
  setAnonymizedMode
}) => {
  return (
    <div className="m3-card p-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
      <div className="flex items-center gap-3">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold ${
          anonymizedMode ? 'bg-[#E6F4EA] text-[#137333]' : 'bg-[#E8F0FE] text-[#1A73E8]'
        }`}>
          {anonymizedMode ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-gray-900 text-sm">Blind Screening Mode & Anonymizer Mask</h3>
            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#137333] bg-[#E6F4EA] px-2 py-0.5 rounded-full">
              <ShieldCheck className="w-3 h-3 text-[#34A853]" /> DEI Compliant (99.2% Equity)
            </span>
          </div>
          <p className="text-gray-500 text-xs">
            {anonymizedMode
              ? 'Masking PII: Names → Candidate Code, Universities → Tier Categories, Location → Region Zone'
              : 'Standard View: PII attributes visible for recruiter evaluation'}
          </p>
        </div>
      </div>

      {/* Toggle Button */}
      <button
        onClick={() => setAnonymizedMode(!anonymizedMode)}
        className={`px-4 py-2 rounded-full font-bold transition-all shadow-2xs flex items-center gap-2 shrink-0 ${
          anonymizedMode
            ? 'bg-[#137333] hover:bg-[#0f5b28] text-white'
            : 'bg-[#1A73E8] hover:bg-[#1557B0] text-white'
        }`}
      >
        {anonymizedMode ? <Lock className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        <span>{anonymizedMode ? 'Blind Mode Active' : 'Enable Blind Mode'}</span>
      </button>
    </div>
  );
};
