import React, { useState } from 'react';
import {
  Layers,
  AlertOctagon,
  Clock,
  DollarSign,
  Mail,
  FileSpreadsheet,
  HelpCircle,
  Users,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Send,
  Search,
  CheckCircle2
} from 'lucide-react';
import { Candidate } from '../../../types';

interface RecruiterAutomationSuitePanelProps {
  candidates?: Candidate[];
}

export const RecruiterAutomationSuitePanel: React.FC<RecruiterAutomationSuitePanelProps> = ({ candidates = [] }) => {
  const [selectedTier, setSelectedTier] = useState<'all' | 'tier_a' | 'tier_b' | 'tier_c'>('all');
  const [emailSubject, setEmailSubject] = useState('Exclusive Invitation: Staff AI Engineer Role at Google');
  const [emailBody, setEmailBody] = useState(
    `Hi Maya,\n\nI reviewed your published work in distributed PyTorch optimizations and was thoroughly impressed. We are scaling our core AI Infrastructure team and would love to connect for a quick 15-minute chat.\n\nBest,\nRecruitment Team`
  );
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [lookalikeSearch, setLookalikeSearch] = useState('');

  const handleSendEmail = () => {
    setIsSendingEmail(true);
    setTimeout(() => {
      setIsSendingEmail(false);
      alert('Outreach email dispatched successfully via Gmail API.');
    }, 1000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1A73E8] via-[#1557B0] to-[#A142F4] p-6 rounded-2xl text-white shadow-sm space-y-2">
        <div className="flex items-center gap-2 text-xs font-bold bg-white/20 px-3 py-1 rounded-full w-fit backdrop-blur-xs">
          <Sparkles className="w-3.5 h-3.5" /> Recruiter Intelligence & Automation Suite
        </div>
        <h1 className="text-xl font-bold font-sans">Automated Talent Acquisition & Analytics Engine</h1>
        <p className="text-xs text-white/90 max-w-2xl">
          Automated tiering, attrition risk forecasting, Lookalike candidate discovery, and cold outreach automation.
        </p>
      </div>

      {/* Grid: Talent Pool Tiering + Attrition Risk Predictor + Time-to-Hire */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Automated Talent Pool Tiering */}
        <div className="m3-card p-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-gray-900">
            <Layers className="w-4 h-4 text-[#1A73E8]" />
            <span>Automated Talent Pool Tiering</span>
          </div>

          <div className="space-y-1.5 text-xs">
            <div className="p-2 rounded-xl bg-[#E8F0FE] text-[#1A73E8] font-bold flex justify-between">
              <span>Tier A (Elite Match &gt;90%)</span>
              <span className="font-mono">12 Applicants</span>
            </div>
            <div className="p-2 rounded-xl bg-[#E6F4EA] text-[#137333] font-bold flex justify-between">
              <span>Tier B (Strong Backup 75-89%)</span>
              <span className="font-mono">28 Applicants</span>
            </div>
            <div className="p-2 rounded-xl bg-[#F1F3F4] text-gray-600 font-bold flex justify-between">
              <span>Tier C (Keep on File &lt;75%)</span>
              <span className="font-mono">45 Applicants</span>
            </div>
          </div>
        </div>

        {/* Attrition Risk Predictor Widget */}
        <div className="m3-card p-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-gray-900">
            <AlertOctagon className="w-4 h-4 text-[#34A853]" />
            <span>Candidate Attrition Risk Predictor</span>
          </div>

          <div className="p-3 bg-[#F8F9FA] rounded-xl border border-gray-200 text-center space-y-1">
            <span className="text-[10px] text-gray-400 font-bold uppercase">Predicted Early Departure Risk</span>
            <p className="text-xl font-extrabold text-[#34A853]">Low Attrition Risk (12%)</p>
            <p className="text-[10px] text-gray-500">Based on 2.4 yr average tenure stability across top tech roles.</p>
          </div>
        </div>

        {/* Time-to-Hire Forecaster */}
        <div className="m3-card p-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-gray-900">
            <Clock className="w-4 h-4 text-[#1A73E8]" />
            <span>Time-to-Hire Forecaster</span>
          </div>

          <div className="p-3 bg-[#F8F9FA] rounded-xl border border-gray-200 text-center space-y-1">
            <span className="text-[10px] text-gray-400 font-bold uppercase">Estimated Requisition Closing</span>
            <p className="text-2xl font-extrabold text-[#1A73E8] font-mono">18 Days</p>
            <p className="text-[10px] text-[#137333] font-bold">↓ 4 days faster than company average</p>
          </div>
        </div>
      </div>

      {/* Grid: Bottleneck Detector + Lookalike Finder + Talent Rediscovery */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Pipeline Bottleneck Detector */}
        <div className="m3-card p-4 bg-white border border-red-200 bg-red-50/20 rounded-2xl shadow-2xs space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-[#EA4335]">
            <AlertTriangle className="w-4 h-4" />
            <span>Pipeline Bottleneck Alert</span>
          </div>
          <p className="text-xs text-gray-800 leading-snug">
            🚨 Stage Bottleneck: Technical Assessment average delay is <strong>8 days above baseline</strong>. 14 candidate files awaiting review.
          </p>
        </div>

        {/* Lookalike Candidate Finder */}
        <div className="m3-card p-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-gray-900">
            <Users className="w-4 h-4 text-[#1A73E8]" />
            <span>Lookalike Candidate Finder</span>
          </div>
          <div className="relative text-xs">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Find candidates similar to: [Employee Name]"
              value={lookalikeSearch}
              onChange={(e) => setLookalikeSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-[#F8F9FA] border border-gray-300 rounded-lg text-xs"
            />
          </div>
        </div>

        {/* Dynamic Talent Rediscovery */}
        <div className="m3-card p-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-gray-900">
            <RotateCcw className="w-4 h-4 text-[#34A853]" />
            <span>Dynamic Talent Rediscovery</span>
          </div>
          <p className="text-xs text-gray-600">
            Crawled 420 historical archive applicants ("Silver Medalists"). Matched <strong>6 past candidates</strong> with active Staff AI requisitions.
          </p>
        </div>
      </div>

      {/* Grid: Cold Outreach Workspace + Question Generator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Automated Cold Outreach Workspace */}
        <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#F1F3F4]">
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-[#EA4335]" />
              <h3 className="text-sm font-bold text-gray-900">Automated Cold Outreach Workspace (Gmail Style)</h3>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <input
              type="text"
              value={emailSubject}
              onChange={(e) => setEmailSubject(e.target.value)}
              className="w-full p-2 bg-[#F8F9FA] border border-gray-200 rounded-lg font-bold text-xs"
            />
            <textarea
              value={emailBody}
              onChange={(e) => setEmailBody(e.target.value)}
              rows={5}
              className="w-full p-2.5 bg-[#F8F9FA] border border-gray-200 rounded-lg text-xs font-sans leading-relaxed"
            />
            <button
              onClick={handleSendEmail}
              disabled={isSendingEmail}
              className="px-4 py-2 bg-[#1A73E8] hover:bg-[#1557B0] text-white text-xs font-bold rounded-full transition-all shadow-2xs flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSendingEmail ? 'Dispatching Email...' : 'Send via Gmail API'}</span>
            </button>
          </div>
        </div>

        {/* AI Interview Question Generator */}
        <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#F1F3F4]">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#A142F4]" />
              <h3 className="text-sm font-bold text-gray-900">AI Interview Question Generator</h3>
            </div>
            <span className="text-xs text-[#A142F4] font-bold">Targeted for Skill Gaps</span>
          </div>

          <div className="space-y-2 text-xs font-sans">
            <div className="p-2.5 bg-[#F8F9FA] border border-gray-200 rounded-xl space-y-1">
              <span className="font-bold text-[#1A73E8]">1. Distributed Systems Question:</span>
              <p className="text-gray-700">"How have you handled p99 latency degradation during multi-node GPU gradient synchronization in PyTorch?"</p>
            </div>
            <div className="p-2.5 bg-[#F8F9FA] border border-gray-200 rounded-xl space-y-1">
              <span className="font-bold text-[#A142F4]">2. Leadership / Soft Skill Question:</span>
              <p className="text-gray-700">"Describe a situation where research team goals diverged from product deployment timelines."</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
