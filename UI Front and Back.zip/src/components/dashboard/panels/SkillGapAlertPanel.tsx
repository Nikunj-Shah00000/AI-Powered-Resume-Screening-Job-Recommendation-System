import React, { useState } from 'react';
import { AlertCircle, ArrowRight, BookOpen, CheckCircle2, ExternalLink, Plus } from 'lucide-react';
import { Candidate, MissingSkillGap } from '../../../types';

interface SkillGapAlertPanelProps {
  candidate?: Candidate;
}

export const SkillGapAlertPanel: React.FC<SkillGapAlertPanelProps> = ({ candidate }) => {
  const [assignedCourses, setAssignedCourses] = useState<Record<string, boolean>>({});

  const gaps: MissingSkillGap[] = candidate?.missingSkillGaps || [
    {
      skillName: 'ONNX Runtime Optimization',
      importance: 'Preferred',
      severity: 'Minor Gap',
      suggestedCourse: {
        id: 'course-101',
        title: 'High-Performance Inference with ONNX Runtime & TensorRT',
        platform: 'Google Cloud Skills Boost',
        durationHours: '12 hours',
        difficulty: 'Intermediate',
        bridgesSkill: 'ONNX Runtime Optimization',
        syllabusUrl: 'https://cloud.google.com/training',
        assigned: false
      }
    }
  ];

  const handleAssign = (courseId: string) => {
    setAssignedCourses((prev) => ({ ...prev, [courseId]: true }));
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#FEF7E0] text-[#B06000] flex items-center justify-center font-bold text-xs">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Real-Time Skill Gap Alert & Course Recommender</h3>
            <p className="text-xs text-gray-500">Identifies missing qualifications & maps tailored training courses</p>
          </div>
        </div>
        <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full">
          {gaps.length} Actionable Gap
        </span>
      </div>

      <div className="space-y-3">
        {gaps.map((gap, idx) => (
          <div key={idx} className="p-3.5 rounded-xl border border-amber-200 bg-amber-50/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-amber-900 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-600" /> Missing: {gap.skillName}
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                {gap.severity} ({gap.importance})
              </span>
            </div>

            {/* Course Card */}
            {gap.suggestedCourse && (
              <div className="bg-white p-3 rounded-lg border border-gray-200 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1A73E8] flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5" /> {gap.suggestedCourse.platform}
                  </span>
                  <span className="text-[10px] text-gray-500">{gap.suggestedCourse.durationHours}</span>
                </div>
                <p className="font-bold text-gray-900">{gap.suggestedCourse.title}</p>

                <div className="flex items-center justify-between pt-1 border-t border-gray-100">
                  <a
                    href={gap.suggestedCourse.syllabusUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[11px] text-[#1A73E8] hover:underline flex items-center gap-1"
                  >
                    View Syllabus <ExternalLink className="w-3 h-3" />
                  </a>

                  <button
                    onClick={() => handleAssign(gap.suggestedCourse!.id)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                      assignedCourses[gap.suggestedCourse!.id]
                        ? 'bg-[#E6F4EA] text-[#137333]'
                        : 'bg-[#1A73E8] hover:bg-[#1557B0] text-white'
                    }`}
                  >
                    {assignedCourses[gap.suggestedCourse!.id] ? '✓ Course Assigned' : '+ Assign Upskilling Course'}
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
