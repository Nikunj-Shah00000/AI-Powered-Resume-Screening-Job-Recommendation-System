import React from 'react';
import { ArrowRight, Check, Sliders, Sparkles } from 'lucide-react';

export const FuzzySkillMatchPanel: React.FC = () => {
  const standardizationPairs = [
    { resumeVariant: 'React.js / React 19', standardizedTitle: 'Frontend Engineering (React Taxonomy)', confidence: 99 },
    { resumeVariant: 'ML Engineer / AI Architect', standardizedTitle: 'Staff Artificial Intelligence Specialist', confidence: 97 },
    { resumeVariant: 'Node / Express JS / TS', standardizedTitle: 'Node.js Backend Ecosystem', confidence: 95 }
  ];

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Fuzzy Skill Matching & Title Standardization</h3>
            <p className="text-xs text-gray-500">Normalizes non-standard resume jargon into canonical taxonomy</p>
          </div>
        </div>
        <span className="text-xs font-semibold text-[#1A73E8] bg-[#E8F0FE] px-2.5 py-1 rounded-full">
          Canonical AI Mapping
        </span>
      </div>

      <div className="space-y-2">
        {standardizationPairs.map((pair, idx) => (
          <div key={idx} className="p-3 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 truncate">
              <span className="font-mono bg-white px-2 py-1 rounded border text-gray-700 truncate">{pair.resumeVariant}</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#1A73E8] shrink-0" />
              <span className="font-bold text-gray-900 truncate">{pair.standardizedTitle}</span>
            </div>
            <span className="font-bold text-[#137333] bg-[#E6F4EA] px-2 py-0.5 rounded-full text-[10px] shrink-0">
              {pair.confidence}% Standard
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
