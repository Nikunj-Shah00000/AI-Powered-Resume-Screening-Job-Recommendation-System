import React, { useState } from 'react';
import { Languages, Globe, RefreshCw, Check, Sparkles, AlertCircle } from 'lucide-react';

interface MultilingualParsingPanelProps {
  currentLanguage?: string;
  onLanguageChange?: (lang: string) => void;
  isTranslatedView?: boolean;
  onToggleTranslation?: () => void;
}

export const MultilingualParsingPanel: React.FC<MultilingualParsingPanelProps> = ({
  currentLanguage = 'Spanish',
  onLanguageChange,
  isTranslatedView = true,
  onToggleTranslation
}) => {
  const [selectedLang, setSelectedLang] = useState<string>(currentLanguage);
  const [isTranslating, setIsTranslating] = useState<boolean>(false);

  const languages = [
    { code: 'es', name: 'Spanish (Español)', flag: '🌐' },
    { code: 'en', name: 'English (US)', flag: '🇺🇸' },
    { code: 'fr', name: 'French (Français)', flag: '🇫🇷' },
    { code: 'de', name: 'German (Deutsch)', flag: '🇩🇪' },
    { code: 'zh', name: 'Chinese (Mandarin)', flag: '🇨🇳' },
    { code: 'ja', name: 'Japanese (日本語)', flag: '🇯🇵' }
  ];

  const handleSelectLang = (langName: string) => {
    setSelectedLang(langName);
    setIsTranslating(true);
    setTimeout(() => {
      setIsTranslating(false);
      if (onLanguageChange) onLanguageChange(langName);
    }, 600);
  };

  return (
    <div className="inline-flex flex-wrap items-center gap-2 bg-white border border-[#E3E7EE] p-2 rounded-2xl shadow-2xs text-xs font-sans">
      {/* Auto Detected Language Chip */}
      <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#E8F0FE] text-[#1A73E8] rounded-full font-bold">
        <Globe className="w-3.5 h-3.5" />
        <span>Detected: {selectedLang}</span>
      </div>

      {/* Language Selector Dropdown */}
      <div className="relative inline-block">
        <select
          value={selectedLang}
          onChange={(e) => handleSelectLang(e.target.value)}
          className="bg-[#F1F3F4] hover:bg-[#E8EAED] text-gray-800 font-medium px-3 py-1.5 rounded-full outline-none focus:ring-2 focus:ring-[#1A73E8] cursor-pointer text-xs"
        >
          {languages.map((l) => (
            <option key={l.code} value={l.name}>
              {l.flag} {l.name}
            </option>
          ))}
        </select>
      </div>

      {/* Status Badge */}
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#E6F4EA] text-[#137333] font-semibold text-[11px]">
        <Sparkles className="w-3 h-3 text-[#34A853]" /> AI Translated Profile
      </span>

      {/* Toggle View Action */}
      <button
        onClick={onToggleTranslation}
        className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1A73E8] hover:bg-[#1557B0] text-white rounded-full font-medium transition-all shadow-2xs"
      >
        <Languages className="w-3.5 h-3.5" />
        <span>{isTranslatedView ? 'Show Original Text' : 'Show English Translation'}</span>
      </button>

      {isTranslating && (
        <span className="text-[10px] text-[#1A73E8] font-bold animate-pulse flex items-center gap-1">
          <RefreshCw className="w-3 h-3 animate-spin" /> Translating...
        </span>
      )}
    </div>
  );
};
