import React, { useState } from 'react';
import { Network, ShieldCheck, RefreshCw, Zap, Sliders, Sparkles } from 'lucide-react';

export const AdversarialDebiasingPanel: React.FC = () => {
  const [engaged, setEngaged] = useState(true);
  const [strength, setStrength] = useState(3); // 1 to 5
  const [isRecalibrating, setIsRecalibrating] = useState(false);

  const handleRecalibrate = () => {
    setIsRecalibrating(true);
    setTimeout(() => {
      setIsRecalibrating(false);
    }, 1200);
  };

  const modelAccuracy = 94.2 - (strength - 1) * 0.4;
  const demographicFairPlay = 91.0 + strength * 1.5;

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#F3E8FD] text-[#A142F4] flex items-center justify-center font-bold text-xs">
            <Network className="w-5 h-5 text-[#A142F4]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Adversarial Bias Disruptor & Neural Guardrails</h3>
            <p className="text-xs text-gray-500">Gradients optimized to remove latent demographic sub-vector signals</p>
          </div>
        </div>

        {/* Real-time Status Indicator */}
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#A142F4] opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#A142F4]" />
          </span>
          <span className="text-xs font-bold text-[#A142F4] bg-[#F3E8FD] px-2.5 py-0.5 rounded-full">
            Active Mitigation
          </span>
        </div>
      </div>

      {/* Main Dual Metric Visualization */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="p-3.5 rounded-xl border border-gray-200 bg-[#F8F9FA] space-y-1 text-center">
          <span className="text-[10px] font-bold text-gray-500 uppercase">Model Scoring Accuracy</span>
          <p className="text-2xl font-bold text-[#1A73E8] font-mono">{modelAccuracy.toFixed(1)}%</p>
          <p className="text-[10px] text-gray-400">High utility screening baseline</p>
        </div>

        <div className="p-3.5 rounded-xl border border-purple-200 bg-[#F3E8FD]/30 space-y-1 text-center">
          <span className="text-[10px] font-bold text-[#A142F4] uppercase">Demographic Fair-Play Parity</span>
          <p className="text-2xl font-bold text-[#A142F4] font-mono">{demographicFairPlay.toFixed(1)}%</p>
          <p className="text-[10px] text-purple-600 font-medium">Minimizing demographic leakage</p>
        </div>
      </div>

      {/* Adversarial Correction Strength Slider */}
      <div className="space-y-2 p-3.5 bg-[#F8F9FA] border border-gray-200 rounded-xl text-xs">
        <div className="flex justify-between font-bold text-gray-800">
          <span>Adversarial Correction Strength:</span>
          <span className="text-[#A142F4] font-mono">Level {strength} / 5 (High Disruption)</span>
        </div>
        <input
          type="range"
          min={1}
          max={5}
          step={1}
          value={strength}
          onChange={(e) => setStrength(Number(e.target.value))}
          className="w-full accent-[#A142F4] cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-gray-400">
          <span>1x Defensive</span>
          <span>3x Balanced</span>
          <span>5x Maximum Disruption</span>
        </div>
      </div>

      {/* Action Controls */}
      <div className="flex items-center justify-between pt-1 text-xs">
        <button
          onClick={() => setEngaged(!engaged)}
          className={`px-3.5 py-1.5 rounded-full font-bold transition-all ${
            engaged ? 'bg-[#A142F4] text-white' : 'bg-gray-200 text-gray-700'
          }`}
        >
          {engaged ? '✓ Adversarial Guardrails Engaged' : 'Engage Guardrails'}
        </button>

        <button
          onClick={handleRecalibrate}
          disabled={isRecalibrating}
          className="px-3.5 py-1.5 rounded-full font-bold bg-[#1A73E8] hover:bg-[#1557B0] text-white flex items-center gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRecalibrating ? 'animate-spin' : ''}`} />
          <span>{isRecalibrating ? 'Recalibrating Weights...' : 'Recalibrate Debiasing Weights'}</span>
        </button>
      </div>
    </div>
  );
};
