import React from 'react';
import { Brain, Quote, Sparkles, CheckCircle2 } from 'lucide-react';
import { Candidate, InferredSoftSkill } from '../../../types';

interface SoftSkillInferencePanelProps {
  candidate?: Candidate;
}

export const SoftSkillInferencePanel: React.FC<SoftSkillInferencePanelProps> = ({ candidate }) => {
  const softSkills: InferredSoftSkill[] = candidate?.inferredSoftSkills || [
    {
      skillName: 'Technical Leadership & Mentorship',
      confidenceScore: 95,
      evidenceSnippets: [
        '"Led team of 5 research engineers while maintaining hands-on code contributions in open source vLLM project."',
        '"Mentored 3 junior software engineers to promotion within 12 months."'
      ]
    },
    {
      skillName: 'Cross-functional Communication',
      confidenceScore: 91,
      evidenceSnippets: [
        '"Partnered directly with product leads and executive stakeholders to define quarterly AI architecture roadmap."'
      ]
    },
    {
      skillName: 'High-Impact Problem Solving',
      confidenceScore: 94,
      evidenceSnippets: [
        '"Reduced p99 inference latency by 42% through custom INT8 quantization under tight production deadlines."'
      ]
    }
  ];

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Soft Skill Inference Engine</h3>
            <p className="text-xs text-gray-500">AI behavioral trait extraction backed by exact resume text quotes</p>
          </div>
        </div>
        <span className="text-xs font-semibold text-[#1A73E8] bg-[#E8F0FE] px-2.5 py-1 rounded-full">
          Behavioral Audit
        </span>
      </div>

      <div className="space-y-3">
        {softSkills.map((sk, idx) => (
          <div key={idx} className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-xs text-gray-900 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#1A73E8]" /> {sk.skillName}
              </h4>
              <span className="text-[11px] font-bold text-[#137333] bg-[#E6F4EA] px-2 py-0.5 rounded-full">
                {sk.confidenceScore}% Confidence
              </span>
            </div>

            {/* Confidence Progress Bar */}
            <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-[#34A853] h-full rounded-full transition-all duration-300"
                style={{ width: `${sk.confidenceScore}%` }}
              />
            </div>

            {/* Evidence Snippets */}
            <div className="pt-1 space-y-1">
              {sk.evidenceSnippets.map((quote, qIdx) => (
                <div key={qIdx} className="text-[11px] text-gray-600 bg-white p-2 rounded border border-gray-200/80 flex items-start gap-1.5">
                  <Quote className="w-3 h-3 text-[#1A73E8] shrink-0 mt-0.5" />
                  <span className="italic">{quote}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
