import React, { useState } from 'react';
import { MapPin, Navigation, Car, Bus, Footprints, AlertTriangle, Sliders } from 'lucide-react';

interface CommuteFilterPanelProps {
  workModeFilter?: string;
  setWorkModeFilter?: (mode: string) => void;
  maxCommuteTime?: number;
  setMaxCommuteTime?: (mins: number) => void;
}

export const CommuteFilterPanel: React.FC<CommuteFilterPanelProps> = ({
  workModeFilter = 'All',
  setWorkModeFilter,
  maxCommuteTime = 45,
  setMaxCommuteTime
}) => {
  const [selectedMode, setSelectedMode] = useState<string>(workModeFilter);
  const [commuteMinutes, setCommuteMinutes] = useState<number>(maxCommuteTime);
  const [travelMode, setTravelMode] = useState<'Transit' | 'Driving' | 'Walking'>('Transit');

  const handleWorkMode = (mode: string) => {
    setSelectedMode(mode);
    if (setWorkModeFilter) setWorkModeFilter(mode);
  };

  const handleCommuteChange = (mins: number) => {
    setCommuteMinutes(mins);
    if (setMaxCommuteTime) setMaxCommuteTime(mins);
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Navigation className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Commute-Aware Filtering & Work-Mode Selector</h3>
            <p className="text-xs text-gray-500">Google Maps route matrix integrated location screening</p>
          </div>
        </div>
        <span className="text-xs font-semibold text-[#1A73E8] bg-[#E8F0FE] px-2.5 py-1 rounded-full">
          Maps API Active
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Work Mode Selector */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-700 block">Work Mode Filter:</label>
          <div className="flex items-center gap-2">
            {['All', 'Remote', 'Hybrid', 'On-Site'].map((mode) => (
              <button
                key={mode}
                onClick={() => handleWorkMode(mode)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                  selectedMode === mode
                    ? 'bg-[#1A73E8] text-white shadow-2xs'
                    : 'bg-[#F1F3F4] text-gray-700 hover:bg-gray-200'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        {/* Commute Time Slider & Travel Mode */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-gray-700">
            <span>Max Commute Threshold:</span>
            <span className="text-[#1A73E8] font-mono">{commuteMinutes} Mins</span>
          </div>
          <input
            type="range"
            min={10}
            max={90}
            step={5}
            value={commuteMinutes}
            onChange={(e) => handleCommuteChange(Number(e.target.value))}
            className="w-full accent-[#1A73E8] cursor-pointer"
          />

          <div className="flex items-center gap-2 pt-1 text-xs">
            <span className="text-gray-500 font-medium">Mode:</span>
            <button
              onClick={() => setTravelMode('Transit')}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 ${
                travelMode === 'Transit' ? 'border-[#1A73E8] bg-[#E8F0FE] text-[#1A73E8] font-bold' : 'border-gray-200 text-gray-600'
              }`}
            >
              <Bus className="w-3.5 h-3.5" /> Transit
            </button>
            <button
              onClick={() => setTravelMode('Driving')}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 ${
                travelMode === 'Driving' ? 'border-[#1A73E8] bg-[#E8F0FE] text-[#1A73E8] font-bold' : 'border-gray-200 text-gray-600'
              }`}
            >
              <Car className="w-3.5 h-3.5" /> Driving
            </button>
            <button
              onClick={() => setTravelMode('Walking')}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 ${
                travelMode === 'Walking' ? 'border-[#1A73E8] bg-[#E8F0FE] text-[#1A73E8] font-bold' : 'border-gray-200 text-gray-600'
              }`}
            >
              <Footprints className="w-3.5 h-3.5" /> Walking
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
