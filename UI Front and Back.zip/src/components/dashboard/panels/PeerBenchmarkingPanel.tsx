import React from 'react';
import { Users, BarChart2, Star, CheckCircle2 } from 'lucide-react';
import { Candidate } from '../../../types';

interface PeerBenchmarkingPanelProps {
  candidate?: Candidate;
}

export const PeerBenchmarkingPanel: React.FC<PeerBenchmarkingPanelProps> = ({ candidate }) => {
  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Peer Benchmarking Comparative Panel</h3>
            <p className="text-xs text-gray-500">Candidate ranking against pool percentile for similar roles</p>
          </div>
        </div>
        <span className="text-xs font-bold text-[#1A73E8] bg-[#E8F0FE] px-2.5 py-1 rounded-full">
          Top 3% Talent Pool
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] text-center space-y-1">
          <span className="text-[10px] font-bold text-gray-500 uppercase">Match Score Percentile</span>
          <p className="text-2xl font-bold text-[#1A73E8]">98th %ile</p>
          <p className="text-[10px] text-gray-400">Outperforms 98% of applicants</p>
        </div>

        <div className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] text-center space-y-1">
          <span className="text-[10px] font-bold text-gray-500 uppercase">Skill Density Index</span>
          <p className="text-2xl font-bold text-[#34A853]">9.4 / 10</p>
          <p className="text-[10px] text-gray-400">High technical depth ratio</p>
        </div>

        <div className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] text-center space-y-1">
          <span className="text-[10px] font-bold text-gray-500 uppercase">Experience Efficiency</span>
          <p className="text-2xl font-bold text-purple-700">1.8x</p>
          <p className="text-[10px] text-gray-400">Accomplishments per year</p>
        </div>
      </div>
    </div>
  );
};
