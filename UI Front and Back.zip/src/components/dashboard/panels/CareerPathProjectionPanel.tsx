import React from 'react';
import { GitCommit, ArrowRight, Compass, Sparkles } from 'lucide-react';

export const CareerPathProjectionPanel: React.FC = () => {
  const Milestones = [
    { title: 'Current Role', role: 'Senior Staff AI Engineer', timeline: 'Present', milestone: 'Core Contributor' },
    { title: 'Next Milestone (12-18 Mos)', role: 'Principal AI Architect / Fellow', timeline: '2027 Target', milestone: 'Org-wide Strategy' },
    { title: 'Long-Term Vision (3-5 Yrs)', role: 'VP of AI Research & Engineering', timeline: '2029 Target', milestone: 'Executive Leader' }
  ];

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Career Path Projection & Next-Level Readiness</h3>
            <p className="text-xs text-gray-500">Predictive growth trajectory over 18 - 36 month window</p>
          </div>
        </div>
        <span className="text-xs font-semibold text-[#1A73E8] bg-[#E8F0FE] px-2.5 py-1 rounded-full">
          AI Career Roadmap
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {Milestones.map((m, idx) => (
          <div key={idx} className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] space-y-2 relative">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-[#1A73E8] bg-[#E8F0FE] px-2 py-0.5 rounded-full">
                {m.title}
              </span>
              <span className="text-[10px] text-gray-400 font-mono">{m.timeline}</span>
            </div>
            <h4 className="font-bold text-xs text-gray-900 mt-1">{m.role}</h4>
            <p className="text-[11px] text-gray-500">{m.milestone}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
