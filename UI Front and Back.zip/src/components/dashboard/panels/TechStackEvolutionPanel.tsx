import React from 'react';
import { Cpu, CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';
import { Candidate, TechStackEvolution } from '../../../types';

interface TechStage {
  yearRange: string;
  primaryTechnologies: string[];
  adoptionPhase: string;
}

interface TechStackEvolutionPanelProps {
  candidate?: Candidate;
}

export const TechStackEvolutionPanel: React.FC<TechStackEvolutionPanelProps> = ({ candidate }) => {
  const evolution: TechStage[] = [
    {
      yearRange: '2018 - 2020',
      primaryTechnologies: ['Python', 'TensorFlow 1.x', 'Scikit-Learn', 'AWS EC2'],
      adoptionPhase: 'Legacy ML Foundation'
    },
    {
      yearRange: '2021 - 2023',
      primaryTechnologies: ['PyTorch 2.0', 'Transformers', 'Kubernetes', 'GCP Vertex AI'],
      adoptionPhase: 'Modern Deep Learning'
    },
    {
      yearRange: '2024 - Present',
      primaryTechnologies: ['vLLM', 'CUDA Kernel Optimization', 'ONNX Runtime', 'FlashAttention-2'],
      adoptionPhase: 'Cutting-Edge LLM Architecture'
    }
  ];

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Tech Stack Evolution Timeline</h3>
            <p className="text-xs text-gray-500">Chronological tech adoption & framework migration trajectory</p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1 text-xs font-bold text-[#137333] bg-[#E6F4EA] px-2.5 py-1 rounded-full">
          <Sparkles className="w-3.5 h-3.5 text-[#34A853]" /> 98% Modern Stack
        </span>
      </div>

      <div className="space-y-3">
        {evolution.map((stage, idx) => (
          <div key={idx} className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#1A73E8] bg-[#E8F0FE] px-2.5 py-0.5 rounded-full">
                {stage.yearRange}
              </span>
              <span className="text-xs font-semibold text-gray-700">{stage.adoptionPhase}</span>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {stage.primaryTechnologies.map((tech, tIdx) => (
                <span
                  key={tIdx}
                  className={`text-[11px] font-mono px-2.5 py-1 rounded-md border ${
                    idx === evolution.length - 1
                      ? 'bg-purple-50 text-purple-900 border-purple-200 font-bold'
                      : 'bg-white text-gray-800 border-gray-200'
                  }`}
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
