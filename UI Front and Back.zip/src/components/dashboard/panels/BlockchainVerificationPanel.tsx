import React, { useState } from 'react';
import { ShieldCheck, ExternalLink, CheckCircle2, Clock, Lock, Sparkles, Key } from 'lucide-react';
import { Candidate, BlockchainCredential } from '../../../types';

interface BlockchainVerificationPanelProps {
  candidate?: Candidate;
}

export const BlockchainVerificationPanel: React.FC<BlockchainVerificationPanelProps> = ({ candidate }) => {
  const [selectedProof, setSelectedProof] = useState<BlockchainCredential | null>(null);

  const credentials: BlockchainCredential[] = candidate?.blockchainCredentials || [
    {
      id: 'bc-1',
      title: 'M.S. Computer Science - Stanford University',
      issuer: 'Stanford Registrar Digital Attestation',
      issuedDate: '2019-06-15',
      ledgerNetwork: 'Ethereum Mainnet',
      txHash: '0x7f8e909bc2ca4966816fd683c7b7f4d4a1b2c3d4',
      verificationStatus: 'verified',
      proofUrl: 'https://etherscan.io/tx/0x7f8e909bc2ca4966'
    },
    {
      id: 'bc-2',
      title: 'Google Cloud Certified Professional ML Engineer',
      issuer: 'Google Cloud Credentials Ledger',
      issuedDate: '2023-04-10',
      ledgerNetwork: 'Polygon PoS',
      txHash: '0x3a12b4c5d6e7f8a90123456789abcdef01234567',
      verificationStatus: 'verified',
      proofUrl: 'https://polygonscan.com/tx/0x3a12b4c5'
    }
  ];

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E6F4EA] text-[#137333] flex items-center justify-center font-bold text-xs">
            <ShieldCheck className="w-5 h-5 text-[#34A853]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Blockchain Credential Verification</h3>
            <p className="text-xs text-gray-500">Cryptographically signed academic degrees & cloud certifications</p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1 text-xs font-bold text-[#137333] bg-[#E6F4EA] px-2.5 py-1 rounded-full">
          <CheckCircle2 className="w-3.5 h-3.5 text-[#34A853]" /> Tamper-Proof
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {credentials.map((cred) => (
          <div key={cred.id} className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] space-y-2 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E6F4EA] text-[#137333]">
                  {cred.ledgerNetwork}
                </span>
                <span className="text-[10px] text-gray-400 font-mono">
                  {cred.txHash.slice(0, 6)}...{cred.txHash.slice(-4)}
                </span>
              </div>
              <h4 className="font-bold text-xs text-gray-900 mt-2">{cred.title}</h4>
              <p className="text-[11px] text-gray-500">{cred.issuer}</p>
            </div>

            <div className="pt-2 border-t border-gray-200 flex items-center justify-between">
              <span className="text-[10px] text-gray-400">Issued: {cred.issuedDate}</span>
              <button
                onClick={() => setSelectedProof(cred)}
                className="text-[11px] font-semibold text-[#1A73E8] hover:underline flex items-center gap-1"
              >
                View Ledger Proof <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Verification Proof Modal / Card */}
      {selectedProof && (
        <div className="bg-[#1E1E1E] text-white p-4 rounded-xl space-y-2 font-mono text-xs animate-fade-in relative">
          <button
            onClick={() => setSelectedProof(null)}
            className="absolute top-2 right-2 text-gray-400 hover:text-white text-xs font-bold px-2 py-0.5 rounded bg-gray-800"
          >
            Close
          </button>
          <div className="flex items-center gap-2 text-emerald-400 font-bold border-b border-gray-700 pb-2">
            <Lock className="w-4 h-4" /> Cryptographic Ledger Proof Verification
          </div>
          <p><span className="text-gray-400">Credential:</span> {selectedProof.title}</p>
          <p><span className="text-gray-400">Issuer Public Key:</span> ed25519:StanfordRegistrarRoot2019</p>
          <p><span className="text-gray-400">Transaction Hash:</span> <span className="text-blue-300 break-all">{selectedProof.txHash}</span></p>
          <p><span className="text-gray-400">Ledger Block:</span> #19,482,091 (Verified 12 Validator Nodes)</p>
          <div className="pt-2 text-right">
            <a
              href={selectedProof.proofUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-emerald-400 hover:underline text-[11px]"
            >
              Open On Block Explorer <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
