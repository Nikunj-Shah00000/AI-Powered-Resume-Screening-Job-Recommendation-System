import React, { useState } from 'react';
import { Sparkles, CheckCircle2, AlertTriangle, RefreshCw, Wand2, Shield, ArrowRight } from 'lucide-react';

export const GenderNeutralJobTuningPanel: React.FC = () => {
  const [jobDescriptionText, setJobDescriptionText] = useState<string>(
    `We are seeking elite coding ninjas and rockstar software engineers to manage man-hours and build aggressive AI solutions. Applicants must be dominant technical leaders capable of managing intense pressure.`
  );

  const [appliedCorrections, setAppliedCorrections] = useState<boolean>(false);

  const flaggedWords = [
    { word: 'ninjas', replacement: 'engineering specialists', type: 'Masculine-coded jargon' },
    { word: 'rockstar', replacement: 'high-performing', type: 'Exclusionary cliché' },
    { word: 'man-hours', replacement: 'working hours', type: 'Gender-biased term' },
    { word: 'dominant', replacement: 'collaborative', type: 'Aggressive bias' }
  ];

  const handleApplyCorrections = () => {
    let corrected = jobDescriptionText;
    flaggedWords.forEach((item) => {
      corrected = corrected.replace(new RegExp(item.word, 'gi'), item.replacement);
    });
    setJobDescriptionText(corrected);
    setAppliedCorrections(true);
  };

  const handleReset = () => {
    setJobDescriptionText(
      `We are seeking elite coding ninjas and rockstar software engineers to manage man-hours and build aggressive AI solutions. Applicants must be dominant technical leaders capable of managing intense pressure.`
    );
    setAppliedCorrections(false);
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#FEF7E0] text-[#B06000] flex items-center justify-center font-bold text-xs">
            <Wand2 className="w-5 h-5 text-[#B06000]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Gender-Neutral Job Tuning & Inclusivity Auditor</h3>
            <p className="text-xs text-gray-500">Detects biased terminology and suggests inclusive alternatives</p>
          </div>
        </div>

        {/* Score & Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E6F4EA] text-[#137333] text-xs font-bold">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#34A853]" />
            <span>Inclusivity Score: {appliedCorrections ? '98%' : '64%'}</span>
          </div>

          <button
            onClick={handleReset}
            className="p-1.5 rounded-lg border border-gray-200 text-gray-500 hover:text-gray-900 hover:bg-gray-100"
            title="Re-Audit Text"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Flagged Words Breakdown Chips */}
      <div className="space-y-2">
        <span className="text-[11px] font-bold text-gray-600 uppercase tracking-wider block">
          {appliedCorrections ? 'All Flagged Words Corrected:' : 'Flagged Terminology & Suggested Alternatives:'}
        </span>

        <div className="flex flex-wrap gap-2">
          {flaggedWords.map((item, idx) => (
            <div
              key={idx}
              className={`px-2.5 py-1.5 rounded-xl border text-xs flex items-center gap-2 transition-all ${
                appliedCorrections
                  ? 'border-[#34A853]/40 bg-[#E6F4EA] text-[#137333]'
                  : 'border-[#FBBC05]/60 bg-[#FEF7E0] text-[#B06000]'
              }`}
            >
              <span className="font-bold line-through opacity-70">{item.word}</span>
              <ArrowRight className="w-3 h-3 text-gray-400" />
              <span className="font-bold text-[#137333] bg-white px-2 py-0.5 rounded-md shadow-2xs">
                {item.replacement}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Editor & AI Correction Actions */}
      <div className="space-y-2">
        <textarea
          value={jobDescriptionText}
          onChange={(e) => setJobDescriptionText(e.target.value)}
          rows={3}
          className="w-full text-xs font-sans p-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#1A73E8] bg-[#F8F9FA]"
        />

        <div className="flex items-center justify-between pt-1">
          <span className="text-[11px] text-gray-500 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-[#1A73E8]" /> Powered by Gemini Inclusive Tone Optimizer
          </span>

          <button
            onClick={handleApplyCorrections}
            disabled={appliedCorrections}
            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all shadow-2xs flex items-center gap-1.5 ${
              appliedCorrections
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                : 'bg-[#34A853] hover:bg-[#2d9248] text-white'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>{appliedCorrections ? '✓ Tone Corrected' : 'Apply AI Tone Corrections'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
