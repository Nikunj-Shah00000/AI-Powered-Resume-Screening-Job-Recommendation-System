import React, { useState } from 'react';
import { Activity, RefreshCw, Sliders, CheckCircle2, ArrowRight } from 'lucide-react';

export const DynamicThresholdingPanel: React.FC = () => {
  const [isAuto, setIsAuto] = useState(true);
  const [targetVolume, setTargetVolume] = useState(20);
  const [customThreshold, setCustomThreshold] = useState(74);
  const [isRecalibrating, setIsRecalibrating] = useState(false);

  const calculatedThreshold = isAuto ? 74 : customThreshold;

  const handleRecalibrate = () => {
    setIsRecalibrating(true);
    setTimeout(() => {
      setIsRecalibrating(false);
    }, 1000);
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Activity className="w-5 h-5 text-[#1A73E8]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Dynamic Threshold Optimizer & Pool Depth Scaler</h3>
            <p className="text-xs text-gray-500">Auto-calibrates shortlist cutoffs based on applicant density and target volume</p>
          </div>
        </div>

        {/* Real-time Pulsing Status */}
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#34A853] opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#34A853]" />
          </span>
          <span className="text-xs font-bold text-[#137333] bg-[#E6F4EA] px-2.5 py-0.5 rounded-full">
            Passing Threshold: {calculatedThreshold}% Match
          </span>
        </div>
      </div>

      {/* Pool Distribution Bar */}
      <div className="p-3.5 rounded-xl border border-gray-200 bg-[#F8F9FA] space-y-2 text-xs">
        <div className="flex justify-between font-bold text-gray-800">
          <span>Active Requisition Talent Pipeline (250 Applicants)</span>
          <span className="text-[#1A73E8] font-mono">Target Interview Capacity: {targetVolume}</span>
        </div>

        {/* Stacked Pool Depth Meter */}
        <div className="w-full bg-gray-200 h-4 rounded-lg overflow-hidden flex relative">
          <div className="bg-[#1A73E8] h-full" style={{ width: '15%' }} title="Target Shortlist (20)" />
          <div className="bg-[#FBBC05] h-full" style={{ width: '25%' }} title="Under Review (50)" />
          <div className="bg-gray-400 h-full" style={{ width: '60%' }} title="Filtered Below Threshold (180)" />

          {/* Shifting Cutoff Line */}
          <div className="absolute top-0 bottom-0 left-[15%] border-r-2 border-red-500 z-10" />
        </div>

        <div className="flex items-center justify-between text-[11px] text-gray-500 pt-1">
          <span className="flex items-center gap-1 text-[#1A73E8] font-bold">
            <span className="w-2 h-2 rounded-full bg-[#1A73E8]" /> Top Tier Interviewees ({targetVolume})
          </span>
          <span className="flex items-center gap-1 text-[#B06000] font-bold">
            <span className="w-2 h-2 rounded-full bg-[#FBBC05]" /> Under Review (50)
          </span>
          <span className="flex items-center gap-1 text-gray-500 font-bold">
            <span className="w-2 h-2 rounded-full bg-gray-400" /> Screened Out (180)
          </span>
        </div>
      </div>

      {/* Controls & Configuration */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        <div className="p-3 rounded-xl border border-gray-200 bg-white flex items-center justify-between">
          <span className="font-bold text-gray-800">Mode: {isAuto ? 'AI Auto-Threshold' : 'Manual Fixed Cutoff'}</span>
          <button
            onClick={() => setIsAuto(!isAuto)}
            className={`px-3 py-1 rounded-full font-bold transition-all ${
              isAuto ? 'bg-[#1A73E8] text-white' : 'bg-gray-200 text-gray-700'
            }`}
          >
            {isAuto ? 'Auto Active' : 'Switch to Auto'}
          </button>
        </div>

        <div className="p-3 rounded-xl border border-gray-200 bg-white flex items-center justify-between">
          <span className="font-bold text-gray-800">Target Interviewees:</span>
          <input
            type="number"
            min={5}
            max={100}
            value={targetVolume}
            onChange={(e) => setTargetVolume(Number(e.target.value))}
            className="w-16 px-2 py-1 bg-[#F8F9FA] border border-gray-300 rounded font-mono text-center font-bold"
          />
        </div>
      </div>

      {/* Action */}
      <div className="flex justify-end pt-1">
        <button
          onClick={handleRecalibrate}
          disabled={isRecalibrating}
          className="px-4 py-1.5 rounded-full bg-[#1A73E8] hover:bg-[#1557B0] text-white text-xs font-bold transition-all shadow-2xs flex items-center gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRecalibrating ? 'animate-spin' : ''}`} />
          <span>{isRecalibrating ? 'Recalibrating Pool...' : 'Recalibrate Requisition Pool'}</span>
        </button>
      </div>
    </div>
  );
};
