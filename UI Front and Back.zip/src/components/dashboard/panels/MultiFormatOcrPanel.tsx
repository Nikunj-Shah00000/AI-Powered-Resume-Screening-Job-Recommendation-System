import React, { useState } from 'react';
import { FileCode, Copy, Check, Eye, RefreshCw, FileText, Sparkles, Image as ImageIcon } from 'lucide-react';
import { Candidate } from '../../../types';

interface MultiFormatOcrPanelProps {
  candidate?: Candidate;
  fileName?: string;
  rawText?: string;
}

export const MultiFormatOcrPanel: React.FC<MultiFormatOcrPanelProps> = ({
  candidate,
  fileName = 'Resume_Document.pdf',
  rawText
}) => {
  const [viewMode, setViewMode] = useState<'split' | 'text' | 'image'>('split');
  const [copied, setCopied] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);

  const textContent = rawText || candidate?.ocrExtractedText || `MAYA LIN - SENIOR STAFF AI/ML ENGINEER
Email: maya.lin@example.com | Phone: +1 (415) 892-0129 | Location: San Francisco, CA
SUMMARY: Senior ML Engineer with 8 years of experience building scalable transformer architectures, fine-tuning LLMs on GCP Vertex AI, and deploying PyTorch inference pipelines in production. Published researcher with 3 papers at NeurIPS.
EXPERIENCE:
- Anthro AI (2023 - Present): Staff AI Engineer - Architected LLM serving processing 50M+ daily tokens with PyTorch and vLLM. Reduced p99 latency by 42%.
- Tech Labs (2019 - 2023): Senior ML Researcher - Trained custom transformer models for document parsing.
EDUCATION: M.S. CS Stanford University, B.S. EE UC Berkeley`;

  const fileExt = (fileName.split('.').pop() || 'pdf').toUpperCase();

  const handleCopy = () => {
    navigator.clipboard.writeText(textContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReExtract = () => {
    setIsExtracting(true);
    setTimeout(() => setIsExtracting(false), 1200);
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      {/* Panel Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <FileCode className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-gray-900">Multi-Format OCR Status & Visualizer</h3>
              {/* File Format Indicator Badge */}
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                fileExt === 'PDF' ? 'bg-red-50 text-red-600 border border-red-200' :
                fileExt === 'PNG' || fileExt === 'JPG' || fileExt === 'JPEG' ? 'bg-purple-50 text-purple-600 border border-purple-200' :
                'bg-blue-50 text-blue-600 border border-blue-200'
              }`}>
                {fileExt} Document
              </span>
            </div>
            <p className="text-xs text-gray-500">Google Drive style multi-modal document conversion engine</p>
          </div>
        </div>

        {/* View Controls & Actions */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div className="inline-flex p-0.5 bg-[#F1F3F4] rounded-full text-xs font-medium border border-[#E8EAED]">
            <button
              onClick={() => setViewMode('split')}
              className={`px-2.5 py-1 rounded-full transition-all ${
                viewMode === 'split' ? 'bg-white text-[#1A73E8] font-bold shadow-2xs' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Split View
            </button>
            <button
              onClick={() => setViewMode('text')}
              className={`px-2.5 py-1 rounded-full transition-all ${
                viewMode === 'text' ? 'bg-white text-[#1A73E8] font-bold shadow-2xs' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Raw Text
            </button>
            <button
              onClick={() => setViewMode('image')}
              className={`px-2.5 py-1 rounded-full transition-all ${
                viewMode === 'image' ? 'bg-white text-[#1A73E8] font-bold shadow-2xs' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Original
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#E8F0FE] hover:bg-[#D2E3FC] text-[#1A73E8] rounded-full text-xs font-medium transition-all"
            title="Copy extracted raw text to clipboard"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#34A853]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Text'}</span>
          </button>
        </div>
      </div>

      {/* OCR Status & Progress Bar */}
      <div className="bg-[#F8F9FA] p-3 rounded-xl border border-[#E8EAED]">
        <div className="flex items-center justify-between text-xs font-medium mb-1.5">
          <span className="flex items-center gap-1.5 text-gray-700">
            <Sparkles className="w-3.5 h-3.5 text-[#1A73E8] animate-spin" />
            {isExtracting ? 'OCR Text Extraction in Progress...' : 'Multi-Modal OCR Processed & Verified'}
          </span>
          <span className="text-[#137333] font-bold bg-[#E6F4EA] px-2 py-0.5 rounded-full text-[10px]">
            100% Text Confidence
          </span>
        </div>
        <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-[#1A73E8] via-[#4285F4] to-[#34A853] h-full transition-all duration-500"
            style={{ width: isExtracting ? '65%' : '100%' }}
          />
        </div>
      </div>

      {/* Split Pane / Text Visualizer */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {(viewMode === 'split' || viewMode === 'image') && (
          <div className="bg-[#F1F3F4] rounded-xl p-4 border border-gray-300 min-h-[180px] flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-gray-600 font-medium mb-2 pb-1 border-b border-gray-300">
              <span className="flex items-center gap-1">
                <ImageIcon className="w-3.5 h-3.5 text-gray-700" /> Original Rendered Document
              </span>
              <span className="text-[10px] bg-white px-2 py-0.5 rounded text-gray-500 font-mono">{fileName}</span>
            </div>
            <div className="bg-white rounded-lg p-3 shadow-xs border border-gray-200 font-serif text-xs text-gray-800 space-y-1.5 overflow-y-auto max-h-[160px]">
              <div className="font-bold text-sm border-b pb-1 text-gray-900">{candidate?.name || 'Maya Lin'}</div>
              <p className="text-[11px] text-gray-600">{candidate?.summary || textContent.slice(0, 150)}...</p>
              <div className="pt-1 text-[10px] text-gray-400 italic">Rendered Page 1 of 1</div>
            </div>
            <div className="mt-2 text-right">
              <button
                onClick={handleReExtract}
                className="text-[11px] text-[#1A73E8] hover:underline inline-flex items-center gap-1"
              >
                <RefreshCw className={`w-3 h-3 ${isExtracting ? 'animate-spin' : ''}`} /> Re-Scan OCR Layer
              </button>
            </div>
          </div>
        )}

        {(viewMode === 'split' || viewMode === 'text') && (
          <div className={`bg-[#1E1E1E] text-[#D4D4D4] rounded-xl p-4 font-mono text-xs overflow-y-auto max-h-[220px] ${
            viewMode === 'text' ? 'md:col-span-2' : ''
          }`}>
            <div className="flex items-center justify-between text-[11px] text-gray-400 pb-2 border-b border-gray-700 mb-2">
              <span className="flex items-center gap-1 text-[#4FC3F7]">
                <FileText className="w-3 h-3" /> Extracted Raw OCR Text Stream
              </span>
              <span className="text-[10px] text-[#81C784]">UTF-8 Verified</span>
            </div>
            <pre className="whitespace-pre-wrap leading-relaxed text-[11px] text-emerald-300 font-mono selection:bg-[#1A73E8] selection:text-white">
              {textContent}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
