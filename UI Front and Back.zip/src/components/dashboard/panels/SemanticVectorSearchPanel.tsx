import React, { useState } from 'react';
import { Sparkles, Search, Sliders, CheckCircle2, ArrowRightLeft } from 'lucide-react';

interface SemanticVectorSearchPanelProps {
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
  searchMode?: 'keyword' | 'vector';
  setSearchMode?: (mode: 'keyword' | 'vector') => void;
}

export const SemanticVectorSearchPanel: React.FC<SemanticVectorSearchPanelProps> = ({
  searchQuery = '',
  setSearchQuery,
  searchMode = 'vector',
  setSearchMode
}) => {
  const [localMode, setLocalMode] = useState<'keyword' | 'vector'>(searchMode);

  const conceptMappings = [
    { candidateTerm: 'Large Language Model Fine-Tuning', jobTerm: 'Transformer Architecture Optimization', similarity: 0.96 },
    { candidateTerm: 'vLLM & INT8 Quantization', jobTerm: 'High-Throughput Model Serving', similarity: 0.94 },
    { candidateTerm: 'Vertex AI Pipelines', jobTerm: 'Google Cloud Infrastructure', similarity: 0.92 }
  ];

  const handleModeChange = (mode: 'keyword' | 'vector') => {
    setLocalMode(mode);
    if (setSearchMode) setSearchMode(mode);
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Semantic Vector Search & Matching Engine</h3>
            <p className="text-xs text-gray-500">Gemini Embedding-004 multidimensional concept mapping</p>
          </div>
        </div>

        {/* Dual Mode Switcher */}
        <div className="inline-flex p-1 bg-[#F1F3F4] rounded-full text-xs font-semibold border border-[#E8EAED]">
          <button
            onClick={() => handleModeChange('keyword')}
            className={`px-3 py-1 rounded-full transition-all ${
              localMode === 'keyword' ? 'bg-white text-[#1A73E8] shadow-2xs' : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Exact Keyword
          </button>
          <button
            onClick={() => handleModeChange('vector')}
            className={`px-3 py-1 rounded-full transition-all flex items-center gap-1 ${
              localMode === 'vector' ? 'bg-[#1A73E8] text-white shadow-2xs' : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Sparkles className="w-3 h-3" /> AI Vector Embeddings
          </button>
        </div>
      </div>

      {/* Concept Mapping Chips */}
      {localMode === 'vector' && (
        <div className="space-y-2 bg-[#F8F9FA] p-3.5 rounded-xl border border-[#E8EAED]">
          <span className="text-[11px] font-bold text-gray-700 uppercase tracking-wider block">
            Implicit Concept Mapping Pairs (768-Dim Vector Space):
          </span>
          <div className="space-y-2">
            {conceptMappings.map((pair, idx) => (
              <div key={idx} className="bg-white p-2.5 rounded-lg border border-gray-200 text-xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 truncate">
                  <span className="font-semibold text-gray-900 truncate">{pair.candidateTerm}</span>
                  <ArrowRightLeft className="w-3.5 h-3.5 text-[#1A73E8] shrink-0" />
                  <span className="font-semibold text-gray-700 truncate">{pair.jobTerm}</span>
                </div>
                <span className="font-mono text-[11px] font-bold text-[#137333] bg-[#E6F4EA] px-2 py-0.5 rounded shrink-0">
                  {pair.similarity} Cosine Sim
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
