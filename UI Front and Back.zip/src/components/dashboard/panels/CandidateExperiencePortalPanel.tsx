import React, { useState } from 'react';
import {
  MessageSquare,
  FileText,
  Calendar,
  CheckCircle2,
  DollarSign,
  Mic,
  Bell,
  Code,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Send,
  X,
  Volume2,
  PhoneCall,
  Mail,
  Sliders,
  Award
} from 'lucide-react';

export const CandidateExperiencePortalPanel: React.FC = () => {
  // Chat Widget State
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState([
    { sender: 'bot', text: 'Hello! I am your AI Career Assistant. Ask me anything about job requirements, interview prep, or application status!' }
  ]);

  // Voice Resume State
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);

  // Scheduler State
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  // Omni-Channel Alert State
  const [whatsappAlert, setWhatsappAlert] = useState(true);
  const [smsAlert, setSmsAlert] = useState(true);
  const [emailAlert, setEmailAlert] = useState(true);
  const [probabilityFloor, setProbabilityFloor] = useState(85);

  const pipelineSteps = [
    { title: 'Applied', status: 'completed', date: 'Aug 2' },
    { title: 'Screening Passed', status: 'completed', date: 'Aug 4' },
    { title: 'Assessment', status: 'active', date: 'Aug 6' },
    { title: 'Interview Scheduled', status: 'pending', date: 'Aug 10' },
    { title: 'Offer Decision', status: 'pending', date: 'TBD' }
  ];

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    const userMsg = chatInput;
    setChatMessages((prev) => [...prev, { sender: 'user', text: userMsg }]);
    setChatInput('');

    setTimeout(() => {
      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'bot',
          text: `Regarding "${userMsg}": Your profile match score is 96%. You exceed the required PyTorch experience and align well with the team's research focus.`
        }
      ]);
    }, 800);
  };

  const handleToggleRecord = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      setRecordingTime(1);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#1A73E8] via-[#4285F4] to-[#34A853] p-6 rounded-2xl text-white shadow-sm space-y-2">
        <div className="flex items-center gap-2 text-xs font-bold bg-white/20 px-3 py-1 rounded-full w-fit backdrop-blur-xs">
          <Sparkles className="w-3.5 h-3.5" /> Candidate Portal & Engagement Hub
        </div>
        <h1 className="text-xl font-bold font-sans">AI-Guided Candidate Experience Suite</h1>
        <p className="text-xs text-white/90 max-w-2xl">
          Real-time application progress tracking, AI resume builder, smart calendar scheduler, and instant feedback loops.
        </p>
      </div>

      {/* Grid: Pizza Tracker + Predictive Salary Chip */}
      <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-900">Pizza-Tracker Application Progress Pipeline</h3>
              <p className="text-xs text-gray-500">Google Fi style real-time requisition lifecycle tracker</p>
            </div>
          </div>

          {/* Predictive Salary Valuation Chip */}
          <div className="px-3.5 py-1.5 rounded-full bg-[#E6F4EA] border border-[#34A853]/30 text-[#137333] text-xs font-bold flex items-center gap-1.5">
            <DollarSign className="w-4 h-4 text-[#34A853]" />
            <span>AI Valuation: $185,000 - $225,000 / yr</span>
          </div>
        </div>

        {/* Step Indicator Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 pt-2">
          {pipelineSteps.map((step, idx) => (
            <div key={idx} className="p-3 rounded-xl border border-gray-200 bg-[#F8F9FA] space-y-1.5 text-center relative">
              <div
                className={`w-6 h-6 rounded-full mx-auto flex items-center justify-center text-xs font-bold ${
                  step.status === 'completed'
                    ? 'bg-[#34A853] text-white'
                    : step.status === 'active'
                    ? 'bg-[#1A73E8] text-white animate-pulse'
                    : 'bg-gray-200 text-gray-500'
                }`}
              >
                {step.status === 'completed' ? '✓' : idx + 1}
              </div>
              <h4 className="font-bold text-xs text-gray-900">{step.title}</h4>
              <span className="text-[10px] text-gray-400 font-mono">{step.date}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Grid: Docs Builder + Voice Resume */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* AI Resume Builder (Google Docs Style) */}
        <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#1A73E8]" />
              <h3 className="text-sm font-bold text-gray-900">AI Resume Builder & Workspace</h3>
            </div>
            <span className="text-[11px] font-bold text-[#137333] bg-[#E6F4EA] px-2.5 py-1 rounded-full">
              Syntax Optimized (98%)
            </span>
          </div>

          <div className="p-4 bg-[#F8F9FA] border border-gray-200 rounded-xl space-y-2 text-xs font-mono">
            <p className="font-bold text-gray-900">MAYA LIN — STAFF AI ENGINEER</p>
            <p className="text-gray-600">
              Senior Machine Learning Architect with 8+ years scaling PyTorch models on Vertex AI...
            </p>
            <div className="pt-2 border-t border-gray-200 flex flex-wrap gap-1.5">
              <span className="text-[10px] bg-[#E8F0FE] text-[#1A73E8] px-2 py-0.5 rounded font-sans font-bold">
                + Keyword Added: Distributed Training
              </span>
              <span className="text-[10px] bg-[#E6F4EA] text-[#137333] px-2 py-0.5 rounded font-sans font-bold">
                + Metric Tailored: p99 Latency &lt; 12ms
              </span>
            </div>
          </div>
        </div>

        {/* Voice Resume Input Hub */}
        <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
            <div className="flex items-center gap-2">
              <Mic className="w-5 h-5 text-[#EA4335]" />
              <h3 className="text-sm font-bold text-gray-900">Voice Resume Input Hub</h3>
            </div>
            <span className="text-xs text-gray-500">Audio Speech-to-Text Parsing</span>
          </div>

          <div className="p-4 bg-[#F8F9FA] border border-gray-200 rounded-xl flex flex-col items-center justify-center space-y-3">
            <button
              onClick={handleToggleRecord}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                isRecording ? 'bg-[#EA4335] text-white animate-pulse' : 'bg-[#E8F0FE] text-[#1A73E8] hover:bg-[#1A73E8] hover:text-white'
              }`}
            >
              <Mic className="w-6 h-6" />
            </button>
            <span className="text-xs font-bold text-gray-800">
              {isRecording ? 'Recording Audio Intro... (Click to Stop)' : 'Record 60-Sec Voice Summary'}
            </span>
            {isRecording && (
              <div className="flex items-center gap-1 text-[#EA4335] text-xs font-mono">
                <Volume2 className="w-4 h-4 animate-bounce" /> Waveform Active
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Grid: Smart Scheduler + Gamified Challenge */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Smart Interview Scheduler */}
        <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#1A73E8]" />
              <h3 className="text-sm font-bold text-gray-900">Smart Interview Scheduler (Google Calendar Style)</h3>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
            {['Aug 10 - 10:00 AM', 'Aug 10 - 02:00 PM', 'Aug 11 - 11:30 AM', 'Aug 11 - 04:00 PM'].map((slot) => (
              <button
                key={slot}
                onClick={() => setSelectedSlot(slot)}
                className={`p-2.5 rounded-xl border font-bold transition-all ${
                  selectedSlot === slot
                    ? 'border-[#1A73E8] bg-[#E8F0FE] text-[#1A73E8]'
                    : 'border-gray-200 bg-[#F8F9FA] text-gray-700 hover:bg-gray-100'
                }`}
              >
                {slot}
              </button>
            ))}
          </div>
          {selectedSlot && (
            <p className="text-xs text-[#137333] font-bold bg-[#E6F4EA] p-2 rounded-lg text-center">
              ✓ Slot Booked: {selectedSlot} (Google Meet link generated)
            </p>
          )}
        </div>

        {/* Gamified Assessment Challenge Launcher */}
        <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
            <div className="flex items-center gap-2">
              <Code className="w-5 h-5 text-[#A142F4]" />
              <h3 className="text-sm font-bold text-gray-900">Gamified Skill Assessment Launcher</h3>
            </div>
            <span className="text-xs font-bold text-[#A142F4] bg-[#F3E8FD] px-2 py-0.5 rounded-full">
              Replaces Lengthy Tests
            </span>
          </div>

          <div className="p-3.5 bg-[#F8F9FA] border border-gray-200 rounded-xl space-y-2">
            <h4 className="font-bold text-xs text-gray-900">⚡ 5-Minute Code Refactor Challenge</h4>
            <p className="text-xs text-gray-500">
              Optimize a PyTorch tensor operation pipeline to prove hands-on proficiency.
            </p>
            <button
              onClick={() => alert('Launching 5-Minute Refactor Simulator...')}
              className="px-4 py-1.5 bg-[#A142F4] hover:bg-[#8e32e0] text-white text-xs font-bold rounded-full transition-all shadow-2xs"
            >
              Start Challenge
            </button>
          </div>
        </div>
      </div>

      {/* Omni-Channel Alert Configurator */}
      <div className="m3-card p-5 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-[#1A73E8]" />
            <h3 className="text-sm font-bold text-gray-900">Omni-Channel Alert & High-Probability Filter</h3>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Checkboxes */}
          <div className="space-y-2">
            <span className="font-bold text-gray-800 block">Notification Channels:</span>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={whatsappAlert}
                onChange={(e) => setWhatsappAlert(e.target.checked)}
                className="accent-[#34A853]"
              />
              <span>WhatsApp Alerts</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={smsAlert}
                onChange={(e) => setSmsAlert(e.target.checked)}
                className="accent-[#1A73E8]"
              />
              <span>SMS Direct Messaging</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={emailAlert}
                onChange={(e) => setEmailAlert(e.target.checked)}
                className="accent-[#1A73E8]"
              />
              <span>Email Updates</span>
            </label>
          </div>

          {/* High Probability Threshold Slider */}
          <div className="space-y-2">
            <div className="flex justify-between font-bold text-gray-800">
              <span>High-Probability Alert Match Floor:</span>
              <span className="text-[#1A73E8] font-mono">{probabilityFloor}% Match</span>
            </div>
            <input
              type="range"
              min={70}
              max={95}
              value={probabilityFloor}
              onChange={(e) => setProbabilityFloor(Number(e.target.value))}
              className="w-full accent-[#1A73E8] cursor-pointer"
            />
            <p className="text-[10px] text-gray-400">Notifications fire exclusively when match confidence exceeds threshold.</p>
          </div>
        </div>
      </div>

      {/* Floating Collapsible RAG Chatbot Widget */}
      <div className="fixed bottom-6 right-6 z-50">
        {!chatOpen ? (
          <button
            onClick={() => setChatOpen(true)}
            className="p-4 bg-[#1A73E8] hover:bg-[#1557B0] text-white rounded-full shadow-lg flex items-center gap-2 font-bold text-xs transition-transform hover:scale-105"
          >
            <MessageSquare className="w-5 h-5" />
            <span>AI Career Assistant</span>
          </button>
        ) : (
          <div className="w-80 sm:w-96 bg-white border border-gray-300 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-96">
            <div className="p-3.5 bg-[#1A73E8] text-white flex items-center justify-between font-bold text-xs">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>RAG Assistant (Google Business Style)</span>
              </div>
              <button onClick={() => setChatOpen(false)} className="p-1 hover:bg-white/20 rounded">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 p-3 overflow-y-auto space-y-2 text-xs">
              {chatMessages.map((msg, i) => (
                <div
                  key={i}
                  className={`p-2.5 rounded-xl max-w-[85%] ${
                    msg.sender === 'user'
                      ? 'bg-[#1A73E8] text-white ml-auto'
                      : 'bg-[#F1F3F4] text-gray-800 mr-auto'
                  }`}
                >
                  {msg.text}
                </div>
              ))}
            </div>

            <div className="p-2 border-t border-gray-200 flex gap-1.5 bg-[#F8F9FA]">
              <input
                type="text"
                placeholder="Ask about role requirements..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 px-3 py-1.5 text-xs bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#1A73E8]"
              />
              <button
                onClick={handleSendMessage}
                className="p-2 bg-[#1A73E8] hover:bg-[#1557B0] text-white rounded-xl"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
