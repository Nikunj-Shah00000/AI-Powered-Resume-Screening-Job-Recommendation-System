import React from 'react';
import { Building2, Info, Award, Shield } from 'lucide-react';
import { Candidate, CompanyExperience } from '../../../types';

interface CompanyTierPanelProps {
  candidate?: Candidate;
}

export const CompanyTierPanel: React.FC<CompanyTierPanelProps> = ({ candidate }) => {
  const experiences: CompanyExperience[] = candidate?.companyHistory || [
    {
      id: 'comp-1',
      companyName: 'Anthro AI',
      roleTitle: 'Staff AI Engineer',
      startDate: '2023-01',
      endDate: 'Present',
      tier: 'Tier 1 (FAANG / Frontier AI)',
      criteriaTooltip: 'Tier 1: Top-tier Frontier AI lab / Big Tech company with world-class engineering standards.',
      durationMonths: 43
    },
    {
      id: 'comp-2',
      companyName: 'Tech Labs',
      roleTitle: 'Senior ML Researcher',
      startDate: '2019-01',
      endDate: '2022-12',
      tier: 'Tier 2 (Unicorn / Fortune 500)',
      criteriaTooltip: 'Tier 2: High-growth unicorn or Fortune 500 technology organization.',
      durationMonths: 48
    }
  ];

  const getTierBadgeStyle = (tier: string) => {
    if (tier.includes('Tier 1')) return 'bg-purple-100 text-purple-900 border-purple-300';
    if (tier.includes('Tier 2')) return 'bg-blue-100 text-blue-900 border-blue-300';
    if (tier.includes('Tier 3')) return 'bg-emerald-100 text-emerald-900 border-emerald-300';
    return 'bg-amber-100 text-amber-900 border-amber-300';
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Company Tier Classification</h3>
            <p className="text-xs text-gray-500">AI-indexed pedigree tiers for past employers & organizations</p>
          </div>
        </div>
        <span className="text-xs font-semibold text-[#1A73E8] bg-[#E8F0FE] px-2.5 py-1 rounded-full">
          Pedigree Auditor
        </span>
      </div>

      <div className="space-y-3">
        {experiences.map((exp) => (
          <div key={exp.id} className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-sm text-gray-900">{exp.companyName}</h4>
                {/* Tier Badge with Tooltip */}
                <span
                  title={exp.criteriaTooltip}
                  className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border cursor-help ${getTierBadgeStyle(exp.tier)}`}
                >
                  {exp.tier}
                </span>
              </div>
              <p className="text-xs text-gray-600 font-medium mt-0.5">{exp.roleTitle}</p>
              <p className="text-[11px] text-gray-400 mt-0.5">
                {exp.startDate} — {exp.endDate} ({exp.durationMonths} mos)
              </p>
            </div>

            <div className="text-right shrink-0 text-xs text-gray-500">
              <span className="inline-flex items-center gap-1 text-[11px] font-medium text-gray-700 bg-white px-2.5 py-1 rounded-md border border-gray-200">
                <Award className="w-3.5 h-3.5 text-[#FBBC04]" /> Verified Work History
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
