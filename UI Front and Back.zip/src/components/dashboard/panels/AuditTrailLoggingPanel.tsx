import React, { useState } from 'react';
import { History, ShieldCheck, Download, Search, ChevronDown, ChevronUp, Lock, FileCode } from 'lucide-react';

export const AuditTrailLoggingPanel: React.FC = () => {
  const [severityFilter, setSeverityFilter] = useState<'all' | 'info' | 'warning' | 'critical'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedRow, setExpandedRow] = useState<string | null>(null);

  const logs = [
    {
      id: 'log-101',
      timestamp: '2026-08-07 10:42:18 UTC',
      eventType: 'AI Score Generation',
      actor: 'System Engine (Gemini 3.6)',
      hash: '0x8f192a91',
      severity: 'info',
      delta: {
        candidateId: 'cand-1',
        previousScore: 92,
        updatedScore: 96,
        reason: 'Added verified portfolio GitHub commits and GCP certification proof.'
      }
    },
    {
      id: 'log-102',
      timestamp: '2026-08-07 09:15:02 UTC',
      eventType: 'Candidate Unmasked (Override)',
      actor: 'Recruiter #402 (Sarah Chen)',
      hash: '0x4e28b1a3',
      severity: 'warning',
      delta: {
        candidateId: 'cand-2',
        action: 'Manual Blind Screening Override',
        reason: 'Recruiter requested interview logistics contact unmasking.'
      }
    },
    {
      id: 'log-103',
      timestamp: '2026-08-07 08:30:45 UTC',
      eventType: 'Weight Configuration Shift',
      actor: 'System Engine',
      hash: '0x1c99f012',
      severity: 'info',
      delta: {
        previousWeights: { merit: 40, diversity: 30, trajectory: 30 },
        newWeights: { merit: 45, diversity: 30, trajectory: 25 },
        recalibratedCount: 24
      }
    },
    {
      id: 'log-104',
      timestamp: '2026-08-06 18:22:10 UTC',
      eventType: 'Adversarial Debiasing Recalibration',
      actor: 'Compliance Auditor #12',
      hash: '0x99a410ef',
      severity: 'info',
      delta: {
        demographicParityBaseline: '94.8%',
        fourFifthsCheck: 'Passed (Disparate Impact Ratio: 0.94)'
      }
    }
  ];

  const handleDownloadLog = () => {
    const jsonStr = JSON.stringify(logs, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-compliance-log-${Date.now()}.json`;
    a.click();
  };

  const filtered = logs.filter((log) => {
    if (severityFilter !== 'all' && log.severity !== severityFilter) return false;
    if (searchTerm && !log.eventType.toLowerCase().includes(searchTerm.toLowerCase()) && !log.actor.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="m3-card p-6 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <History className="w-5 h-5 text-[#1A73E8]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Compliance Audit Log & Cryptographic Ledger</h3>
            <p className="text-xs text-gray-500">Immutable ledger of automated AI scoring decisions and human overrides</p>
          </div>
        </div>

        <button
          onClick={handleDownloadLog}
          className="px-3.5 py-1.5 rounded-full bg-[#1A73E8] hover:bg-[#1557B0] text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download JSON Audit Log</span>
        </button>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search event type or actor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-[#F8F9FA] border border-[#E8EAED] rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-[#1A73E8]"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="text-gray-500 font-medium">Severity:</span>
          {['all', 'info', 'warning', 'critical'].map((sev) => (
            <button
              key={sev}
              onClick={() => setSeverityFilter(sev as any)}
              className={`px-2.5 py-1 rounded-full text-[11px] font-semibold uppercase ${
                severityFilter === sev ? 'bg-[#1A73E8] text-white' : 'bg-[#F1F3F4] text-gray-700 hover:bg-gray-200'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="overflow-x-auto border border-[#E8EAED] rounded-xl">
        <table className="w-full text-left text-xs font-sans">
          <thead className="bg-[#F8F9FA] border-b border-[#E8EAED] text-gray-500 uppercase text-[10px] font-bold">
            <tr>
              <th className="py-2.5 px-3">Timestamp</th>
              <th className="py-2.5 px-3">Event Type</th>
              <th className="py-2.5 px-3">Actor / Agent</th>
              <th className="py-2.5 px-3">Validation Hash</th>
              <th className="py-2.5 px-3 text-right">Details</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filtered.map((log) => {
              const isExpanded = expandedRow === log.id;
              return (
                <React.Fragment key={log.id}>
                  <tr className="hover:bg-gray-50/80 transition-colors">
                    <td className="py-2.5 px-3 font-mono text-gray-500 text-[11px] whitespace-nowrap">
                      {log.timestamp}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-gray-900 flex items-center gap-1.5">
                      <span
                        className={`w-2 h-2 rounded-full ${
                          log.severity === 'warning' ? 'bg-[#FBBC05]' : 'bg-[#34A853]'
                        }`}
                      />
                      {log.eventType}
                    </td>
                    <td className="py-2.5 px-3 text-gray-700">{log.actor}</td>
                    <td className="py-2.5 px-3 font-mono text-[11px] text-[#1A73E8] flex items-center gap-1">
                      <Lock className="w-3 h-3 text-[#1A73E8]" /> {log.hash}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => setExpandedRow(isExpanded ? null : log.id)}
                        className="p-1 rounded text-gray-500 hover:text-gray-900 hover:bg-gray-100"
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </td>
                  </tr>

                  {/* Accordion Delta Row */}
                  {isExpanded && (
                    <tr className="bg-blue-50/30">
                      <td colSpan={5} className="p-3">
                        <div className="bg-[#1E1E1E] text-green-400 p-3 rounded-lg font-mono text-[11px] overflow-x-auto space-y-1">
                          <span className="text-gray-400 font-bold block">// State Delta / Audit Payload JSON</span>
                          <pre>{JSON.stringify(log.delta, null, 2)}</pre>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
