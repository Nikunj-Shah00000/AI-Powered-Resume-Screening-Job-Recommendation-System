import React, { useState } from 'react';
import { ExternalLink, RefreshCw, CheckCircle2, AlertTriangle, XCircle, Github, Linkedin, Globe, ChevronDown, ChevronUp, Code2 } from 'lucide-react';
import { Candidate, PortfolioLink } from '../../../types';

interface PortfolioVerificationPanelProps {
  candidate?: Candidate;
}

export const PortfolioVerificationPanel: React.FC<PortfolioVerificationPanelProps> = ({ candidate }) => {
  const [isVerifying, setIsVerifying] = useState(false);
  const [expanded, setExpanded] = useState(true);

  const links: PortfolioLink[] = candidate?.portfolioLinks || [
    {
      platform: 'github',
      url: 'https://github.com/mayalin-ai',
      status: 'verified',
      lastVerifiedTimestamp: '2 mins ago',
      repoCount: 42,
      topLanguages: ['Python', 'C++', 'CUDA'],
      pinnedProjects: ['vllm-flash-attn-opt', 'transformer-quantizer-v3', 'vertex-agent-sdk']
    },
    {
      platform: 'linkedin',
      url: 'https://linkedin.com/in/mayalin-ai',
      status: 'verified',
      lastVerifiedTimestamp: '10 mins ago'
    },
    {
      platform: 'behance',
      url: 'https://behance.net/mayalin-designs',
      status: 'unverified',
      lastVerifiedTimestamp: '1 hour ago'
    }
  ];

  const handleReVerify = () => {
    setIsVerifying(true);
    setTimeout(() => setIsVerifying(false), 1200);
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Github className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Project Portfolio Extraction & Verification</h3>
            <p className="text-xs text-gray-500">AI Verified code repositories, design portfolios, and social profiles</p>
          </div>
        </div>

        <button
          onClick={handleReVerify}
          disabled={isVerifying}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#E8F0FE] hover:bg-[#D2E3FC] text-[#1A73E8] rounded-full text-xs font-semibold transition-all"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
          <span>{isVerifying ? 'Verifying Links...' : 'Re-Verify Links'}</span>
        </button>
      </div>

      {/* Multi-platform Link Container */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {links.map((link, idx) => {
          const isVerified = link.status === 'verified';
          const isUnverified = link.status === 'unverified';
          const isBroken = link.status === 'broken';

          return (
            <div key={idx} className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] flex flex-col justify-between space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {link.platform === 'github' && <Github className="w-4 h-4 text-gray-900" />}
                  {link.platform === 'linkedin' && <Linkedin className="w-4 h-4 text-[#0A66C2]" />}
                  {link.platform === 'behance' && <Globe className="w-4 h-4 text-[#053EFF]" />}
                  {link.platform === 'website' && <Globe className="w-4 h-4 text-[#34A853]" />}
                  <span className="font-bold text-xs capitalize text-gray-900">{link.platform}</span>
                </div>

                {/* Status Badges */}
                {isVerified && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#E6F4EA] text-[#137333] text-[10px] font-bold">
                    <CheckCircle2 className="w-3 h-3 text-[#34A853]" /> Verified
                  </span>
                )}
                {isUnverified && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#FEF7E0] text-[#B06000] text-[10px] font-bold">
                    <AlertTriangle className="w-3 h-3" /> Unverified
                  </span>
                )}
                {isBroken && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#FCE8E6] text-[#C5221F] text-[10px] font-bold">
                    <XCircle className="w-3 h-3" /> Broken 404
                  </span>
                )}
              </div>

              <div className="text-[11px] text-gray-500 truncate font-mono">{link.url}</div>
              <div className="text-[10px] text-gray-400">Fetched: {link.lastVerifiedTimestamp}</div>

              <a
                href={link.url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-1.5 w-full py-1.5 bg-white hover:bg-[#F1F3F4] border border-gray-300 text-gray-800 rounded-lg text-xs font-medium transition-all"
              >
                <span>Launch Portfolio</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          );
        })}
      </div>

      {/* Expandable Repository Quick-View */}
      <div className="bg-[#F8F9FA] border border-[#E8EAED] rounded-xl p-3.5 space-y-2">
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full flex items-center justify-between text-xs font-bold text-gray-800"
        >
          <span className="flex items-center gap-1.5">
            <Code2 className="w-4 h-4 text-[#1A73E8]" /> Extracted Repository Metadata (GitHub Quick-View)
          </span>
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {expanded && (
          <div className="pt-2 border-t border-gray-200 text-xs space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-semibold text-gray-700">Primary Languages:</span>
              <span className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded font-mono text-[10px]">Python</span>
              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-mono text-[10px]">C++</span>
              <span className="px-2 py-0.5 bg-purple-100 text-purple-800 rounded font-mono text-[10px]">CUDA</span>
            </div>

            <div>
              <span className="font-semibold text-gray-700 block mb-1">Pinned Repositories & Star Metric:</span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div className="bg-white p-2 rounded border border-gray-200 text-[11px]">
                  <p className="font-bold text-gray-900 truncate">vllm-flash-attn-opt</p>
                  <p className="text-[10px] text-gray-500">⭐ 1,420 stars • Python/C++</p>
                </div>
                <div className="bg-white p-2 rounded border border-gray-200 text-[11px]">
                  <p className="font-bold text-gray-900 truncate">transformer-quantizer-v3</p>
                  <p className="text-[10px] text-gray-500">⭐ 890 stars • PyTorch</p>
                </div>
                <div className="bg-white p-2 rounded border border-gray-200 text-[11px]">
                  <p className="font-bold text-gray-900 truncate">vertex-agent-sdk</p>
                  <p className="text-[10px] text-gray-500">⭐ 320 stars • TypeScript</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
