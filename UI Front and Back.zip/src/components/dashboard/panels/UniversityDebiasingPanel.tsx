import React, { useState } from 'react';
import { GraduationCap, ShieldCheck, Sliders, CheckCircle2, Award, ArrowRight } from 'lucide-react';

interface UniversityDebiasingPanelProps {
  debiasingActive?: boolean;
  onToggleDebiasing?: (active: boolean) => void;
}

export const UniversityDebiasingPanel: React.FC<UniversityDebiasingPanelProps> = ({
  debiasingActive = true,
  onToggleDebiasing
}) => {
  const [isActive, setIsActive] = useState<boolean>(debiasingActive);
  const [reviewMode, setReviewMode] = useState<'debiased' | 'standard'>('debiased');

  const handleToggle = (val: boolean) => {
    setIsActive(val);
    if (onToggleDebiasing) onToggleDebiasing(val);
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
            isActive ? 'bg-[#E6F4EA] text-[#137333]' : 'bg-[#E8F0FE] text-[#1A73E8]'
          }`}>
            <div className="relative">
              <GraduationCap className="w-5 h-5" />
              <ShieldCheck className="w-3 h-3 absolute -bottom-1 -right-1 text-[#34A853]" />
            </div>
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Skill-First Masking & University De-biasing</h3>
            <p className="text-xs text-gray-500">Strips elite institutional pedigree to evaluate verified skill competence</p>
          </div>
        </div>

        {/* Review Mode Dropdown */}
        <div className="flex items-center gap-2 shrink-0">
          <select
            value={reviewMode}
            onChange={(e) => setReviewMode(e.target.value as 'debiased' | 'standard')}
            className="text-xs font-semibold bg-[#F8F9FA] border border-[#E8EAED] rounded-lg px-2.5 py-1.5 text-gray-800 focus:outline-none focus:ring-1 focus:ring-[#1A73E8]"
          >
            <option value="debiased">De-biased Competency-First Scoring</option>
            <option value="standard">Standard Review Mode</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Toggle Controls & Institutional Mask Status */}
        <div className="p-3.5 rounded-xl border border-gray-200 bg-[#F8F9FA] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gray-800 flex items-center gap-1.5">
              <GraduationCap className="w-4 h-4 text-[#1A73E8]" /> University De-biasing Shield
            </span>
            <button
              onClick={() => handleToggle(!isActive)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                isActive ? 'bg-[#34A853]' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  isActive ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="text-xs space-y-2">
            <div className="p-2 rounded bg-white border border-gray-200 space-y-1">
              <span className="text-[10px] text-gray-400 uppercase font-bold block">Original Credential</span>
              <p className={`font-mono text-xs ${isActive ? 'line-through text-gray-400' : 'text-gray-800 font-bold'}`}>
                M.S. Computer Science — Stanford University (Ivy League / Top 5)
              </p>
            </div>

            <div className="p-2 rounded bg-[#E6F4EA] border border-[#34A853]/30 space-y-1">
              <span className="text-[10px] text-[#137333] uppercase font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-[#34A853]" /> De-biased Output (Masked)
              </span>
              <p className="font-mono text-xs font-bold text-[#137333]">
                {isActive ? '[Verified Tier 1 Academic Institution - CS Masters]' : 'Unmasked Pedigree View'}
              </p>
            </div>
          </div>
        </div>

        {/* Competency Weight vs Institutional Ranking Comparison Bar */}
        <div className="p-3.5 rounded-xl border border-gray-200 bg-[#F8F9FA] space-y-3">
          <span className="text-xs font-bold text-gray-800 block">
            Skill Competency vs. Institutional Ranking Weighting
          </span>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-[#137333]">Verified Skill Outputs & Proof-of-Work</span>
              <span className="text-[#137333]">88%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden flex">
              <div className="bg-[#34A853] h-full rounded-l-full" style={{ width: '88%' }} />
              <div className="bg-gray-400 h-full rounded-r-full" style={{ width: '12%' }} />
            </div>
            <div className="flex items-center justify-between text-[10px] text-gray-500">
              <span className="flex items-center gap-1 text-[#137333] font-bold">
                <Award className="w-3 h-3 text-[#34A853]" /> Core Skill Certification
              </span>
              <span>12% Pedigree Factor</span>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1 text-[11px] text-gray-600">
            <span className="px-2 py-0.5 rounded-full bg-[#E6F4EA] text-[#137333] font-semibold">
              ✓ 99.4% Pedigree Bias Neutralized
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
