import React, { useState } from 'react';
import { Sliders, RefreshCw, Save, RotateCcw, Sparkles } from 'lucide-react';

export const CustomWeightSlidersPanel: React.FC = () => {
  const [meritWeight, setMeritWeight] = useState(45);
  const [diversityWeight, setDiversityWeight] = useState(30);
  const [experienceWeight, setExperienceWeight] = useState(25);
  const [isRecalibrating, setIsRecalibrating] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState('balanced');

  const total = meritWeight + diversityWeight + experienceWeight;

  const handleReset = () => {
    setMeritWeight(45);
    setDiversityWeight(30);
    setExperienceWeight(25);
    setSelectedPreset('balanced');
  };

  const handleRecalibrate = () => {
    setIsRecalibrating(true);
    setTimeout(() => {
      setIsRecalibrating(false);
    }, 1000);
  };

  const handlePresetChange = (preset: string) => {
    setSelectedPreset(preset);
    if (preset === 'merit_first') {
      setMeritWeight(65);
      setDiversityWeight(20);
      setExperienceWeight(15);
    } else if (preset === 'diversity_first') {
      setMeritWeight(35);
      setDiversityWeight(45);
      setExperienceWeight(20);
    } else {
      setMeritWeight(45);
      setDiversityWeight(30);
      setExperienceWeight(25);
    }
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Sliders className="w-5 h-5 text-[#1A73E8]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Algorithmic Balancing Matrix & Custom Weight Sliders</h3>
            <p className="text-xs text-gray-500">Fine-tune relative importance of technical merit vs. diversity guardrails</p>
          </div>
        </div>

        {/* Presets & Reset */}
        <div className="flex items-center gap-2">
          <select
            value={selectedPreset}
            onChange={(e) => handlePresetChange(e.target.value)}
            className="text-xs font-semibold bg-[#F8F9FA] border border-[#E8EAED] rounded-lg px-2.5 py-1 text-gray-800"
          >
            <option value="balanced">Preset: Balanced Model</option>
            <option value="merit_first">Preset: Technical Merit Focus</option>
            <option value="diversity_first">Preset: High Diversity Guardrails</option>
          </select>

          <button
            onClick={handleReset}
            className="p-1.5 rounded-lg border border-gray-200 text-gray-500 hover:text-gray-900 hover:bg-gray-100"
            title="Reset to Balanced Model"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Sliders Grid */}
      <div className="space-y-3">
        {/* Slider 1: Technical Merit */}
        <div className="p-3 bg-[#F8F9FA] border border-gray-200 rounded-xl space-y-1.5 text-xs">
          <div className="flex items-center justify-between font-bold text-gray-800">
            <span className="flex items-center gap-1 text-[#1A73E8]">
              Technical Merit Weight (Skills, Certs, Portfolio)
            </span>
            <span className="font-mono text-[#1A73E8]">{meritWeight}%</span>
          </div>
          <input
            type="range"
            min={10}
            max={80}
            value={meritWeight}
            onChange={(e) => setMeritWeight(Number(e.target.value))}
            className="w-full accent-[#1A73E8] cursor-pointer"
          />
        </div>

        {/* Slider 2: Diversity Guardrails */}
        <div className="p-3 bg-[#F8F9FA] border border-gray-200 rounded-xl space-y-1.5 text-xs">
          <div className="flex items-center justify-between font-bold text-gray-800">
            <span className="flex items-center gap-1 text-[#A142F4]">
              Structural Diversity Guardrails (Demographic Parity & De-biasing)
            </span>
            <span className="font-mono text-[#A142F4]">{diversityWeight}%</span>
          </div>
          <input
            type="range"
            min={10}
            max={80}
            value={diversityWeight}
            onChange={(e) => setDiversityWeight(Number(e.target.value))}
            className="w-full accent-[#A142F4] cursor-pointer"
          />
        </div>

        {/* Slider 3: Experience & Trajectory */}
        <div className="p-3 bg-[#F8F9FA] border border-gray-200 rounded-xl space-y-1.5 text-xs">
          <div className="flex items-center justify-between font-bold text-gray-800">
            <span className="flex items-center gap-1 text-[#34A853]">
              Experience & Trajectory (Promotion Velocity, Company Tier)
            </span>
            <span className="font-mono text-[#34A853]">{experienceWeight}%</span>
          </div>
          <input
            type="range"
            min={10}
            max={80}
            value={experienceWeight}
            onChange={(e) => setExperienceWeight(Number(e.target.value))}
            className="w-full accent-[#34A853] cursor-pointer"
          />
        </div>
      </div>

      {/* Capacity Indicator & Recalibrate Action */}
      <div className="flex items-center justify-between pt-1 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-gray-500 font-medium">Model Capacity Allocation:</span>
          <span className={`font-mono font-bold px-2 py-0.5 rounded text-[11px] ${
            total === 100 ? 'bg-[#E6F4EA] text-[#137333]' : 'bg-[#FEF7E0] text-[#B06000]'
          }`}>
            {total}% Total
          </span>
        </div>

        <button
          onClick={handleRecalibrate}
          disabled={isRecalibrating}
          className="px-4 py-1.5 rounded-full text-xs font-bold bg-[#1A73E8] hover:bg-[#1557B0] text-white transition-all shadow-2xs flex items-center gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRecalibrating ? 'animate-spin' : ''}`} />
          <span>{isRecalibrating ? 'Recalibrating Ranking...' : 'Recalibrate Ranking'}</span>
        </button>
      </div>
    </div>
  );
};
