import React, { useState } from 'react';
import { Sparkles, Copy, Check, ThumbsUp, ThumbsDown, Info, Shield } from 'lucide-react';
import { Candidate } from '../../../types';

interface XaiMatchJustificationPanelProps {
  candidate?: Candidate;
}

export const XaiMatchJustificationPanel: React.FC<XaiMatchJustificationPanelProps> = ({ candidate }) => {
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState<'up' | 'down' | null>(null);

  const rationale = `This candidate was recommended with high confidence because their 8 years of PyTorch and GCP Vertex AI experience directly mirror your distributed ML infrastructure scaling requirements. Furthermore, their demonstrated promotion velocity (+45% above industry baseline) and open-source contributions indicate strong technical leadership potential.`;

  const decisionWeights = [
    { factor: 'Technical Merit & Stack Alignment', weight: 45, color: '#1A73E8' },
    { factor: 'Career Velocity & Promotion Rate', weight: 30, color: '#A142F4' },
    { factor: 'Cultural Values & Soft Skill Fit', weight: 25, color: '#34A853' }
  ];

  const handleCopy = () => {
    navigator.clipboard.writeText(rationale);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#A142F4]/30 rounded-2xl shadow-2xs relative overflow-hidden">
      {/* Background Subtle Gradient Glow */}
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-[#A142F4]/10 rounded-full blur-2xl pointer-events-none" />

      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#F3E8FD] text-[#A142F4] flex items-center justify-center font-bold text-xs">
            <Sparkles className="w-5 h-5 text-[#A142F4]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Explainable AI (XAI) Match Justification</h3>
            <p className="text-xs text-gray-500">Transparent algorithmic reasoning & decision driver breakdown</p>
          </div>
        </div>

        <span className="text-xs font-bold text-[#A142F4] bg-[#F3E8FD] px-2.5 py-1 rounded-full border border-[#A142F4]/20">
          Gemini 3.6 Explainability
        </span>
      </div>

      {/* AI Rationale Box */}
      <div className="p-4 rounded-xl border border-[#A142F4]/20 bg-[#F3E8FD]/20 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#A142F4] flex items-center gap-1.5">
            <Sparkles className="w-4 h-4" /> AI Match Rationale Context
          </span>

          <button
            onClick={handleCopy}
            className="text-xs font-semibold text-gray-600 hover:text-gray-900 bg-white border border-gray-200 px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-2xs"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#34A853]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Rationale'}</span>
          </button>
        </div>

        <p className="text-xs text-gray-800 leading-relaxed font-sans font-medium">
          "{rationale}"
        </p>

        {/* Feedback Micro-interaction */}
        <div className="flex items-center justify-between pt-2 border-t border-purple-100/60 text-xs">
          <span className="text-gray-500 text-[11px]">Is this explanation helpful?</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFeedback('up')}
              className={`p-1.5 rounded-lg border text-xs transition-all flex items-center gap-1 ${
                feedback === 'up' ? 'bg-[#E6F4EA] border-[#34A853] text-[#137333]' : 'border-gray-200 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <ThumbsUp className="w-3.5 h-3.5" /> Yes
            </button>
            <button
              onClick={() => setFeedback('down')}
              className={`p-1.5 rounded-lg border text-xs transition-all flex items-center gap-1 ${
                feedback === 'down' ? 'bg-[#FCE8E6] border-[#EA4335] text-[#C5221F]' : 'border-gray-200 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <ThumbsDown className="w-3.5 h-3.5" /> No
            </button>
          </div>
        </div>
      </div>

      {/* Decision Weight Breakdown */}
      <div className="space-y-2">
        <span className="text-[11px] font-bold text-gray-700 uppercase tracking-wider block">
          Algorithmic Decision Drivers:
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {decisionWeights.map((w, idx) => (
            <div key={idx} className="p-2.5 rounded-xl border border-gray-200 bg-[#F8F9FA] space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-gray-800 truncate">{w.factor}</span>
                <span className="font-bold font-mono" style={{ color: w.color }}>
                  {w.weight}%
                </span>
              </div>
              <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${w.weight}%`, backgroundColor: w.color }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
