import React from 'react';
import { TrendingUp, Award, Users, Rocket, Zap } from 'lucide-react';
import { Candidate, GrowthTrajectory } from '../../../types';

interface GrowthTrajectoryPanelProps {
  candidate?: Candidate;
}

export const GrowthTrajectoryPanel: React.FC<GrowthTrajectoryPanelProps> = ({ candidate }) => {
  const trajectory = candidate?.growthTrajectory || {
    promotionVelocityTag: '🚀 Fast-Track: Promoted in 18 months',
    promotionVelocityColor: 'green' as const,
    averageTenureMonths: 24,
    industryAvgComparison: '+45% faster than industry baseline',
    titleChanges: [
      { title: 'Software Engineer', year: '2020', company: 'TechCorp' },
      { title: 'Senior AI Engineer', year: '2022', company: 'Google' },
      { title: 'Staff AI Architect', year: '2024', company: 'DeepMind' }
    ],
    avgYearsPerPromotion: 1.8,
    industryAvgYearsPerPromotion: 3.2,
    responsibilityEscalationIndex: 94,
    teamSizeManagedTrend: 'IC → 5 Engineers → 12 Person Research Team'
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E6F4EA] text-[#137333] flex items-center justify-center font-bold text-xs">
            <Rocket className="w-5 h-5 text-[#34A853]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Growth Trajectory Mapping</h3>
            <p className="text-xs text-gray-500">Career velocity, promotion rate & team management scale analysis</p>
          </div>
        </div>
        <span className="text-xs font-bold text-[#137333] bg-[#E6F4EA] px-2.5 py-1 rounded-full flex items-center gap-1">
          <Zap className="w-3.5 h-3.5" /> High Potential (HiPo)
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Metric 1 */}
        <div className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] text-center space-y-1">
          <span className="text-[10px] font-bold text-gray-500 uppercase">Promotion Velocity</span>
          <p className="text-xl font-bold text-[#137333]">{trajectory.avgYearsPerPromotion} Yrs / Promo</p>
          <p className="text-[10px] text-gray-400">Industry Avg: {trajectory.industryAvgYearsPerPromotion} Yrs</p>
        </div>

        {/* Metric 2 */}
        <div className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] text-center space-y-1">
          <span className="text-[10px] font-bold text-gray-500 uppercase">Escalation Index</span>
          <p className="text-sm font-bold text-[#1A73E8] mt-1">{trajectory.responsibilityEscalationIndex}</p>
          <p className="text-[10px] text-gray-400">Top 5% Candidate Percentile</p>
        </div>

        {/* Metric 3 */}
        <div className="p-3.5 rounded-xl border border-[#E8EAED] bg-[#F8F9FA] text-center space-y-1">
          <span className="text-[10px] font-bold text-gray-500 uppercase">Team Size Scale</span>
          <p className="text-xs font-bold text-gray-800 mt-1">{trajectory.teamSizeManagedTrend}</p>
          <p className="text-[10px] text-gray-400">IC to Tech Lead / Principal</p>
        </div>
      </div>
    </div>
  );
};
