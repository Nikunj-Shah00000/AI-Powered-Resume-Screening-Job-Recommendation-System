import React, { useState } from 'react';
import { Network, Sparkles, Info, Layers } from 'lucide-react';
import { Candidate } from '../../../types';

interface SkillGraphPanelProps {
  candidate?: Candidate;
}

export const SkillGraphPanel: React.FC<SkillGraphPanelProps> = ({ candidate }) => {
  const [hoveredNode, setHoveredNode] = useState<{ name: string; score: string; type: string } | null>(null);

  const primarySkill = candidate?.technicalSkills[0] || 'Python';
  const secondarySkills = candidate?.technicalSkills.slice(1, 6) || ['PyTorch', 'TensorFlow', 'Kubernetes', 'GCP', 'Docker'];

  // Skill connections data
  const skillNodes = [
    { id: 'primary', name: primarySkill, isPrimary: true, x: 220, y: 110, score: '99% Primary Mastery' },
    ...secondarySkills.map((sk, idx) => {
      const angle = (idx / secondarySkills.length) * 2 * Math.PI - Math.PI / 2;
      const radius = 100;
      return {
        id: `sec-${idx}`,
        name: sk,
        isPrimary: false,
        x: Math.round(220 + radius * Math.cos(angle)),
        y: Math.round(110 + radius * Math.sin(angle)),
        score: `${95 - idx * 3}% Correlation`
      };
    })
  ];

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-xs">
            <Network className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Graph-Based Skill Extraction Canvas</h3>
            <p className="text-xs text-gray-500">Interactive Knowledge Graph linking primary & related technical domains</p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#E8F0FE] text-[#1A73E8] font-semibold">
            <span className="w-2 h-2 rounded-full bg-[#1A73E8]" /> Primary Core (#1A73E8)
          </span>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#E6F4EA] text-[#137333] font-semibold">
            <span className="w-2 h-2 rounded-full bg-[#34A853]" /> Sub-Skills (#34A853)
          </span>
        </div>
      </div>

      {/* SVG Canvas for Knowledge Graph */}
      <div className="relative bg-[#F8F9FA] rounded-xl border border-[#E8EAED] p-4 min-h-[240px] flex items-center justify-center overflow-hidden">
        {/* Tooltip Overlay */}
        {hoveredNode && (
          <div className="absolute top-3 left-3 bg-gray-900 text-white text-xs px-3 py-1.5 rounded-lg shadow-lg border border-gray-700 z-10 animate-fade-in flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-[#FBBC04]" />
            <div>
              <span className="font-bold">{hoveredNode.name}:</span>{' '}
              <span className="text-emerald-400 font-medium">{hoveredNode.score}</span>
            </div>
          </div>
        )}

        <svg className="w-full h-[220px] max-w-[440px]" viewBox="0 0 440 220">
          {/* Connecting Lines */}
          {skillNodes.filter(n => !n.isPrimary).map((node) => (
            <line
              key={node.id}
              x1={skillNodes[0].x}
              y1={skillNodes[0].y}
              x2={node.x}
              y2={node.y}
              stroke={hoveredNode?.name === node.name ? '#1A73E8' : '#D2E3FC'}
              strokeWidth={hoveredNode?.name === node.name ? '3' : '2'}
              strokeDasharray={node.isPrimary ? 'none' : '4,4'}
              className="transition-all duration-300"
            />
          ))}

          {/* Render Nodes */}
          {skillNodes.map((node) => (
            <g
              key={node.id}
              className="cursor-pointer transition-transform duration-200 hover:scale-105"
              onMouseEnter={() => setHoveredNode({ name: node.name, score: node.score, type: node.isPrimary ? 'Primary' : 'Related' })}
              onMouseLeave={() => setHoveredNode(null)}
            >
              {/* Node Background Pill */}
              <rect
                x={node.x - 45}
                y={node.y - 14}
                width={90}
                height={28}
                rx={14}
                fill={node.isPrimary ? '#1A73E8' : '#34A853'}
                className="shadow-sm transition-colors"
              />
              {/* Node Text */}
              <text
                x={node.x}
                y={node.y + 4}
                textAnchor="middle"
                fill="#FFFFFF"
                fontSize="11"
                fontWeight="bold"
                fontFamily="sans-serif"
              >
                {node.name.length > 11 ? `${node.name.slice(0, 9)}..` : node.name}
              </text>
            </g>
          ))}
        </svg>
      </div>

      <div className="flex items-center justify-between text-xs text-gray-500 pt-1">
        <span className="flex items-center gap-1 text-gray-600">
          <Info className="w-3.5 h-3.5 text-[#1A73E8]" /> Hover over nodes to inspect contextual correlation metrics
        </span>
        <span className="font-semibold text-[#1A73E8]">Google Gemini Graph Parser v3</span>
      </div>
    </div>
  );
};
