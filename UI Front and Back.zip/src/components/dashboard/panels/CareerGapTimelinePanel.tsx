import React, { useState } from 'react';
import { Calendar, AlertCircle, CheckCircle2, MessageSquare, Info, ShieldCheck, Sparkles } from 'lucide-react';
import { Candidate, CareerGap } from '../../../types';

interface CareerGapTimelinePanelProps {
  candidate?: Candidate;
}

export const CareerGapTimelinePanel: React.FC<CareerGapTimelinePanelProps> = ({ candidate }) => {
  const [reviewed, setReviewed] = useState(false);
  const [requested, setRequested] = useState(false);

  const gaps: CareerGap[] = candidate?.careerGaps || [
    {
      id: 'gap-1',
      startDate: '2023-06',
      endDate: '2023-11',
      durationMonths: 6,
      aiContextNote: 'Period correlates with full-time M.S. Thesis completion and independent open-source research as stated in candidate summary.',
      severity: 'Minor Gap',
      userExplanation: 'Dedicated 6 months to full-time research writing and published NeurIPS paper on transformer quantization.'
    }
  ];

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#FEF7E0] text-[#B06000] flex items-center justify-center font-bold text-xs">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Career Gap Analysis & Contextual Timeline</h3>
            <p className="text-xs text-gray-500">Automated timeline gap detection with AI-inferred professional context</p>
          </div>
        </div>

        {gaps.length > 0 ? (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#FEF7E0] text-[#B06000] text-xs font-bold">
            <AlertCircle className="w-3.5 h-3.5" /> {gaps.length} Employment Gap Detected
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#E6F4EA] text-[#137333] text-xs font-bold">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#34A853]" /> Continuous History
          </span>
        )}
      </div>

      {gaps.length === 0 ? (
        <div className="p-4 bg-[#F8F9FA] rounded-xl text-xs text-gray-600 text-center">
          No significant employment gaps (&gt; 3 months) detected across candidate timeline.
        </div>
      ) : (
        <div className="space-y-3">
          {gaps.map((gap) => (
            <div key={gap.id} className="p-4 rounded-xl border border-amber-200 bg-amber-50/40 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 font-bold text-xs">
                    {gap.durationMonths} Month Employment Gap
                  </span>
                  <span className="text-xs text-gray-600 font-medium">
                    ({gap.startDate} — {gap.endDate})
                  </span>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <button
                    onClick={() => setReviewed(!reviewed)}
                    className={`px-3 py-1 rounded-full font-medium transition-all ${
                      reviewed
                        ? 'bg-[#E6F4EA] text-[#137333] border border-emerald-300'
                        : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {reviewed ? '✓ Gap Reviewed' : 'Mark as Reviewed'}
                  </button>

                  <button
                    onClick={() => setRequested(true)}
                    disabled={requested}
                    className="px-3 py-1 rounded-full bg-[#1A73E8] hover:bg-[#1557B0] text-white font-medium transition-all disabled:opacity-50"
                  >
                    {requested ? 'Request Sent' : 'Request Explanation'}
                  </button>
                </div>
              </div>

              {/* AI Contextual Note */}
              <div className="bg-white p-3 rounded-lg border border-amber-200/80 text-xs text-gray-800 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-[#1A73E8]">
                  <Sparkles className="w-3.5 h-3.5" /> AI Contextual Inference
                </div>
                <p className="text-gray-600 leading-relaxed">{gap.aiContextNote}</p>
                {gap.userExplanation && (
                  <div className="mt-2 pt-2 border-t border-gray-100 text-[11px] text-gray-700">
                    <span className="font-semibold text-gray-900">Candidate Note: </span>
                    "{gap.userExplanation}"
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
