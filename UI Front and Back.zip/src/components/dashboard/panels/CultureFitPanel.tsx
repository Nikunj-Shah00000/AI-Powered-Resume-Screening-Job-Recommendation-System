import React from 'react';
import { HeartHandshake, CheckCircle2, MessageSquare, Quote, Sparkles } from 'lucide-react';
import { Candidate, CultureFit } from '../../../types';

interface CultureFitPanelProps {
  candidate?: Candidate;
}

export const CultureFitPanel: React.FC<CultureFitPanelProps> = ({ candidate }) => {
  const culture: CultureFit = candidate?.cultureFit || {
    cultureFitIndex: 94,
    matchedValues: [
      { candidatePhrasing: 'Autonomous Research Execution', corporateValue: 'Innovation & Agility', alignmentScore: 96 },
      { candidatePhrasing: 'Open Source Community Contributor', corporateValue: 'Collaborative Open Ecosystem', alignmentScore: 92 }
    ],
    sourceSnippets: [
      '"Led team of 5 research engineers while maintaining hands-on code contributions in open source vLLM project."'
    ],
    interviewQuestions: [
      'How do you balance pure ML research exploration with strict production SLA deadlines?',
      'Describe a time you optimized GPU hardware usage under strict cloud cost constraints.'
    ]
  };

  return (
    <div className="m3-card p-5 space-y-4 bg-white border border-[#E3E7EE] rounded-2xl shadow-2xs">
      <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#E6F4EA] text-[#137333] flex items-center justify-center font-bold text-xs">
            <HeartHandshake className="w-5 h-5 text-[#34A853]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-900">Culture Fit Predictor & Interview Guide</h3>
            <p className="text-xs text-gray-500">Value alignment scoring & tailored behavioral interview prompts</p>
          </div>
        </div>
        <span className="text-xs font-bold text-[#137333] bg-[#E6F4EA] px-2.5 py-1 rounded-full">
          {culture.cultureFitIndex}% Value Alignment
        </span>
      </div>

      <div className="space-y-3">
        {/* Value Alignment Pairs */}
        <div className="space-y-2">
          <span className="text-[11px] font-bold text-gray-700 uppercase tracking-wider block">
            Matched Core Values:
          </span>
          {culture.matchedValues.map((v, idx) => (
            <div key={idx} className="p-2.5 rounded-lg border border-gray-200 bg-[#F8F9FA] flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-gray-900">{v.corporateValue}</span>
                <span className="text-gray-500 font-medium"> ← "{v.candidatePhrasing}"</span>
              </div>
              <span className="font-bold text-[#137333] bg-[#E6F4EA] px-2 py-0.5 rounded text-[10px]">
                {v.alignmentScore}% Match
              </span>
            </div>
          ))}
        </div>

        {/* Suggested Behavioral Interview Questions */}
        <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-200 text-xs space-y-2">
          <span className="font-bold text-[#1A73E8] flex items-center gap-1.5">
            <MessageSquare className="w-4 h-4" /> AI Generated Interview Questions:
          </span>
          <ul className="space-y-1.5 text-gray-800 list-disc list-inside pl-1">
            {culture.interviewQuestions.map((q, qIdx) => (
              <li key={qIdx} className="leading-relaxed">
                "{q}"
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
