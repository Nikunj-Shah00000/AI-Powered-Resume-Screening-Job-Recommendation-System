import React, { useState } from 'react';
import { SystemSettings } from '../../types';
import {
  SlidersHorizontal,
  ShieldCheck,
  Sparkles,
  Save,
  RotateCcw,
  Bell,
  Cpu,
  Check,
  AlertCircle,
  HelpCircle,
  CheckCircle2
} from 'lucide-react';

interface SystemSettingsTabProps {
  settings: SystemSettings;
  onSaveSettings: (newSettings: SystemSettings) => void;
}

export const SystemSettingsTab: React.FC<SystemSettingsTabProps> = ({
  settings,
  onSaveSettings,
}) => {
  const [formData, setFormData] = useState<SystemSettings>({ ...settings });
  const [savedSuccess, setSavedSuccess] = useState(false);

  const totalWeight =
    Number(formData.skillWeight) +
    Number(formData.experienceWeight) +
    Number(formData.educationWeight) +
    Number(formData.keywordDensityWeight);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleReset = () => {
    setFormData({
      skillWeight: 40,
      experienceWeight: 30,
      educationWeight: 15,
      keywordDensityWeight: 15,
      anonymizedScreening: false,
      autoShortlistThreshold: 85,
      autoRejectThreshold: 45,
      emailNotifications: true,
      modelName: 'gemini-3.6-flash',
    });
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-[#E3E7EE] shadow-2xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E8F0FE] text-[#1A73E8] text-xs font-semibold mb-2">
            <SlidersHorizontal className="w-3.5 h-3.5" /> Material 3 AI Model Configuration
          </div>
          <h1 className="text-xl font-bold text-gray-900 font-sans tracking-tight">
            Screening Algorithm & Sensitivity Weights
          </h1>
          <p className="text-xs text-gray-500 mt-1">
            Customize AI scoring proportions, anonymized blind screening rules, and automated workflow triggers.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 px-3.5 py-2 bg-[#E6F4EA] text-[#137333] font-bold text-xs rounded-full animate-bounce">
            <CheckCircle2 className="w-4 h-4" /> Settings Saved!
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Card 1: AI Scoring Sensitivity Weights */}
        <div className="m3-card p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
            <div>
              <h2 className="text-base font-bold text-gray-900">AI Match Score Component Weights</h2>
              <p className="text-xs text-gray-500">Total must equal 100%</p>
            </div>
            <span
              className={`text-xs font-bold px-3 py-1 rounded-full ${
                totalWeight === 100 ? 'bg-[#E6F4EA] text-[#137333]' : 'bg-[#FCE8E6] text-[#C5221F]'
              }`}
            >
              Total Weight: {totalWeight}%
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Skill Weight */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-gray-700">
                <span>Technical Skills Overlap</span>
                <span className="text-[#1A73E8]">{formData.skillWeight}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={formData.skillWeight}
                onChange={(e) => setFormData({ ...formData, skillWeight: Number(e.target.value) })}
                className="w-full accent-[#1A73E8]"
              />
            </div>

            {/* Experience Weight */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-gray-700">
                <span>Experience Duration & Seniority</span>
                <span className="text-[#1A73E8]">{formData.experienceWeight}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={formData.experienceWeight}
                onChange={(e) => setFormData({ ...formData, experienceWeight: Number(e.target.value) })}
                className="w-full accent-[#1A73E8]"
              />
            </div>

            {/* Education Weight */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-gray-700">
                <span>Education & Accreditation</span>
                <span className="text-[#1A73E8]">{formData.educationWeight}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={formData.educationWeight}
                onChange={(e) => setFormData({ ...formData, educationWeight: Number(e.target.value) })}
                className="w-full accent-[#1A73E8]"
              />
            </div>

            {/* Keyword Density Weight */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-gray-700">
                <span>Keyword Density & Context Match</span>
                <span className="text-[#1A73E8]">{formData.keywordDensityWeight}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={formData.keywordDensityWeight}
                onChange={(e) => setFormData({ ...formData, keywordDensityWeight: Number(e.target.value) })}
                className="w-full accent-[#1A73E8]"
              />
            </div>
          </div>
        </div>

        {/* Card 2: Equity & Blind Screening Options */}
        <div className="m3-card p-6 space-y-4">
          <h2 className="text-base font-bold text-gray-900 pb-3 border-b border-[#F1F3F4]">
            Diversity & Anonymized Screening
          </h2>

          <div className="flex items-center justify-between p-4 rounded-xl bg-[#F8F9FA] border border-[#E3E7EE]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#E6F4EA] text-[#137333] flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-gray-900">Anonymize Candidate Information (Blind Screening)</h3>
                <p className="text-[11px] text-gray-500">
                  Hides candidate names, email addresses, and location demographics to prevent unconscious bias during initial review.
                </p>
              </div>
            </div>

            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={formData.anonymizedScreening}
                onChange={(e) => setFormData({ ...formData, anonymizedScreening: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#34A853]"></div>
            </label>
          </div>
        </div>

        {/* Card 3: Automated Workflow Threshold Triggers */}
        <div className="m3-card p-6 space-y-4">
          <h2 className="text-base font-bold text-gray-900 pb-3 border-b border-[#F1F3F4]">
            Automated Workflow Triggers
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-700 block">
                Auto-Shortlist Score Threshold ({formData.autoShortlistThreshold}%)
              </label>
              <input
                type="range"
                min="50"
                max="98"
                value={formData.autoShortlistThreshold}
                onChange={(e) => setFormData({ ...formData, autoShortlistThreshold: Number(e.target.value) })}
                className="w-full accent-[#34A853]"
              />
              <p className="text-[11px] text-gray-500">
                Candidates scoring above this threshold will automatically receive a "Shortlisted" tag.
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-700 block">
                Auto-Reject Score Threshold ({formData.autoRejectThreshold}%)
              </label>
              <input
                type="range"
                min="20"
                max="60"
                value={formData.autoRejectThreshold}
                onChange={(e) => setFormData({ ...formData, autoRejectThreshold: Number(e.target.value) })}
                className="w-full accent-[#EA4335]"
              />
              <p className="text-[11px] text-gray-500">
                Candidates scoring below this threshold will be flagged for rejection.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-4 py-2 bg-[#F1F3F4] hover:bg-[#E8EAED] text-gray-700 text-xs font-medium rounded-full transition-all"
          >
            <RotateCcw className="w-4 h-4" /> Reset Defaults
          </button>

          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 bg-[#1A73E8] hover:bg-[#1557B0] text-white font-bold text-xs rounded-full shadow-xs transition-all"
          >
            <Save className="w-4 h-4" /> Save System Settings
          </button>
        </div>
      </form>
    </div>
  );
};
