import React, { useState } from 'react';
import { Candidate, JobListing } from '../../types';
import { BidirectionalRecommendationPanel } from './panels/BidirectionalRecommendationPanel';
import { SemanticVectorSearchPanel } from './panels/SemanticVectorSearchPanel';
import { CommuteFilterPanel } from './panels/CommuteFilterPanel';
import { SkillGapAlertPanel } from './panels/SkillGapAlertPanel';
import { CultureFitPanel } from './panels/CultureFitPanel';
import { CareerPathProjectionPanel } from './panels/CareerPathProjectionPanel';
import { GenderNeutralJobTuningPanel } from './panels/GenderNeutralJobTuningPanel';
import {
  Briefcase,
  Sparkles,
  CheckCircle2,
  XCircle,
  Star,
  Zap,
  Filter,
  Search,
  Eye,
  Check,
  Building,
  MapPin,
  Clock,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  SlidersHorizontal,
  ChevronRight,
  UserCheck
} from 'lucide-react';

interface JobMatcherTabProps {
  candidates: Candidate[];
  jobListings: JobListing[];
  onSelectCandidate: (candidate: Candidate) => void;
  onUpdateCandidateStatus: (candidateId: string, status: Candidate['status']) => void;
  onOpenJobCreateModal: () => void;
}

export const JobMatcherTab: React.FC<JobMatcherTabProps> = ({
  candidates,
  jobListings,
  onSelectCandidate,
  onUpdateCandidateStatus,
  onOpenJobCreateModal,
}) => {
  const [selectedJobId, setSelectedJobId] = useState<string>(jobListings[0]?.id || '');
  const [matchScoreFilter, setMatchScoreFilter] = useState<'All' | 'High' | 'Moderate'>('All');
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [analyzingMatchId, setAnalyzingMatchId] = useState<string | null>(null);
  const [aiMatchAnalysis, setAiMatchAnalysis] = useState<Record<string, any>>({});

  const activeJob = jobListings.find((j) => j.id === selectedJobId) || jobListings[0];

  // Run deep Gemini AI Matcher on demand
  const handleRunDeepMatch = async (candidate: Candidate) => {
    if (!activeJob) return;
    setAnalyzingMatchId(candidate.id);

    try {
      const response = await fetch('/api/match-job', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          candidateSkills: candidate.technicalSkills,
          candidateSummary: candidate.summary,
          jobTitle: activeJob.title,
          jobRequirements: activeJob.requiredSkills.join(', '),
          jobDescription: activeJob.description,
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setAiMatchAnalysis((prev) => ({
          ...prev,
          [`${candidate.id}-${activeJob.id}`]: result,
        }));
      }
    } catch (err) {
      console.error('Deep Match Error:', err);
    } finally {
      setAnalyzingMatchId(null);
    }
  };

  // Filter candidates for selected job
  const matchedCandidates = candidates.filter((c) => {
    if (matchScoreFilter === 'High' && c.matchScore < 85) return false;
    if (matchScoreFilter === 'Moderate' && (c.matchScore < 70 || c.matchScore >= 85)) return false;
    if (
      searchFilter &&
      !c.name.toLowerCase().includes(searchFilter.toLowerCase()) &&
      !c.role.toLowerCase().includes(searchFilter.toLowerCase()) &&
      !c.technicalSkills.some((s) => s.toLowerCase().includes(searchFilter.toLowerCase()))
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-[#E3E7EE] shadow-2xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E8F0FE] text-[#1A73E8] text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" /> Gemini Smart Job Recommendation Engine
          </div>
          <h1 className="text-xl font-bold text-gray-900 font-sans tracking-tight">
            Job Matcher & Candidate Ranking Stream
          </h1>
          <p className="text-xs text-gray-500 mt-1">
            Dynamic keyword matching, AI compatibility scores, missing keyword analysis, and quick decision toggles.
          </p>
        </div>

        <button
          onClick={onOpenJobCreateModal}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#1A73E8] hover:bg-[#1557B0] text-white font-medium text-xs rounded-full shadow-2xs transition-all shrink-0"
        >
          <Briefcase className="w-4 h-4" /> Post New Position
        </button>
      </div>

      {/* Gender-Neutral Job Description Tuning Panel */}
      <GenderNeutralJobTuningPanel />

      {/* Bidirectional View Switcher & Stream */}
      <BidirectionalRecommendationPanel
        candidates={candidates}
        jobListings={jobListings}
        onSelectCandidate={onSelectCandidate}
      />

      {/* Semantic Vector Search Engine & Commute Filter Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SemanticVectorSearchPanel />
        <CommuteFilterPanel />
      </div>

      {/* Position Selector Tabs */}
      <div className="m3-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-gray-700 uppercase tracking-wider">
            Select Active Job Position ({jobListings.length})
          </span>
          <span className="text-xs text-[#1A73E8] font-medium">
            {activeJob?.matchedCandidatesCount || 0} Recommended Profiles
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {jobListings.map((job) => (
            <button
              key={job.id}
              onClick={() => setSelectedJobId(job.id)}
              className={`px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap transition-all border shrink-0 ${
                selectedJobId === job.id
                  ? 'bg-[#1A73E8] text-white border-[#1A73E8] shadow-2xs'
                  : 'bg-white text-gray-700 border-[#E3E7EE] hover:border-gray-300'
              }`}
            >
              {job.title}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Job Overview Spotlight */}
      {activeJob && (
        <div className="m3-card p-6 bg-gradient-to-r from-white via-[#F8F9FA] to-[#E8F0FE] space-y-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-[#E3E7EE]">
            <div>
              <span className="text-xs font-semibold text-[#1A73E8] bg-[#E8F0FE] px-2.5 py-0.5 rounded-full">
                {activeJob.department}
              </span>
              <h2 className="text-lg font-bold text-gray-900 mt-1 font-sans">{activeJob.title}</h2>
              <p className="text-xs text-gray-500 flex items-center gap-2 mt-0.5">
                <MapPin className="w-3.5 h-3.5 text-gray-400" /> {activeJob.location} • {activeJob.type} • {activeJob.salaryRange}
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="bg-[#E6F4EA] text-[#137333] px-3 py-1 rounded-full font-bold">
                {activeJob.experienceRequired} Required
              </span>
            </div>
          </div>

          <div className="text-xs text-gray-600 leading-relaxed">
            <strong className="text-gray-800">Required Skill Keywords: </strong>
            <div className="inline-flex flex-wrap gap-1.5 ml-2">
              {activeJob.requiredSkills.map((sk, idx) => (
                <span key={idx} className="bg-white border border-[#E3E7EE] text-gray-800 font-semibold px-2 py-0.5 rounded">
                  {sk}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Filter and Stream Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="relative">
            <input
              type="text"
              placeholder="Search candidate stream..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-white border border-[#E3E7EE] focus:border-[#1A73E8] rounded-full outline-none"
            />
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2" />
          </div>

          <div className="flex items-center bg-white p-0.5 rounded-full border border-[#E3E7EE]">
            <button
              onClick={() => setMatchScoreFilter('All')}
              className={`px-3 py-1 rounded-full transition-all ${
                matchScoreFilter === 'All' ? 'bg-[#E8F0FE] text-[#1A73E8] font-bold' : 'text-gray-600'
              }`}
            >
              All Matches
            </button>
            <button
              onClick={() => setMatchScoreFilter('High')}
              className={`px-3 py-1 rounded-full transition-all ${
                matchScoreFilter === 'High' ? 'bg-[#E6F4EA] text-[#137333] font-bold' : 'text-gray-600'
              }`}
            >
              High Match (&gt;85%)
            </button>
            <button
              onClick={() => setMatchScoreFilter('Moderate')}
              className={`px-3 py-1 rounded-full transition-all ${
                matchScoreFilter === 'Moderate' ? 'bg-[#FEF7E0] text-[#B06000] font-bold' : 'text-gray-600'
              }`}
            >
              70 - 85%
            </button>
          </div>
        </div>

        <span className="text-gray-500">
          Showing <strong>{matchedCandidates.length}</strong> matching candidates
        </span>
      </div>

      {/* Candidate Recommendation Cards Stream */}
      <div className="space-y-4">
        {matchedCandidates.map((candidate) => {
          const aiAnalysis = aiMatchAnalysis[`${candidate.id}-${activeJob.id}`];

          return (
            <div
              key={candidate.id}
              className="m3-card p-6 space-y-4 m3-card-hover border-l-4 border-l-[#1A73E8]"
            >
              {/* Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-[#E8F0FE] text-[#1A73E8] font-bold text-base flex items-center justify-center shrink-0">
                    {candidate.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-gray-900 font-sans tracking-tight">
                      {candidate.name}
                    </h3>
                    <p className="text-xs text-gray-500 font-medium">{candidate.role} • {candidate.location.split('(')[0]}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right">
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#E6F4EA] text-[#137333] text-sm font-bold shadow-2xs">
                      <Star className="w-4 h-4 fill-[#137333]" />
                      {aiAnalysis ? `${aiAnalysis.matchPercentage}% AI Score` : `${candidate.matchScore}% Match`}
                    </span>
                    <p className="text-[10px] text-gray-400 mt-0.5">{candidate.status}</p>
                  </div>
                </div>
              </div>

              {/* Summary / Reasoning */}
              <p className="text-xs text-gray-600 leading-relaxed bg-[#F8F9FA] p-3 rounded-xl border border-[#E8EAED]">
                {aiAnalysis?.fitAnalysis || candidate.summary}
              </p>

              {/* Keywords Match Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="font-bold text-gray-700 block mb-1 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#34A853]" /> Matching Key Keywords:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {(aiAnalysis?.matchingKeywords || candidate.technicalSkills.slice(0, 5)).map((kw: string, i: number) => (
                      <span key={i} className="bg-[#E6F4EA] text-[#137333] font-semibold text-[11px] px-2.5 py-0.5 rounded-full">
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="font-bold text-gray-700 block mb-1 flex items-center gap-1.5">
                    <XCircle className="w-3.5 h-3.5 text-[#EA4335]" /> Missing Keywords:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {(aiAnalysis?.missingKeywords || candidate.missingKeywords).map((kw: string, i: number) => (
                      <span key={i} className="bg-[#FCE8E6] text-[#C5221F] font-semibold text-[11px] px-2.5 py-0.5 rounded-full">
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons Bar */}
              <div className="pt-3 border-t border-[#F1F3F4] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <button
                  onClick={() => handleRunDeepMatch(candidate)}
                  disabled={analyzingMatchId === candidate.id}
                  className="text-[#1A73E8] font-semibold hover:underline flex items-center gap-1"
                >
                  {analyzingMatchId === candidate.id ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Deep Gemini AI Evaluating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" /> Run Deep Gemini Compatibility Check
                    </>
                  )}
                </button>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    onClick={() => onSelectCandidate(candidate)}
                    className="px-3.5 py-1.5 bg-[#F1F3F4] hover:bg-[#E8EAED] text-gray-700 font-medium rounded-full transition-all"
                  >
                    View Full Resume
                  </button>

                  <button
                    onClick={() => onUpdateCandidateStatus(candidate.id, 'Shortlisted')}
                    className="px-4 py-1.5 bg-[#137333] hover:bg-[#0d5023] text-white font-medium rounded-full transition-all flex items-center gap-1.5 shadow-2xs"
                  >
                    <Check className="w-3.5 h-3.5" /> Shortlist Candidate
                  </button>

                  <button
                    onClick={() => onUpdateCandidateStatus(candidate.id, 'Rejected')}
                    className="px-3.5 py-1.5 bg-[#FCE8E6] hover:bg-[#FAD2CF] text-[#C5221F] font-medium rounded-full transition-all"
                  >
                    Reject
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Skill Gap Alert & Culture Fit Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-4 border-t border-[#E3E7EE]">
        <SkillGapAlertPanel candidate={candidates[0]} />
        <CultureFitPanel candidate={candidates[0]} />
      </div>

      {/* Career Path Projection */}
      <CareerPathProjectionPanel />
    </div>
  );
};
