import React, { useState } from 'react';
import { Candidate, JobListing, SystemMetrics, TabType } from '../../types';
import { sampleResumes } from '../../data/mockData';
import {
  FileText,
  TrendingUp,
  CheckCircle2,
  Clock,
  Briefcase,
  Upload,
  Sparkles,
  ArrowRight,
  Filter,
  Eye,
  Star,
  Check,
  Zap,
  ShieldCheck,
  UserCheck,
  ChevronRight,
  AlertCircle
} from 'lucide-react';

interface OverviewTabProps {
  metrics: SystemMetrics;
  candidates: Candidate[];
  jobListings: JobListing[];
  onSelectCandidate: (candidate: Candidate) => void;
  onSelectJob: (job: JobListing) => void;
  setActiveTab: (tab: TabType) => void;
  onParseSampleResume: (sampleText: string, sampleName: string) => void;
  onOpenUploadModal: () => void;
  isParsing: boolean;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  metrics,
  candidates,
  jobListings,
  onSelectCandidate,
  onSelectJob,
  setActiveTab,
  onParseSampleResume,
  onOpenUploadModal,
  isParsing,
}) => {
  const [selectedSample, setSelectedSample] = useState<string>('');

  const topCandidates = [...candidates]
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, 4);

  const activeJobs = jobListings.filter((j) => j.status === 'Active');

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-white via-[#F8F9FA] to-[#E8F0FE] p-6 rounded-2xl border border-[#E3E7EE] shadow-2xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E8F0FE] text-[#1A73E8] text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" /> Material 3 AI Dashboard
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-gray-900 tracking-tight font-sans">
            AI Resume Screening & Job Match Stream
          </h1>
          <p className="text-sm text-gray-600 mt-1 max-w-2xl leading-relaxed">
            Real-time candidate parsing, skill distribution analytics, and automated job matching powered by Google Gemini 3.6.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenUploadModal}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#1A73E8] hover:bg-[#1557B0] text-white font-medium text-sm rounded-full shadow-xs transition-all"
          >
            <Upload className="w-4 h-4" />
            Upload New Resumes
          </button>
        </div>
      </div>

      {/* Metric Cards (Flanked with Quick Stat Colors) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Processed (Google Blue) */}
        <div className="m3-card p-5 border-l-4 border-l-[#1A73E8] relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">Total Resumes</span>
            <div className="w-9 h-9 rounded-full bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-bold text-gray-900 font-sans tracking-tight">
              {metrics.totalProcessed.toLocaleString()}
            </span>
            <span className="text-xs font-semibold text-[#137333] flex items-center gap-0.5">
              <TrendingUp className="w-3.5 h-3.5" /> +{metrics.processedTrendPercentage}%
            </span>
          </div>
          <p className="text-[11px] text-gray-500 mt-1">Processed across active postings</p>
        </div>

        {/* Card 2: Average Match Score (Google Green) */}
        <div className="m3-card p-5 border-l-4 border-l-[#34A853] relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">Avg Match Score</span>
            <div className="w-9 h-9 rounded-full bg-[#E6F4EA] text-[#137333] flex items-center justify-center">
              <Star className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-bold text-gray-900 font-sans tracking-tight">
              {metrics.avgMatchScore}%
            </span>
            <span className="text-xs font-semibold text-[#137333] flex items-center gap-0.5">
              <TrendingUp className="w-3.5 h-3.5" /> +{metrics.matchScoreTrendPercentage}%
            </span>
          </div>
          <p className="text-[11px] text-gray-500 mt-1">High qualification threshold</p>
        </div>

        {/* Card 3: Pending Reviews (Google Yellow) */}
        <div className="m3-card p-5 border-l-4 border-l-[#FBBC04] relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">Pending Reviews</span>
            <div className="w-9 h-9 rounded-full bg-[#FEF7E0] text-[#B06000] flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-bold text-gray-900 font-sans tracking-tight">
              {metrics.pendingReviews}
            </span>
            <span className="text-xs font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
              Requires Action
            </span>
          </div>
          <p className="text-[11px] text-gray-500 mt-1">Ready for recruiter sign-off</p>
        </div>

        {/* Card 4: Jobs Recommended (Google Red Accent) */}
        <div className="m3-card p-5 border-l-4 border-l-[#EA4335] relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">Jobs Recommended</span>
            <div className="w-9 h-9 rounded-full bg-[#FCE8E6] text-[#C5221F] flex items-center justify-center">
              <Briefcase className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl md:text-3xl font-bold text-gray-900 font-sans tracking-tight">
              {metrics.jobsRecommended}
            </span>
            <span className="text-xs font-medium text-red-700 bg-red-50 px-2 py-0.5 rounded-full">
              Active Stream
            </span>
          </div>
          <p className="text-[11px] text-gray-500 mt-1">Matched against 4 open roles</p>
        </div>
      </div>

      {/* Main Grid Section: Drive Dropzone & Top Candidates */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 cols: Drive-inspired Resume Upload & Quick Tester */}
        <div className="lg:col-span-7 m3-card p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center">
                <Upload className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-bold text-gray-900">Google Drive Resume Dropzone</h2>
                <p className="text-xs text-gray-500">Drag PDF / Word files or click to load sample candidate profiles</p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('parser')}
              className="text-xs font-medium text-[#1A73E8] hover:underline flex items-center gap-1"
            >
              Full Parser <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Drag & Drop Area */}
          <div
            onClick={onOpenUploadModal}
            className="border-2 border-dashed border-[#1A73E8]/30 hover:border-[#1A73E8] bg-[#F8F9FA] hover:bg-[#E8F0FE]/30 rounded-2xl p-6 text-center cursor-pointer transition-all group"
          >
            <div className="w-12 h-12 mx-auto rounded-full bg-white shadow-xs border border-gray-200 flex items-center justify-center text-[#1A73E8] group-hover:scale-105 transition-transform">
              <FileText className="w-6 h-6" />
            </div>
            <p className="mt-3 text-sm font-semibold text-gray-800">
              Drop resumes here, or <span className="text-[#1A73E8] hover:underline">browse files</span>
            </p>
            <p className="text-xs text-gray-500 mt-1">Supports PDF, DOCX, TXT (Up to 10MB per file)</p>

            <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-[11px] text-gray-600">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-white border border-gray-200 shadow-2xs">
                <Zap className="w-3 h-3 text-amber-500" /> Instant Gemini Extraction
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-white border border-gray-200 shadow-2xs">
                <ShieldCheck className="w-3 h-3 text-[#34A853]" /> Bias-Free Screening
              </span>
            </div>
          </div>

          {/* Quick Presets / Test Resumes */}
          <div className="pt-2">
            <span className="text-xs font-semibold text-gray-600 uppercase tracking-wider block mb-2">
              Try Preset Candidate Resumes:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {sampleResumes.map((sample, idx) => (
                <button
                  key={idx}
                  disabled={isParsing}
                  onClick={() => {
                    setSelectedSample(sample.name);
                    onParseSampleResume(sample.text, sample.name);
                  }}
                  className={`text-left p-2.5 rounded-xl border text-xs transition-all flex items-center justify-between ${
                    selectedSample === sample.name
                      ? 'border-[#1A73E8] bg-[#E8F0FE] text-[#1A73E8] font-semibold'
                      : 'border-[#E3E7EE] hover:border-gray-300 bg-white text-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileText className="w-4 h-4 text-[#1A73E8] shrink-0" />
                    <span className="truncate">{sample.name}</span>
                  </div>
                  {isParsing && selectedSample === sample.name ? (
                    <span className="text-[10px] text-[#1A73E8] animate-pulse font-bold">Parsing...</span>
                  ) : (
                    <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full shrink-0">
                      Load & Parse
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right 5 cols: Top Matched Candidates */}
        <div className="lg:col-span-5 m3-card p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-[#FBBC04]" />
                <h2 className="text-base font-bold text-gray-900">Top Candidate Matches</h2>
              </div>
              <button
                onClick={() => setActiveTab('analytics')}
                className="text-xs font-medium text-[#1A73E8] hover:underline"
              >
                View All ({candidates.length})
              </button>
            </div>

            <div className="mt-4 space-y-3">
              {topCandidates.map((cand) => (
                <div
                  key={cand.id}
                  onClick={() => onSelectCandidate(cand)}
                  className="p-3 rounded-xl border border-[#E3E7EE] hover:border-[#1A73E8]/40 hover:bg-[#F8F9FA] transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3 truncate">
                    <div className="w-10 h-10 rounded-full bg-[#E8F0FE] text-[#1A73E8] flex items-center justify-center font-bold text-sm shrink-0">
                      {cand.name.charAt(0)}
                    </div>
                    <div className="truncate">
                      <h3 className="text-xs font-bold text-gray-900 group-hover:text-[#1A73E8] transition-colors truncate">
                        {cand.name}
                      </h3>
                      <p className="text-[11px] text-gray-500 truncate">{cand.role}</p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-gray-100 text-gray-600">
                          {cand.experienceYears} yrs exp
                        </span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-blue-50 text-blue-700 font-medium">
                          {cand.location.split('(')[0]}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#E6F4EA] text-[#137333] text-xs font-bold">
                      {cand.matchScore}% Match
                    </div>
                    <p className="text-[10px] text-gray-400 mt-1">{cand.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#F1F3F4] flex items-center justify-between text-xs text-gray-500">
            <span>Sorted by Gemini AI Compatibility Matrix</span>
            <button
              onClick={() => setActiveTab('matcher')}
              className="text-[#1A73E8] font-medium hover:underline flex items-center gap-1"
            >
              Match Stream <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Active Jobs Spotlight & Screening Insights */}
      <div className="m3-card p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#F1F3F4]">
          <div className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-[#1A73E8]" />
            <h2 className="text-base font-bold text-gray-900">Active Job Positions & Candidate Pipeline</h2>
          </div>
          <button
            onClick={() => setActiveTab('matcher')}
            className="text-xs font-medium text-[#1A73E8] hover:underline"
          >
            Manage Job Matcher
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {activeJobs.map((job) => (
            <div
              key={job.id}
              onClick={() => onSelectJob(job)}
              className="p-4 rounded-xl border border-[#E3E7EE] hover:border-[#1A73E8] hover:bg-[#F8F9FA] transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-[#1A73E8] bg-[#E8F0FE] px-2 py-0.5 rounded-full">
                    {job.type}
                  </span>
                  <span className="text-[11px] text-gray-400">{job.postedDate}</span>
                </div>
                <h3 className="text-sm font-bold text-gray-900 mt-2 group-hover:text-[#1A73E8] transition-colors line-clamp-1">
                  {job.title}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5 line-clamp-1">{job.department}</p>
                <p className="text-xs font-semibold text-gray-700 mt-2">{job.salaryRange}</p>

                <div className="mt-3 flex flex-wrap gap-1">
                  {job.requiredSkills.slice(0, 3).map((skill, i) => (
                    <span key={i} className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                      {skill}
                    </span>
                  ))}
                  {job.requiredSkills.length > 3 && (
                    <span className="text-[10px] text-gray-400">+{job.requiredSkills.length - 3}</span>
                  )}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#F1F3F4] flex items-center justify-between text-xs">
                <span className="text-gray-500">
                  <strong className="text-gray-900">{job.applicantsCount}</strong> Applicants
                </span>
                <span className="text-[#137333] font-semibold bg-[#E6F4EA] px-2 py-0.5 rounded-full text-[11px]">
                  {job.matchedCandidatesCount} Matched
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
