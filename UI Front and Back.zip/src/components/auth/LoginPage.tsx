import React, { useState } from 'react';
import {
  Sparkles,
  UserCheck,
  Briefcase,
  Lock,
  Mail,
  User,
  Building2,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  Check,
  Key
} from 'lucide-react';
import { UserProfile, UserRole } from '../../types';

interface LoginPageProps {
  onLogin: (user: UserProfile) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [roleTab, setRoleTab] = useState<UserRole>('recruiter');
  const [isSignUp, setIsSignUp] = useState(false);

  // Form Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [company, setCompany] = useState('');
  const [title, setTitle] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Validation Errors
  const [errors, setErrors] = useState<{ email?: string; password?: string; name?: string }>({});
  const [domainNotice, setDomainNotice] = useState<string | null>(null);

  // Email Validation Handler
  const handleEmailChange = (val: string) => {
    setEmail(val);
    if (errors.email) {
      setErrors((prev) => ({ ...prev, email: undefined }));
    }

    if (roleTab === 'recruiter' && val.includes('@')) {
      const domain = val.split('@')[1] || '';
      if (['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com'].includes(domain.toLowerCase())) {
        setDomainNotice('Tip: Recruiter accounts perform best with corporate domain emails (e.g. @company.com).');
      } else {
        setDomainNotice(null);
      }
    } else {
      setDomainNotice(null);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: { email?: string; password?: string; name?: string } = {};

    if (!email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Please enter a valid email address.';
    }

    if (!password.trim()) {
      newErrors.password = 'Password is required.';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters.';
    }

    if (isSignUp && !name.trim()) {
      newErrors.name = 'Full name is required.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const user: UserProfile = {
      id: `usr-${Date.now()}`,
      name: name || (roleTab === 'recruiter' ? 'Sarah Chen' : 'Maya Lin'),
      email: email,
      role: roleTab,
      title: title || (roleTab === 'recruiter' ? 'Senior Talent Acquisition Lead' : 'Staff AI Engineer Candidate'),
      company: company || (roleTab === 'recruiter' ? 'Hire Studio Corp' : 'Stanford Alum'),
      avatarUrl: roleTab === 'recruiter' ? 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200' : 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200'
    };

    onLogin(user);
  };

  // Quick Demo Preset Logins
  const handleQuickLogin = (role: UserRole) => {
    if (role === 'recruiter') {
      onLogin({
        id: 'usr-recruiter-01',
        name: 'Sarah Chen',
        email: 'sarah.chen@hirestudio.ai',
        role: 'recruiter',
        title: 'Lead Talent Acquisition Manager',
        company: 'Google AI Studio / Hire Studio',
        avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200'
      });
    } else if (role === 'candidate') {
      onLogin({
        id: 'usr-candidate-01',
        name: 'Maya Lin',
        email: 'maya.lin@stanford.edu',
        role: 'candidate',
        title: 'Staff AI Engineer Candidate',
        company: 'DeepMind Researcher (Ex)',
        avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200'
      });
    } else {
      onLogin({
        id: 'usr-auditor-01',
        name: 'David Kim',
        email: 'david.kim@compliance.gov',
        role: 'auditor',
        title: 'Chief Compliance Auditor',
        company: 'Fair AI Standards Institute',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200'
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      {/* Background Decorator Gradients */}
      <div className="absolute top-0 inset-x-0 h-64 bg-gradient-to-b from-[#E8F0FE] to-transparent -z-10 pointer-events-none" />

      {/* Main Login Card Container */}
      <div className="w-full max-w-md bg-white rounded-3xl border border-[#E3E7EE] shadow-xl overflow-hidden space-y-0">
        
        {/* Header Banner */}
        <div className="p-6 bg-gradient-to-br from-[#1A73E8] via-[#1557B0] to-[#A142F4] text-white space-y-2 text-center relative">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI Talent Intelligence Platform</span>
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight">Hire Studio</h1>
          <p className="text-xs text-white/90">
            Sign in to access AI resume parsing, candidate portal, & debiased matching.
          </p>
        </div>

        {/* Role Portal Tabs */}
        <div className="p-4 bg-[#F1F3F4] border-b border-[#E8EAED] grid grid-cols-2 gap-2 text-xs font-bold">
          <button
            type="button"
            onClick={() => setRoleTab('recruiter')}
            className={`py-2.5 px-3 rounded-2xl flex items-center justify-center gap-2 transition-all ${
              roleTab === 'recruiter'
                ? 'bg-white text-[#1A73E8] shadow-sm font-extrabold'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <UserCheck className="w-4 h-4 text-[#1A73E8]" />
            <span>Recruiter Portal</span>
          </button>

          <button
            type="button"
            onClick={() => setRoleTab('candidate')}
            className={`py-2.5 px-3 rounded-2xl flex items-center justify-center gap-2 transition-all ${
              roleTab === 'candidate'
                ? 'bg-white text-[#34A853] shadow-sm font-extrabold'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Briefcase className="w-4 h-4 text-[#34A853]" />
            <span>Candidate Portal</span>
          </button>
        </div>

        {/* Form Area */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-gray-900">
              {isSignUp ? `Create ${roleTab === 'recruiter' ? 'Recruiter' : 'Candidate'} Account` : `Sign In to ${roleTab === 'recruiter' ? 'Recruiter Workspace' : 'Candidate Portal'}`}
            </h2>
            <button
              type="button"
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-xs font-bold text-[#1A73E8] hover:underline"
            >
              {isSignUp ? 'Already registered? Sign In' : 'Need an account? Sign Up'}
            </button>
          </div>

          {/* Full Name field (Only during Sign Up) */}
          {isSignUp && (
            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-700 block">Full Name</label>
              <div className="relative">
                <User className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder={roleTab === 'recruiter' ? 'e.g. Sarah Chen' : 'e.g. Maya Lin'}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`w-full pl-9 pr-3 py-2.5 bg-[#F8F9FA] border rounded-xl text-xs focus:outline-none focus:ring-2 ${
                    errors.name ? 'border-[#EA4335] focus:ring-[#FCE8E6]' : 'border-[#E8EAED] focus:ring-[#E8F0FE] focus:border-[#1A73E8]'
                  }`}
                />
              </div>
              {errors.name && <p className="text-[11px] text-[#EA4335] font-semibold flex items-center gap-1"><AlertCircle className="w-3 h-3" /> {errors.name}</p>}
            </div>
          )}

          {/* Email Address field */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-700 block">
              {roleTab === 'recruiter' ? 'Work Email Address' : 'Candidate Email Address'}
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
              <input
                type="email"
                placeholder={roleTab === 'recruiter' ? 'sarah@company.com' : 'maya.lin@stanford.edu'}
                value={email}
                onChange={(e) => handleEmailChange(e.target.value)}
                className={`w-full pl-9 pr-3 py-2.5 bg-[#F8F9FA] border rounded-xl text-xs focus:outline-none focus:ring-2 ${
                  errors.email ? 'border-[#EA4335] focus:ring-[#FCE8E6]' : 'border-[#E8EAED] focus:ring-[#E8F0FE] focus:border-[#1A73E8]'
                }`}
              />
            </div>
            {errors.email && <p className="text-[11px] text-[#EA4335] font-semibold flex items-center gap-1"><AlertCircle className="w-3 h-3" /> {errors.email}</p>}
            {domainNotice && <p className="text-[11px] text-[#B06000] bg-[#FEF7E0] p-2 rounded-lg font-medium">{domainNotice}</p>}
          </div>

          {/* Password field */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-700 block">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
                }}
                className={`w-full pl-9 pr-10 py-2.5 bg-[#F8F9FA] border rounded-xl text-xs focus:outline-none focus:ring-2 ${
                  errors.password ? 'border-[#EA4335] focus:ring-[#FCE8E6]' : 'border-[#E8EAED] focus:ring-[#E8F0FE] focus:border-[#1A73E8]'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-gray-400 hover:text-gray-700"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {errors.password && <p className="text-[11px] text-[#EA4335] font-semibold flex items-center gap-1"><AlertCircle className="w-3 h-3" /> {errors.password}</p>}
          </div>

          {/* Remember Me */}
          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-2 text-gray-600 font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="accent-[#1A73E8] rounded"
              />
              <span>Remember this browser</span>
            </label>

            <a href="#forgot" onClick={(e) => { e.preventDefault(); alert('Password reset link sent to registered email.'); }} className="text-[#1A73E8] font-bold hover:underline">
              Forgot password?
            </a>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className={`w-full py-3 rounded-2xl text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 ${
              roleTab === 'recruiter'
                ? 'bg-[#1A73E8] hover:bg-[#1557B0]'
                : 'bg-[#34A853] hover:bg-[#2d9248]'
            }`}
          >
            <span>{isSignUp ? 'Create Hire Studio Account' : `Sign In as ${roleTab === 'recruiter' ? 'Recruiter' : 'Candidate'}`}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Quick Demo One-Click Login Presets */}
        <div className="p-6 bg-[#F8F9FA] border-t border-[#E8EAED] space-y-3">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-[#A142F4]" />
            <span className="text-xs font-bold text-gray-800">Quick Demo One-Click Sign-In</span>
          </div>

          <div className="grid grid-cols-1 gap-2 text-xs">
            <button
              type="button"
              onClick={() => handleQuickLogin('recruiter')}
              className="w-full p-2.5 rounded-xl border border-gray-200 bg-white hover:border-[#1A73E8] hover:bg-[#E8F0FE]/40 text-left flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#1A73E8] text-white font-bold flex items-center justify-center text-xs">
                  SC
                </div>
                <div>
                  <p className="font-bold text-gray-900 group-hover:text-[#1A73E8]">Sarah Chen (Recruiter Mode)</p>
                  <p className="text-[10px] text-gray-500">Lead Talent Acquisition @ Hire Studio</p>
                </div>
              </div>
              <span className="text-[10px] font-bold text-[#1A73E8] bg-[#E8F0FE] px-2 py-1 rounded-full">
                Enter Recruiter Mode →
              </span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('candidate')}
              className="w-full p-2.5 rounded-xl border border-gray-200 bg-white hover:border-[#34A853] hover:bg-[#E6F4EA]/40 text-left flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#34A853] text-white font-bold flex items-center justify-center text-xs">
                  ML
                </div>
                <div>
                  <p className="font-bold text-gray-900 group-hover:text-[#34A853]">Maya Lin (Candidate Mode)</p>
                  <p className="text-[10px] text-gray-500">Staff AI Engineer Applicant</p>
                </div>
              </div>
              <span className="text-[10px] font-bold text-[#137333] bg-[#E6F4EA] px-2 py-1 rounded-full">
                Enter Candidate Portal →
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
