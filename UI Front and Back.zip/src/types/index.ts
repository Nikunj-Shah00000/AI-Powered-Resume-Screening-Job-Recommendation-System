export type UserRole = 'recruiter' | 'candidate' | 'auditor';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  title: string;
  company?: string;
  avatarUrl?: string;
}

export type TabType =
  | 'overview'
  | 'parser'
  | 'analytics'
  | 'matcher'
  | 'candidate_portal'
  | 'recruiter_suite'
  | 'security_suite'
  | 'audit_logs'
  | 'settings';

export interface PortfolioLink {
  platform: 'github' | 'behance' | 'linkedin' | 'website';
  url: string;
  status: 'verified' | 'unverified' | 'broken';
  lastVerifiedTimestamp: string;
  repoCount?: number;
  topLanguages?: string[];
  pinnedProjects?: string[];
  thumbnailUrl?: string;
}

export interface CareerGap {
  id: string;
  startDate: string;
  endDate: string;
  durationMonths: number;
  reasonCategory: 'Higher Education / Upskilling' | 'Family Leave' | 'Independent Freelancing / Pivot' | 'Sabbatical / Personal';
  explanationText: string;
  aiConfidence: number;
  resolved: boolean;
  recruiterNotes?: string;
  aiContextNote?: string;
  userExplanation?: string;
}

export interface CompanyExperience {
  id: string;
  companyName: string;
  roleTitle: string;
  startDate: string;
  endDate: string;
  tier: 'Tier 1 (FAANG / Tech Leader)' | 'Tier 2 (Unicorn / Fortune 500)' | 'Tier 3 (Established SMB)' | 'Startup / Early Stage';
  tierOverride?: string;
  criteriaTooltip: string;
  durationMonths: number;
  promotionsInCompany?: { from: string; to: string; monthsTaken: number }[];
}

export interface BlockchainCredential {
  id: string;
  title: string;
  issuer: string;
  issuedDate: string;
  ledgerNetwork: 'Ethereum' | 'Polygon' | 'Hyperledger' | 'Solana';
  txHash: string;
  verificationStatus: 'verified' | 'mismatch' | 'pending';
  proofUrl: string;
}

export interface InferredSoftSkill {
  id: string;
  skillName: string; // e.g. Leadership, Teamwork
  score: number; // 0 - 100
  aiConfidence: number; // e.g. 94%
  resumeSnippet: string;
  validated: boolean;
  confidenceScore?: number;
  evidenceSnippets?: string[];
}

export interface GrowthTrajectory {
  promotionVelocityTag: string; // e.g. "🚀 Fast-Track: Promoted in 14 months"
  promotionVelocityColor: 'green' | 'blue' | 'purple';
  averageTenureMonths: number;
  industryAvgComparison: string; // e.g. "+35% faster than baseline"
  titleChanges: { title: string; year: string; company: string }[];
  avgYearsPerPromotion?: number;
  industryAvgYearsPerPromotion?: number;
  responsibilityEscalationIndex?: number;
  teamSizeManagedTrend?: string;
}

export type CultureFit = CultureFitInfo;

export interface MissingSkillGap {
  skillName: string;
  importance?: string;
  severity: string;
  suggestedCourse?: CourseRecommendation;
}

export interface TechStackEvolution {
  legacySkills?: string[];
  modernSkills?: string[];
  emergingSkills?: string[];
  skills?: TechStackItem[];
}

export interface TechStackItem {
  id: string;
  name: string;
  category: 'Foundational/Legacy' | 'Modern/Emerging Stack';
  yearsExperience: number;
  adoptionTrend: 'Up-to-Date' | 'Modernizing' | 'Legacy';
  matchesJobReq: boolean;
}

export interface FuzzySkillAlias {
  standardizedRole: string;
  aliases: { name: string; confidence: number; approved: boolean }[];
}

export interface MarketDemandInfo {
  marketDemandScore: number; // 0 - 100
  scarcityTags: { skill: string; tag: string; icon: string }[];
  marketAvailability: 'Low' | 'Medium' | 'High';
  hiringVelocity: 'Fast' | 'Stable' | 'Sluggish';
  twelveMonthTrend: number[]; // e.g. array of numbers for sparkline
}

export interface PeerBenchmarking {
  targetRoleBaseline: string; // e.g., "Senior Engineer Baseline"
  metrics: {
    name: string;
    candidateScore: number;
    teamAvgScore: number;
    variancePercentage: number;
  }[];
}

export interface CareerPathStep {
  stepIndex: number;
  title: string;
  estimatedYear: string;
  isCurrent: boolean;
  requiredCertifications: string[];
  targetAspirations: string[];
}

export interface SkillGapItem {
  skillName: string;
  matched: boolean;
  severity: 'Critical Gap' | 'Minor Gap' | 'Nice-to-Have';
  suggestedCourse?: CourseRecommendation;
}

export interface CourseRecommendation {
  id: string;
  title: string;
  platform: 'Coursera' | 'Udemy' | 'LinkedIn Learning' | 'Google Cloud Skills' | 'Internal LMS';
  durationHours: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  bridgesSkill: string;
  syllabusUrl: string;
  assigned: boolean;
}

export interface CommuteInfo {
  workMode: 'Remote' | 'Hybrid' | 'On-Site';
  commuteMinutes: number;
  travelMode: 'Driving' | 'Transit' | 'Cycling' | 'Walking';
  exceedsThreshold: boolean;
}

export interface CultureFitInfo {
  cultureFitIndex: number; // 0 - 100
  matchedValues: { candidatePhrasing: string; corporateValue: string; alignmentScore: number }[];
  sourceSnippets: string[];
  interviewQuestions: string[];
}

export interface Candidate {
  id: string;
  name: string;
  codeName?: string; // Blind screening code name e.g. "Candidate #84A9"
  role: string;
  email: string;
  phone: string;
  location: string;
  regionZone?: string; // Blind screening zone e.g. "Zone 2 - Within Commute"
  experienceYears: number;
  matchScore: number;
  status: 'Parsed' | 'Shortlisted' | 'In Review' | 'Interview Scheduled' | 'Rejected';
  uploadDate: string;
  summary: string;
  technicalSkills: string[];
  softSkills: string[];
  education: string[];
  avatarUrl?: string;
  fileName: string;
  fileSize: string;
  strengths: string[];
  missingKeywords: string[];
  biasMitigationScore: number;
  aiOptimizationTip: string;
  
  // New Feature Modules Rich Metadata
  detectedLanguage?: string; // e.g., 'es' | 'en' | 'fr' | 'de'
  ocrExtractedText?: string;
  portfolioLinks?: PortfolioLink[];
  careerGaps?: CareerGap[];
  companyHistory?: CompanyExperience[];
  blockchainCredentials?: BlockchainCredential[];
  inferredSoftSkills?: InferredSoftSkill[];
  growthTrajectory?: GrowthTrajectory;
  techStackItems?: TechStackItem[];
  fuzzySkillAlias?: FuzzySkillAlias;
  marketDemand?: MarketDemandInfo;
  peerBenchmarking?: PeerBenchmarking;
  careerPathProjection?: CareerPathStep[];
  skillGaps?: SkillGapItem[];
  commuteInfo?: CommuteInfo;
  cultureFit?: CultureFitInfo;
}

export interface JobListing {
  id: string;
  title: string;
  department: string;
  location: string;
  type: 'Full-time' | 'Remote' | 'Hybrid' | 'Contract';
  salaryRange: string;
  requiredSkills: string[];
  preferredSkills: string[];
  experienceRequired: string;
  postedDate: string;
  description: string;
  applicantsCount: number;
  matchedCandidatesCount: number;
  status: 'Active' | 'Draft' | 'Closed';
  workMode?: 'Remote' | 'Hybrid' | 'On-Site';
  commuteTimeMinutes?: number;
  desirabilityScore?: number; // Job-to-Candidate Desirability Score e.g. 92%
}

export interface JobMatchResult {
  jobId: string;
  jobTitle: string;
  candidateId: string;
  candidateName: string;
  matchPercentage: number;
  candidateToJobFit: number;
  jobToCandidateDesirability: number;
  matchingKeywords: string[];
  missingKeywords: string[];
  fitAnalysis: string;
  recommendation: string;
  userDecision?: 'Shortlisted' | 'Rejected' | 'Pending';
}

export interface SystemMetrics {
  totalProcessed: number;
  processedTrendPercentage: number;
  avgMatchScore: number;
  matchScoreTrendPercentage: number;
  pendingReviews: number;
  jobsRecommended: number;
}

export interface SystemSettings {
  skillWeight: number; // e.g. 40%
  experienceWeight: number; // e.g. 30%
  educationWeight: number; // e.g. 15%
  keywordDensityWeight: number; // e.g. 15%
  anonymizedScreening: boolean;
  autoShortlistThreshold: number; // e.g. 85%
  autoRejectThreshold: number; // e.g. 40%
  emailNotifications: boolean;
  modelName: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'success' | 'info' | 'warning' | 'ai';
}

